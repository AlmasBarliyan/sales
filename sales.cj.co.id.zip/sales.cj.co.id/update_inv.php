<?php

$id = intval($_REQUEST['id']);
$product = $_REQUEST['product'];
$amount = $_REQUEST['amount'];

include 'conn.php';

$sql = "update orders set product='$product',amount='$amount' where id=$id";
@mysql_query($sql);
echo json_encode(array(
	'id' => $id,
	'product' => $product,
	'amount' => $amount
));
?>