<?php

include 'conn.php';
$rs = mysql_query('select * from ss_invmonthly left join cd_material on cd_material.material_code = ss_invmonthly.material_code left join cd_code on cd_code.code= ss_invmonthly.storage');
$result = array();
while($row = mysql_fetch_object($rs)){
	array_push($result, $row);
}

echo json_encode($result);

?>