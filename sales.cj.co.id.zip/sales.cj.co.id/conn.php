<?php

$conn = @mysql_connect('localhost','root','admin1234');
if (!$conn) {
	die('Could not connect: ' . mysql_error());
}
mysql_select_db('cj_local_sales_do', $conn);

?>