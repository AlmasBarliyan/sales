<?php

$product = $_REQUEST['product'];
$amount = $_REQUEST['amount'];

include 'conn.php';

$sql = "insert into orders(product,amount) values('$product','$amount')";
@mysql_query($sql);
echo json_encode(array(
	'id' => mysql_insert_id(),
	'product' => $product,
	'amount' => $amount
));

?>