<?php

class IndexController extends \BaseController {

	 public function __construct()
    {
        $this->beforeFilter('auth');
    }
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		return View::make('pages.beranda')
			->with('create_do', DB::table('ss_podetail')->leftJoin('schedule_po','schedule_po.po_no','=','ss_podetail.po_no')->leftJoin('cd_material','cd_material.material_code','=','ss_podetail.material_code')->where('schedule_po.etd','>',date("Y-m-d"))->where('ss_podetail.qty_in_do_um','=','ss_podetail.qty_um')->orderBy('etd','ASC')->take(5)->get());
	}
	

}
