<?php

class CustomersController extends \BaseController {
	public function __construct()
    {
        $this->beforeFilter('auth');
    }
	public function getIndex(){
		//Session::clear();
		Session::forget('code');
		return View::make('customer.create')
			->with('hcode',CommonCode::where('hcode','=','CA01')->where('code','!=','*')->get())
			->with('plant',CommonCode::where('hcode','=','CA02')->where('code','!=','*')->get())
			->with('code',CommonCode::where('code','!=',0)->where('hcode','=',10)->get())
			->with('tabs',CommonCode::where('code','LIKE','%'.'B2'.'%')->where('hcode','=','CA03')->where('code','!=','*')->get())
			->with('customers',Customers::all());
	}
	public function getCode($code){
		Session::put('code',$code);
		$company = CommonCode::where('code','=','10')->get();
		foreach ($company as $cmp) {
			$company = $cmp->code;
		}
		return View::make('customer.create')
			->with('hcode',CommonCode::where('hcode','=','CA01')->where('code','!=','*')->get())
			->with('plant',CommonCode::where('hcode','=','CA02')->where('code','!=','*')->get())
			->with('code',CommonCode::where('code','!=',0)->where('hcode','=',10)->get())
			->with('tabs',CommonCode::where('code','LIKE','%'.'B2'.'%')->where('hcode','=','CA03')->where('code','!=','*')->get())
			->with('company',$company)
			->with('customers',Customers::where('plant','=',1010)->where('customer_ktg','=',Session::get('code'))->get());	
	}
	public function postCreate(){
		$insert = array();
        foreach (Input::get('ship_name') as $key => $ship_name) {
            $insert[$key]['ship_name'] = $ship_name;
        }
        foreach (Input::get('ship_to_party') as $key => $ship_to_party) {
            $insert[$key]['ship_to_party'] = $ship_to_party;
        }
        foreach (Input::get('street') as $key => $street) {
            $insert[$key]['street'] = $street;
        }
        foreach (Input::get('street2') as $key => $street2) {
            $insert[$key]['street2'] = $street2;
        }
        $company = Input::get('company');
        $plant  = Input::get('plant');
        $customer_name = Input::get('customer_name');
        $customer_code = Input::get('customer_code');
        $customer_ktg  = Input::get('customer_ktg');
        $sales_district = Input::get('sales_district');
        $customer = Customers::create([
        'company'       => $company,
        'plant'         => $plant,
        'customer_code'	=> $customer_code,
        'customer_ktg'	=> $customer_ktg,
        'customer_name'	=> $customer_name,
        'sales_district'=> $sales_district
        ]);
        if ($customer) {
        	foreach ($insert as $row ) {
	            DB::table('ss_customerdtl')->insert([
	                'sold_to_party' => $customer_code,
	                'ship_to_party' => $row['ship_to_party'],
	                'ship_name'    	=> $row['ship_name'],
	                'street'        => $row['street'],
	                'street2'       => $row['street2'],
	                ]);
        	}
        }
        return Redirect::to('/customers/'.Session::get('code'));
		
	}
	public function postUpdate(){
		$insert = array();
        foreach (Input::get('ship_name') as $key => $ship_name) {
            $insert[$key]['ship_name'] = $ship_name;
        }
        foreach (Input::get('ship_to_party') as $key => $ship_to_party) {
            $insert[$key]['ship_to_party'] = $ship_to_party;
        }
        foreach (Input::get('stp') as $key => $stp) {
            $insert[$key]['stp'] = $stp;
        }
        foreach (Input::get('street') as $key => $street) {
            $insert[$key]['street'] = $street;
        }
        foreach (Input::get('street2') as $key => $street2) {
            $insert[$key]['street2'] = $street2;
        }
        $company = Input::get('company');
        $plant  = Input::get('plant');
        $customer_name = Input::get('customer_name');
        $customer_code = Input::get('customer_code');
        $customer_ktg  = Input::get('customer_ktg');
        $sales_district = Input::get('sales_district');
        $customer = Customers::where('customer_code','=',$customer_code)->update([
        'company'       => $company,
        'plant'         => $plant,
        'customer_code'	=> $customer_code,
        'customer_ktg'	=> $customer_ktg,
        'customer_name'	=> $customer_name,
        'sales_district'=> $sales_district
        ]);
        if ($customer) {
        	foreach ($insert as $row ) {
                if ($row['stp'] == '' ) {
                    DB::table('ss_customerdtl')->insert([
                    'sold_to_party' => $customer_code,
                    'ship_to_party' => $row['ship_to_party'],
                    'ship_name'     => $row['ship_name'],
                    'street'        => $row['street'],
                    'street2'       => $row['street2'],
                    ]);
                }else{
                    DB::table('ss_customerdtl')->where('ship_to_party','=',$row['stp'])->where('sold_to_party','=',$customer_code)->update([
                    'sold_to_party' => $customer_code,
                    'ship_to_party' => $row['ship_to_party'],
                    'ship_name'     => $row['ship_name'],
                    'street'        => $row['street'],
                    'street2'       => $row['street2'],
                    ]);
                }
        	}
        }
        return Redirect::to('/customers/'.Session::get('code'));
	}
	public function destroy($customer_code){
		$customer = Customers::find($customer_code);
		$customer->delete();

		return Redirect::to('/customers/'.Session::get('code'));
	}
}
