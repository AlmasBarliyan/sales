<?php

class DeliveryOrderController extends \BaseController {
    public function __construct()
    {
        $this->beforeFilter('auth');
    }
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		//$po = DB::table('ss_po')->distinct()->select('po_no')->get();
		//$po = array(''=>'');
		/*foreach (DB::table('ss_invdaily')->join('ss_po', 'ss_invdaily.material_name', '=', 'ss_po.material_name')->select('ss_po.po_no','ss_po.material_name')->get() as $row) {
		 	$po[$row->material_name] = $row->material_name;
		 }*/ 
		$storage = Input::get('storage');

		$do = DB::table('ss_outmaster')->join('ss_outdtl', 'ss_outdtl.no_transaksi', '=', 'ss_outmaster.no_transaksi')->join('ss_customers','ss_customers.customer_code','=','ss_outmaster.customer_code')->get();
        if ($storage == '') {
            Session::put('stor',$storage);
            return View::make('do.create')
            ->with('delivery_order',DB::table('ss_outmaster as om')->leftJoin('ss_outdtl as od','od.no_transaksi','=','om.no_transaksi')->leftJoin('cd_material as mt','mt.material_code','=','od.material_code')->distinct()->select('om.*')->where('om.status','=','D')->where('mt.material_ktg','=',Auth::user()->emp_ktg)->orderBy('om.date_out','DESC')->get());
        }else{
            Session::put('stor',$storage);
            return View::make('do.create')
            ->with('delivery_order',DB::table('ss_outmaster as om')->leftJoin('ss_outdtl as od','od.no_transaksi','=','om.no_transaksi')->leftJoin('cd_material as mt','mt.material_code','=','od.material_code')->distinct()->select('om.*')->where('om.status','=','D')->where('source','=',$storage)->where('mt.material_ktg','=',Auth::user()->emp_ktg)->orderBy('om.date_out','DESC')->get());
        }
		
	}
	public function getCreate()
	{
        session_start();
        session_destroy();
		$po = array('' => '');
        foreach(DB::select(DB::raw("select distinct pd.po_no from ss_pomaster pm left join ss_podetail pd on pd.po_no=pm.po_no where pd.qty_in_do_um < pd.qty_um")) as $row)
            $po[$row->po_no] = $row->po_no;
        Session::put('dn','');
		return View::make('do.add')
			->with('customers',DB::table('cd_customers')->get())
			->with('warehouse',CommonCode::where('hcode','LIKE','%'.'GD'.'%')->where('code','!=','*')->get())
			->with('po', $po);
	}
	public function create()
    {
		$insert = array();
        foreach (Input::get('material_code') as $key => $material_code) {
            $insert[$key]['material_code'] = $material_code;
        }
        foreach (Input::get('qty_out_um') as $key => $qty_out_um) {
            $insert[$key]['qty_out_um'] = $qty_out_um;
        }
        foreach (Input::get('qty_out_uom') as $key => $qty_out_uom) {
            $insert[$key]['qty_out_uom'] = $qty_out_uom;
        }
        foreach (Input::get('lot_number') as $key => $lot_number) {
            $insert[$key]['lot_number'] = $lot_number;
        }
        foreach (Input::get('material_name') as $key => $material_name) {
            $insert[$key]['material_name'] = $material_name;
        }

        $company = Auth::user()->company;
        $plant = Auth::user()->plant;
        
        
        $source = Input::get('source');
        $destination = Input::get('destination');
        if ($source == '8001' or $source == '8002') {
            $src = 'A';
        }elseif ($source == '8003') {
            $src = 'B';
        }
        $trucking   = Input::get('trucking');
        //$no_srtjln  = Input::get('no_srtjln');
        $customer_code = Input::get('customer_code');
        $po_no = Input::get('po_no');
        $remarks    = Input::get('remarks');
        $date_out   = date("Y-m-d",strtotime(Input::get('date_out')));
        $user_create = Auth::user()->employee_code;
        $user_update = Auth::user()->employee_code;
        $no_rtn = DB::select(DB::raw("select max(substr(no_transaksi,-3,3)) as max from ss_outmaster where(select max(substr(no_transaksi,-3,3)) from ss_outmaster where substr(no_transaksi,3,8)= DATE_FORMAT(NOW(),'%Y%m%d')) and substr(no_transaksi,-4,1)='{$src}'"));
        foreach ($no_rtn as $nortn) {
            /*if ($destination == '7001') {
                $no_transaksi = 'DO'.date('Ymd').'B' .sprintf('%03d', $nortn->max+1);
            }
            elseif($destination == '7002'){
                $no_transaksi = 'DO'.date('Ymd').'A'.sprintf('%03d', $nortn->max+1);
            }*/
            $no_transaksi = 'DO'.date('Ymd').$src.sprintf('%03d', $nortn->max+1);
        }
        $do_no = Input::get('no_transaksi');
        //Session::put('dn',$do_no);
        $check = DeliveryOrder::find($do_no);
        if ($check == '') {
        $return = DeliveryOrder::create([
                'company'       => $company,
                'plant'         => $plant,
                'no_transaksi'  => $do_no,
                'po_no'			=> $po_no,
                'customer_code'	=> $customer_code,
                'date_out'      => $date_out,
                'status'        => 'D',
                'destination'   => $destination,
                'source'        => $source,
                'trucking'      => $trucking,
              //  'no_srtjln'     => $no_srtjln,
                'remarks'       => $remarks,
                'user_create'   => $user_create,
                'user_update'   => $user_update
            ]);
        foreach ($insert as $row ) {
            //$lot_number = array(''=>'');
            
            if ($row['qty_out_um'] != 0) {
                
            $return->DoDetail()->attach($do_no,[
                'no_transaksi'     => $do_no,
                'material_code' => $row['material_code'],
                'lot_number'    => $row['lot_number'],
                'qty_out_um'    => $row['qty_out_um'],
                'qty_out_uom'   => $row['qty_out_uom'],
                'status'        => 'G'
                ]);
            $return->InvDaily()->attach($do_no,[
                'id'            => $do_no,
                'company'       => $company,
                'plant'         => $plant,
                'material_code' => $row['material_code'],
                'lot_number'    => $row['lot_number'],
                'qty_um'        => $row['qty_out_um'],
                'qty_uom'       => $row['qty_out_uom'],
                'storage'       => $source,
                'status'        => 'G',
                'status2'       => 'O',
                'date_ym'       => $date_out,
                'created_at'    => date("Y-m-d H:i:s"),
                'updated_at'    => date("Y-m-d H:i:s")
                ]);
            }
            $pd = DB::table('ss_podetail')->where('po_no','=',$po_no)->where('material_code','=',$row['material_code'])->get();
            foreach ($pd as $dp) {
                
                DB::table('ss_podetail')->where('po_no','=',$po_no)->where('material_code','=',$row['material_code'])->update([
                    'qty_in_do_um'  => $dp->qty_in_do_um + $row['qty_out_um'],
                    'qty_in_do_uom' => $dp->qty_in_do_uom + $row['qty_out_uom']
                    ]);
            }
            

        }
		return Redirect::to('/do-view/'.$do_no);
        }else{
            return Redirect::to('/delivery-order')->with('message','Nomor Delivery Order Telah Tersedia');
        }
	}

	public function postData() {
        switch(Input::get('type')):
            case 'lotnumber':
                $return = '<option value=""></option>';
                foreach(Inventory::where('material_code','=',Input::get('id'))->get() as $row)
                    $return .= "<option value='$row->lot_number'>$row->material_name $row->lot_number $row->good_qty_bag BAG</option>";
                return $return;
                
            break;
        endswitch;    
    }
    public function postData1() {
        switch(Input::get('type')):
            case 'dl':
            	$return = "<option></option>";
                foreach(DB::table('ss_customerdtl')->where('sold_to_party','=',Input::get('id'))->get() as $row)
                	$return .= "<option value='$row->ship_to_party'>$row->ship_to_party - $row->ship_name</option>";
                return $return;
                
            break;
        endswitch;    
    }

    public function postShow() {
        switch(Input::get('type')):
            case 'po':
                if (Input::get('dt')=='') {
                    $return = "<script>alert('Date Out is empty!!');window.location.reload();</script>";
                    return $return;
                }else{
                    $id = Input::get('id');
                    $return = "<option></option>";
                    foreach(DB::select(DB::raw("select distinct cs.*,pm.* from ss_pomaster pm 
                                                join cd_customers cs on cs.ship_to_party=pm.customer_code
                                                join ss_podetail pd on pm.po_no = pd.po_no 
                                                where cs.ship_to_party='{$id}' and pd.qty_in_do_um < pd.qty_um")) as $row)
                    $return .= "<option value='$row->po_no'>$row->po_no</option>";
                    return $return;
                }   
            break;
            case 'sip':
                $id = Input::get('id');
                foreach(DB::select(DB::raw("select cd.* from ss_pomaster pm 
				join cd_customers cd on cd.ship_to_party=pm.ship_to_party 
				where pm.po_no='{$id}'")) as $row)
                    session_start();
                    $_SESSION["p"] = $id;
                $return = "<input type='hidden' value='$row->ship_to_party' name='destination'><input  type='text' class='form-control' name='' value='$row->street3' style='width:400px'>";
                return $return;
            break;
            case 'dono':
                $source = Input::get('wh');
                session_start();
                $_SESSION["mo"] = $source;
                
                $dt = date("Ymd",strtotime(Input::get('dt')));
                
                    if ($source == '8001' or $source == '8002') {
                        $src = 'A';
                    }elseif ($source == '8003') {
                        $src = 'B';
                    }
                    foreach(DB::select(DB::raw("select max(substr(no_transaksi,-3,3)) as max from ss_outmaster where(select max(substr(no_transaksi,-3,3)) from ss_outmaster where substr(no_transaksi,3,8)= '{$dt}') and substr(no_transaksi,-4,1)='{$src}' and substr(no_transaksi,3,8)= '{$dt}'")) as $row)
                        $no_transaksi = 'DO'.date('Ymd',strtotime($dt)).$src.sprintf('%03d', $row->max+1);
                        $return = "<input  type='text' style='width: 250px;'' class='form-control' readonly='readonly' name='no_transaksi' value='$no_transaksi'>";
                
                return $return;
            break;
            
        endswitch;    
    }
    public function getEdit($id_tx)
    {
        //Session::put('id_tx',$id_tx);
        $do = DB::table('ss_outmaster')->where('no_transaksi','=',$id_tx)->get();
        return View::make('do.editin')
                ->with('do',$do)
                ->with('storage',CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get())
                ->with('po',PurchaseOrder::all())
                ->with('customers',Customers::all())
                ->with('customerdtl',DB::table('ss_customerdtl')->get())
                ->with('warehouse',CommonCode::where('hcode','LIKE','%'.'GD'.'%')->where('code','!=','*')->get());
    }
    public function send(){
        $input = Input::all();
        
        
    }
    public function getShow($do_no)
    {
        $do = DB::table('ss_outmaster')->where('no_transaksi','=',$do_no)->get();
        return View::make('do.view')
                ->with('do',$do)
                ->with('storage',CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get())
                ->with('po',PurchaseOrder::all())
                ->with('customerdtl',DB::table('cd_customers')->get())
                ->with('warehouse',CommonCode::where('hcode','LIKE','%'.'GD'.'%')->where('code','!=','*')->get());
    }
    public function deleteItem($idtx,$po_no,$mtcd,$lotno,$qty_um,$qty_uom,$source){
        DB::table('ss_outdtl')->where('no_transaksi','=',$idtx)->where('material_code','=',$mtcd)->where('lot_number','=',$lotno)->where('qty_out_um','=',$qty_um)->where('qty_out_uom','=',$qty_uom)->delete();
        DB::table('ss_invdaily')->where('id','=',$idtx)->where('material_code','=',$mtcd)->where('lot_number','=',$lotno)->where('qty_um','=',$qty_um)->where('qty_uom','=',$qty_uom)->where('storage','=',$source)->delete();
        $pd = DB::table('ss_podetail')->where('po_no','=',$po_no)->get();
        foreach ($pd as $dp) {
            
            DB::table('ss_podetail')->where('po_no','=',$po_no)->where('material_code','=',$mtcd)->update([
                'qty_in_do_um'  => $dp->qty_in_do_um - $qty_um,
                'qty_in_do_uom' => $dp->qty_in_do_uom - $qty_uom
                ]);
        }
        return Redirect::back();
    }
    public function postSend()
    {
        /*$insert = array();
        foreach (Session::get('insert') as $key => $do_no) {
            $insert[$key]['do_no'] = $do_no;
        }*/
        
        $message = Input::get('message');

        $to = explode(',', Input::get('to'));
        $cc = explode(',', Input::get('cc'));
        
        
        Mail::send('emails.do',array(
                'msg'=>$message),function($message) use ($to,$cc){
            $message->to($to,Auth::user()->employee_name)->cc($cc)->subject(Input::get('subject'));
            });
            DB::table('mboxes')->insert([
                'subject'   => Input::get('subject'),
                'message'   => $message,
                'sentby'    => Auth::user()->employee_code,
                'sentto'    => Input::get('to'),
                'sentcc'    => Input::get('cc')
                ]);
        return "<script type='text/javascript'>alert('Email Telah Terkirim');window.location = './delivery-order';</script>";
    }
    public function update()
    {
        
        $do_no = Input::get('dotx');
        DB::table('ss_outmaster')->where('no_transaksi','=',$do_no)->delete();
        DB::table('ss_outdtl')->where('no_transaksi','=',$do_no)->delete();
        DB::table('ss_invdaily')->where('id','=',$do_no)->delete();

        $insert = array();
        foreach (Input::get('material_code') as $key => $material_code) {
            $insert[$key]['material_code'] = $material_code;
        }
        foreach (Input::get('qty_out_um') as $key => $qty_out_um) {
            $insert[$key]['qty_out_um'] = $qty_out_um;
        }
        foreach (Input::get('qty_out_uom') as $key => $qty_out_uom) {
            $insert[$key]['qty_out_uom'] = $qty_out_uom;
        }
        foreach (Input::get('lot_number') as $key => $lot_number) {
            $insert[$key]['lot_number'] = $lot_number;
        }
        foreach (Input::get('matcod') as $key => $matcod) {
            $insert[$key]['matcod'] = $matcod;
        }
        foreach (Input::get('q_o_u') as $key => $q_o_u) {
            $insert[$key]['q_o_u'] = $q_o_u;
        }
        foreach (Input::get('q_o_uo') as $key => $q_o_uo) {
            $insert[$key]['q_o_uo'] = $q_o_uo;
        }
        foreach (Input::get('lotno') as $key => $lotno) {
            $insert[$key]['lotno'] = $lotno;
        }
        foreach (Input::get('material_name') as $key => $material_name) {
            $insert[$key]['material_name'] = $material_name;
        }

        $company = Auth::user()->company;
        $plant = Auth::user()->plant;
        
        
        $source = Input::get('source');
        $destination = Input::get('ship_to_party');
        $trucking   = Input::get('trucking');
        $customer_code = Input::get('customer');
        $so_no = Input::get('so_no');
        $so_date = Input::get('so_date');
        $bill_date = Input::get('bill_date');
        $invoice = Input::get('invoice');
        $po_no = Input::get('pn');
        $remarks    = Input::get('remarks');
        $date_out   = date("Y-m-d",strtotime(Input::get('date_out')));
        $user_create = Auth::user()->employee_code;
        $user_update = Auth::user()->employee_code;
        $created_at = Input::get('created_at');
        $exchange_rate = Input::get('exchange_rate');
        $sum = array_reduce($insert, function ($a, $b) {
            isset($a[$b['material_code']]) ? $a[$b['material_code']]['qty_out_um'] += $b['qty_out_um'] : $a[$b['material_code']] = $b;  
            return $a;
        });

        
        $return = DeliveryOrder::create([
                'company'       => $company,
                'plant'         => $plant,
                'no_transaksi'  => $do_no,
                'po_no'         => $po_no,
                'customer_code' => $customer_code,
                'so_no'         => $so_no,
                'bill_date'     => $bill_date,
                'invoice'       => $invoice,
                'date_out'      => $date_out,
                'status'        => 'D',
                'destination'   => $destination,
                'source'        => $source,
                'trucking'      => $trucking,            
                'remarks'       => $remarks,
                'user_create'   => $user_create,
                'user_update'   => $user_update,
                'created_at'    => $created_at            
            ]);
        foreach ($insert as $row ) {
            //$lot_number = array(''=>'');
            
            if ($row['qty_out_um'] != 0) {
                
            $return->DoDetail()->attach($do_no,[
                'no_transaksi'  => $do_no,
                'material_code' => $row['material_code'],
                'lot_number'    => $row['lot_number'],
                'qty_out_um'    => $row['qty_out_um'],
                'qty_out_uom'   => $row['qty_out_uom'],
                'status'        => 'G'
                ]);
            $return->InvDaily()->attach($do_no,[
                'id'            => $do_no,
                'company'       => $company,
                'plant'         => $plant,
                'material_code' => $row['material_code'],
                'lot_number'    => $row['lot_number'],
                'qty_um'        => $row['qty_out_um'],
                'qty_uom'       => $row['qty_out_uom'],
                'storage'       => $source,
                'status'        => 'G',
                'status2'       => 'O',
                'date_ym'       => $date_out,
                'created_at'    => $created_at,
                'updated_at'    => date("Y-m-d H:i:s")
                ]);
            }
            $pd = DB::table('ss_podetail')->where('po_no','=',$po_no)->where('material_code','=',$row['material_code'])->get();
            foreach ($pd as $dp) {
                
                DB::table('ss_podetail')->where('po_no','=',$po_no)->where('material_code','=',$row['matcod'])->update([
                    'qty_in_do_um'  => ($dp->qty_in_do_um - $row['qty_out_um']) + $row['qty_out_um'],
                    'qty_in_do_uom' => ($dp->qty_in_do_uom - $row['qty_out_uom']) + $row['qty_out_uom']
                    ]);                
            }                        
            foreach ($sum as $ttl) {
                DB::table('performance_detail')->where('po_no','=',$po_no)->where('material_code','=',$ttl['material_code'])->where('qty_um','=',$ttl['qty_out_um'])->where('etd','=',$date_out)->update([
                    'so_no'     => $so_no,
                    'invoice'   => $invoice,
                    'bill_date' => $bill_date,
                    'exchange_rate'=> $exchange_rate
                    ]);
            }
        }
        return Redirect::back();
        
    }
    public function postMultipleSend(){
        if (Input::get('ck_do')!='') {
            
        $insert = array();
        foreach (Input::get('ck_do') as $key => $ck_do) {
            $insert[$key]['ck_do'] = $ck_do;
        }
            Session::put('insert',$insert);
            return View::make('textar')->with('do_dtl',$insert);
        }else{
            return Redirect::back();
        }
    }
    public function destroy($do_no){
        $podo = DB::table('ss_outmaster')->where('no_transaksi','=',$do_no)->first();
        $pd = DB::table('ss_podetail')->where('po_no','=',$podo->po_no)->get();
        foreach ($pd as $dp) {
            
            DB::table('ss_podetail')->where('po_no','=',$dp->po_no)->update([
                'qty_in_do_um'  => 0,
                'qty_in_do_uom' => 0
                ]);
        }
        DB::table('ss_outmaster')->where('no_transaksi','=',$do_no)->delete();
        DB::table('ss_outdtl')->where('no_transaksi','=',$do_no)->delete();
        DB::table('ss_invdaily')->where('id','=',$do_no)->delete();
        return Redirect::back();
    }
}