<?php

class DeliveryOrderController extends \BaseController {
    public function __construct()
    {
        $this->beforeFilter('auth');
    }
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		//$po = DB::table('ss_po')->distinct()->select('po_no')->get();
		//$po = array(''=>'');
		/*foreach (DB::table('ss_invdaily')->join('ss_po', 'ss_invdaily.material_name', '=', 'ss_po.material_name')->select('ss_po.po_no','ss_po.material_name')->get() as $row) {
		 	$po[$row->material_name] = $row->material_name;
		 }*/ 
		$storage = Input::get('storage');

		$do = DB::table('ss_outmaster')->join('ss_outdtl', 'ss_outdtl.no_transaksi', '=', 'ss_outmaster.no_transaksi')->join('ss_customers','ss_customers.customer_code','=','ss_outmaster.customer_code')->get();
        if ($storage == '') {
            Session::put('stor',$storage);
            return View::make('do.create')
            ->with('delivery_order',DB::table('ss_outmaster as om')->leftJoin('ss_outdtl as od','od.no_transaksi','=','om.no_transaksi')->leftJoin('cd_material as mt','mt.material_code','=','od.material_code')->distinct()->select('om.*')->where('mt.material_ktg','=',Auth::user()->emp_ktg)->where('om.status','=','D')->orderBy('om.date_out','DESC')->get());
        }else{
            Session::put('stor',$storage);
            return View::make('do.create')
            ->with('delivery_order',DB::table('ss_outmaster as om')->leftJoin('ss_outdtl as od','od.no_transaksi','=','om.no_transaksi')->leftJoin('cd_material as mt','mt.material_code','=','od.material_code')->distinct()->select('om.*')->where('mt.material_ktg','=',Auth::user()->emp_ktg)->where('om.status','=','D')->where('source','=',$storage)->orderBy('om.date_out','DESC')->get());
        }
		
	}
	public function getCreate()
	{
        session_start();
        session_destroy();
		$po = array('' => '');
        foreach(DB::select(DB::raw("select distinct pd.po_no from ss_pomaster pm left join ss_podetail pd on pd.po_no=pm.po_no where pd.qty_in_do_um < pd.qty_um")) as $row)
            $po[$row->po_no] = $row->po_no;
        Session::put('dn','');
		return View::make('do.add')
			->with('customers',DB::table('cd_customers')->get())
			->with('warehouse',CommonCode::where('hcode','LIKE','%'.'GD'.'%')->where('code','!=','*')->get())
			->with('po', $po);
	}
	public function create()
    {
		$insert = array();
        foreach (Input::get('material_code') as $key => $material_code) {
            $insert[$key]['material_code'] = $material_code;
        }
        foreach (Input::get('qty_out_um') as $key => $qty_out_um) {
            $insert[$key]['qty_out_um'] = $qty_out_um;
        }
        foreach (Input::get('qty_out_uom') as $key => $qty_out_uom) {
            $insert[$key]['qty_out_uom'] = $qty_out_uom;
        }
        foreach (Input::get('lot_number') as $key => $lot_number) {
            $insert[$key]['lot_number'] = $lot_number;
        }
        foreach (Input::get('material_name') as $key => $material_name) {
            $insert[$key]['material_name'] = $material_name;
        }

        $company = Auth::user()->company;
        $plant = Auth::user()->plant;
        
        
        $source = Input::get('source');
        $destination = Input::get('destination');
        if ($source == '8001' or $source == '8002') {
            $src = 'A';
        }elseif ($source == '8003') {
            $src = 'B';
        }
        $trucking   = Input::get('trucking');
        //$no_srtjln  = Input::get('no_srtjln');
        $customer_code = Input::get('customer_code');
        $po_no = Input::get('po_no');
        $remarks    = Input::get('remarks');
        $date_out   = date("Y-m-d",strtotime(Input::get('date_out')));
        $user_create = Auth::user()->employee_code;
        $user_update = Auth::user()->employee_code;
        $no_rtn = DB::select(DB::raw("select max(substr(no_transaksi,-3,3)) as max from ss_outmaster where(select max(substr(no_transaksi,-3,3)) from ss_outmaster where substr(no_transaksi,3,8)= DATE_FORMAT(NOW(),'%Y%m%d')) and substr(no_transaksi,-4,1)='{$src}'"));
        foreach ($no_rtn as $nortn) {
            /*if ($destination == '7001') {
                $no_transaksi = 'DO'.date('Ymd').'B' .sprintf('%03d', $nortn->max+1);
            }
            elseif($destination == '7002'){
                $no_transaksi = 'DO'.date('Ymd').'A'.sprintf('%03d', $nortn->max+1);
            }*/
            $no_transaksi = 'DO'.date('Ymd').$src.sprintf('%03d', $nortn->max+1);
        }
        $do_no = Input::get('no_transaksi');
        //Session::put('dn',$do_no);
        $return = DeliveryOrder::create([
                'company'       => $company,
                'plant'         => $plant,
                'no_transaksi'  => $do_no,
                'po_no'			=> $po_no,
                'customer_code'	=> $customer_code,
                'date_out'      => $date_out,
                'status'        => 'D',
                'destination'   => $destination,
                'source'        => $source,
                'trucking'      => $trucking,
              //  'no_srtjln'     => $no_srtjln,
                'remarks'       => $remarks,
                'user_create'   => $user_create,
                'user_update'   => $user_update
            ]);
        foreach ($insert as $row ) {
            //$lot_number = array(''=>'');
            
            if ($row['qty_out_um'] != 0) {
                
            $return->DoDetail()->attach($do_no,[
                'no_transaksi'     => $do_no,
                'material_code' => $row['material_code'],
                'lot_number'    => $row['lot_number'],
                'qty_out_um'    => $row['qty_out_um'],
                'qty_out_uom'   => $row['qty_out_uom'],
                'status'        => 'G'
                ]);
            $return->InvDaily()->attach($do_no,[
                'id'            => $do_no,
                'company'       => $company,
                'plant'         => $plant,
                'material_code' => $row['material_code'],
                'lot_number'    => $row['lot_number'],
                'qty_um'        => $row['qty_out_um'],
                'qty_uom'       => $row['qty_out_uom'],
                'storage'       => $source,
                'status'        => 'G',
                'status2'       => 'O',
                'date_ym'       => $date_out,
                'created_at'    => date("Y-m-d H:i:s"),
                'updated_at'    => date("Y-m-d H:i:s")
                ]);
            }
            $pd = DB::table('ss_podetail')->where('po_no','=',$po_no)->get();
            foreach ($pd as $dp) {
                
                DB::table('ss_podetail')->where('po_no','=',$po_no)->where('material_code','=',$row['material_code'])->update([
                    'qty_in_do_um'  => $dp->qty_in_do_um + $row['qty_out_um'],
                    'qty_in_do_uom' => $dp->qty_in_do_uom + $row['qty_out_uom']
                    ]);
            }
            

        }
		return Redirect::to('/do-view/'.$do_no);
	}

	public function postData() {
        switch(Input::get('type')):
            case 'lotnumber':
                $return = '<option value=""></option>';
                foreach(Inventory::where('material_code','=',Input::get('id'))->get() as $row)
                    $return .= "<option value='$row->lot_number'>$row->material_name $row->lot_number $row->good_qty_bag BAG</option>";
                return $return;
                
            break;
        endswitch;    
    }
    public function postData1() {
        switch(Input::get('type')):
            case 'dl':
            	$return = "<option></option>";
                foreach(DB::table('ss_customerdtl')->where('sold_to_party','=',Input::get('id'))->get() as $row)
                	$return .= "<option value='$row->ship_to_party'>$row->ship_to_party - $row->ship_name</option>";
                return $return;
                
            break;
        endswitch;    
    }

    public function postShow() {
        switch(Input::get('type')):
            case 'po':
                if (Input::get('dt')=='') {
                    $return = "<script>alert('Date Out is empty!!');window.location.reload();</script>";
                    return $return;
                }else{
                    $id = Input::get('id');
                    $return = "<option></option>";
                    foreach(DB::select(DB::raw("select distinct cs.*,pm.* from ss_pomaster pm 
                                                join cd_customers cs on cs.ship_to_party=pm.customer_code
                                                join ss_podetail pd on pm.po_no = pd.po_no 
                                                where cs.ship_to_party='{$id}' and pd.qty_in_do_um < pd.qty_um")) as $row)
                    $return .= "<option value='$row->po_no'>$row->po_no</option>";
                    return $return;
                }   
            break;
            case 'sip':
                $id = Input::get('id');
                foreach(DB::select(DB::raw("select cd.* from ss_pomaster pm 
				join cd_customers cd on cd.ship_to_party=pm.ship_to_party 
				where pm.po_no='{$id}'")) as $row)
                    session_start();
                    $_SESSION["p"] = $id;
                $return = "<input type='hidden' value='$row->ship_to_party' name='destination'><input  type='text' class='form-control' name='' value='$row->street3' style='width:400px'>";
                return $return;
            break;
            case 'dono':
                $source = Input::get('wh');
                session_start();
                $_SESSION["mo"] = $source;
                
                $dt = date("Ymd",strtotime(Input::get('dt')));
                
                    if ($source == '8001' or $source == '8002') {
                        $src = 'A';
                    }elseif ($source == '8003') {
                        $src = 'B';
                    }
                    foreach(DB::select(DB::raw("select max(substr(no_transaksi,-3,3)) as max from ss_outmaster where(select max(substr(no_transaksi,-3,3)) from ss_outmaster where substr(no_transaksi,3,8)= '{$dt}') and substr(no_transaksi,-4,1)='{$src}' and substr(no_transaksi,3,8)= '{$dt}'")) as $row)
                        $no_transaksi = 'DO'.date('Ymd',strtotime($dt)).$src.sprintf('%03d', $row->max+1);
                        $return = "<input  type='text' style='width: 250px;'' class='form-control' readonly='readonly' name='no_transaksi' value='$no_transaksi'>";
                
                return $return;
            break;
            /*case 'po':
                $m = Input::get('wh');
                session_start();
                $_SESSION["mo"] = $m;
                
                $pno = Input::get('pono');
                if (Input::get('pono')=='') {
                    $return = "<script>alert('PO Number is empty!!');window.location.reload();</script>";
                    return $return;
                }
                else{    
                $list = DB::table('ss_invmonthly')->leftJoin('ss_podetail','ss_invmonthly.material_code','=','ss_podetail.material_code')->leftJoin('cd_material','ss_invmonthly.material_code','=','cd_material.material_code')->select('ss_invmonthly.*','cd_material.*')->distinct()->where('po_no','=',Input::get('pono'))->where('storage','=',Input::get('wh'))->where('ss_invmonthly.status','=','G')->where('ss_invmonthly.end_qty_um','!=',0)->get();
                if (count($list)==0) {
                    $return = "<script>alert('Not Found a Product In Warehouse!!');window.location.reload();</script>";
                }else{
            	
                foreach (DB::table('ss_invmonthly')->leftJoin('ss_podetail','ss_invmonthly.material_code','=','ss_podetail.material_code')->leftJoin('cd_material','ss_invmonthly.material_code','=','cd_material.material_code')->select('ss_invmonthly.*','cd_material.*')->where('po_no','=',Input::get('pono'))->where('storage','=',Input::get('wh'))->where('ss_invmonthly.status','=','G')->where('ss_invmonthly.end_qty_um','!=',0)->get() as $row)
                    
                	$return .= "<p><p>
                      ";
                }
                return $return;
                }
            break;
            case 'dono':
            	$source = Input::get('wh');
		        $dt = date("Ymd",strtotime(Input::get('dt')));
                
                    if ($source == '8001' or $source == '8002') {
    		            $src = 'A';
    		        }elseif ($source == '8003') {
    		            $src = 'B';
    		        }
                	foreach(DB::select(DB::raw("select max(substr(no_transaksi,-3,3)) as max from ss_outmaster where(select max(substr(no_transaksi,-3,3)) from ss_outmaster where substr(no_transaksi,3,8)= '{$dt}') and substr(no_transaksi,-4,1)='{$src}' and substr(no_transaksi,3,8)= '{$dt}'")) as $row)
                		$no_transaksi = 'DO'.date('Ymd',strtotime($dt)).$src.sprintf('%03d', $row->max+1);
                		$return = "<input  type='text' style='width: 250px;'' class='form-control' readonly='readonly' name='no_transaksi' value='$no_transaksi'>";
                	return $return;

            break;
            case 'cu':
                if (Input::get('dt')=='') {
                    $return = "<script>alert('Date Out is empty!!');window.location.reload();</script>";
                    return $return;
                }else{
                $id = Input::get('id');
            	foreach(DB::select(DB::raw("select cs.*,pm.po_no from ss_pomaster pm join ss_customers cs on cs.customer_code=pm.customer_code where pm.po_no='{$id}'")) as $row)
                    session_start();
                    $_SESSION["p"] = $row->po_no;
            	$return = "<input type='hidden' name='customer_code' value='$row->customer_code' ><input type='hidden' value='$row->po_no' id='pono'><input  type='text' class='form-control' readonly='readonly' name='' style='width:400px' value='$row->customer_name'>";
            	return $return;
                }
            break;
            case 'sip':
                $id = Input::get('id');
            	foreach(DB::select(DB::raw("select cd.* from ss_pomaster pm join ss_customers cs on cs.customer_code=pm.customer_code join ss_customerdtl cd on cd.ship_to_party=pm.ship_to_party where pm.po_no='{$id}'")) as $row)
            	$return = "<input type='hidden' value='$row->ship_to_party' name='destination'><input  type='text' class='form-control' readonly='readonly' name='' value='$row->ship_name' style='width:400px'>";
            	return $return;
            break;
            case 'cus':
                $id = Input::get('id');
                $return = "<option></option>";
                foreach(DB::select(DB::raw("select cd.* from ss_customers cs join ss_customerdtl cd on cd.sold_to_party=cs.customer_code")) as $row)
                $return .= "<option>$row->ship_name</option>";
                return $return;
            break;*/
        endswitch;    
    }
    public function getEdit($id_tx)
    {
        //Session::put('id_tx',$id_tx);
        $do = DB::table('ss_outmaster')->where('no_transaksi','=',$id_tx)->get();
        return View::make('do.editin')
                ->with('do',$do)
                ->with('storage',CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get())
                ->with('po',PurchaseOrder::all())
                ->with('customers',Customers::all())
                ->with('customerdtl',DB::table('ss_customerdtl')->get())
                ->with('warehouse',CommonCode::where('hcode','LIKE','%'.'GD'.'%')->where('code','!=','*')->get());
    }
    public function send(){
        $input = Input::all();
        
        
    }
    public function getShow($do_no)
    {
        $do = DB::table('ss_outmaster')->where('no_transaksi','=',$do_no)->get();
        return View::make('do.view')
                ->with('do',$do)
                ->with('storage',CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get())
                ->with('po',PurchaseOrder::all())
                ->with('customers',Customers::all())
                ->with('customerdtl',DB::table('ss_customerdtl')->get())
                ->with('warehouse',CommonCode::where('hcode','LIKE','%'.'GD'.'%')->where('code','!=','*')->get());
    }
    public function postSend()
    {
        /*$insert = array();
        foreach (Session::get('insert') as $key => $do_no) {
            $insert[$key]['do_no'] = $do_no;
        }*/
        
        $message = Input::get('message');

        /*$do = DB::table('ss_outmaster as om')
                                ->select(DB::raw("*, (select count(material_code) from ss_outdtl where material_code = od.material_code) as jumlah"))
                                ->leftJoin('ss_outdtl as od','om.no_transaksi','=','od.no_transaksi')
                                ->leftJoin('cd_material as mt','mt.material_code','=','od.material_code')
                                ->leftJoin('ss_customers as cm','cm.customer_code','=','om.customer_code')
                                ->leftJoin('ss_customerdtl as cd','cd.ship_to_party','=','om.destination')
                                ->leftJoin('ss_pomaster as pm','pm.po_no','=','om.po_no')
                                ->whereIn('od.no_transaksi',$insert)->get();*/
        $to = explode(',', Input::get('to'));
        $cc = explode(',', Input::get('cc'));
        /*foreach ($do as $row) {
            $destination = $row->street2;
            $material_name = $row->material_name;
            $material_code = $row->material_code;
            $customer_name = $row->customer_name;
            $trucking = $row->trucking;
            $po_no = $row->po_no;
            $po_date = $row->po_date;
            $remarks = $row->remarks;
        }*/
        
        Mail::send('emails.do',array(
                /*'material_name'=>$material_name, 
                'material_code'=>$material_code, */
                //'do_no'=>$insert,
                /*'trucking'=>$trucking,
                'customer_name'=>$customer_name, 
                'destination'=>$destination,
                'po_no'=>$po_no,
                'po_date'=>$po_date,
                'remarks'=>$remarks,*/
                'msg'=>$message),function($message) use ($to,$cc){
            $message->to($to,Auth::user()->employee_name)->cc($cc)->subject(Input::get('subject'));
            });
        return "<script type='text/javascript'>alert('Email Telah Terkirim');window.location = './delivery-order';</script>";
    }
    public function update(){
        $podetail = DB::table('ss_outmaster')->where('no_transaksi','=',Input::get('dotx'))->update([
            'no_transaksi'=>Input::get('dotx'),
            'trucking'=> Input::get('trucking'),
            ]);
        return Redirect::back();
    }
    public function postMultipleSend(){
        if (Input::get('ck_do')!='') {
            
        $insert = array();
        foreach (Input::get('ck_do') as $key => $ck_do) {
            $insert[$key]['ck_do'] = $ck_do;
        }
            Session::put('insert',$insert);
            return View::make('textar')->with('do_dtl',$insert);
        }else{
            return Redirect::back();
        }
    }
    public function destroy($do_no){
        DB::table('ss_outmaster')->where('no_transaksi','=',$do_no)->delete();
        DB::table('ss_outdtl')->where('no_transaksi','=',$do_no)->delete();
        DB::table('ss_invdaily')->where('id','=',$do_no)->delete();
        return Redirect::back();
    }
}