<?php

class MailboxController extends \BaseController {
	public function sentmail(){
		return View::make('mailbox.sentmail')
			->with('listmail',DB::table('mboxes')->get());
	}
}
