<?php

class MailboxController extends \BaseController {
	public function sentmail(){
		return View::make('mailbox.sentmail')
			->with('listmail',DB::table('mboxes')->orderBy('created_at','DESC')->paginate(10));
	}
	public function postShow() {
        switch(Input::get('type')):
        case 'sent':

        	foreach(DB::table('mboxes')->where('id','=',Input::get('id'))->get() as $row)
        	$return = "$row->subject";
        	/*$return = "<div class='mail_heading row'>
                          <div class='col-md-8'>
                            <div class='compose-btn'>
                              <a class='btn btn-sm btn-primary' href='mail_compose.html'><i class='fa fa-reply'></i> Reply</a>
                              <button title=' data-placement='top' data-toggle='tooltip' type='button' data-original-title='Print' class='btn  btn-sm tooltips'><i class='fa fa-print'></i> </button>
                              <button title=' data-placement='top' data-toggle='tooltip' data-original-title='Trash' class='btn btn-sm tooltips'><i class='fa fa-trash-o'></i>
                              </button>
                            </div>

                          </div>
                          <div class='col-md-4 text-right'>
                            <p class='date'> 8:02 PM 12 FEB 2014</p>
                          </div>
                          <div class='col-md-12'>
                            <h4> Donec vitae leo at sem lobortis porttitor eu consequat risus. Mauris sed congue orci. Donec ultrices faucibus rutrum.</h4>
                          </div>
                        </div>
                        <div class='sender-info'>
                          <div class='row'>
                            <div class='col-md-12'>
                              <strong>Jon Doe</strong>
                              <span>(jon.doe@gmail.com)</span> to
                              <strong>me</strong>
                              <a class='sender-dropdown'><i class='fa fa-chevron-down'></i></a>
                            </div>
                          </div>
                        </div>
                        <div class='view-mail'>
                          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
                          <p>Riusmod tempor incididunt ut labor erem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                            nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
                            mollit anim id est laborum.</p>
                          <p>Modesed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                            velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                        </div>                        
                        <div class='compose-btn pull-left'>
                          <a class='btn btn-sm btn-primary' href='mail_compose.html'><i class='fa fa-reply'></i> Reply</a>
                          <button class='btn btn-sm '><i class='fa fa-arrow-right'></i> Forward</button>
                          <button title=' data-placement='top' data-toggle='tooltip' type='button' data-original-title='Print' class='btn  btn-sm tooltips'><i class='fa fa-print'></i> </button>
                          <button title=' data-placement='top' data-toggle='tooltip' data-original-title='Trash' class='btn btn-sm tooltips'><i class='fa fa-trash-o'></i>
                          </button>
                        </div>";*/
            return $return;
        break;
            
        endswitch;  
    }
}
