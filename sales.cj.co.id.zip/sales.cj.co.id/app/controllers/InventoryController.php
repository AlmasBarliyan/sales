<?php

class InventoryController extends \BaseController {
    public function __construct()
    {
        $this->beforeFilter('auth');
    }
    public function getIndex() {

        /*$products = array('' => '');
        foreach( as $row)
            $products[$row->material_code] = $row->material_code." - ". $row->material_name ;*/
        return View::make('inventory.create', array(
            'products'  => Products::all(),
            'storage'   => CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get(),
            'inbound'   => DB::table('tx_itemin')->orderBy('date_in','DESC')->get()
        ));
    }
    
    public function postData() {
        switch(Input::get('type')):
            case 'nicklot' and 'size':
                //$return = '<option value=""></option>';
                foreach(Products::where('material_code', Input::get('id'))->get() as $row)
                    $return = "<input type='text' readonly='readonly' value='$row->nicklot' class='form-control' name='nicklot'>
                                <input type='hidden' value='$row->material_name' name='material_name'>
                                <input type='hidden' id='good_kg' onkeyup='myFunction()' value='$row->material_size' name='good_qty_bag'>
                                <input type='hidden' id='bad_kg' onkeyup='myFunction()' value='$row->material_size' name='bad_qty_kgs'>
                                <input type='hidden' id='result_kg' onkeyup='myFunction()' value='$row->material_size' name='result_kgs'> ";
                return $return;
            break;
        endswitch;    
    }
    public function add(){
        return View::make('inventory.add')
            ->with('storage',CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get());
    }
    public function postCreate(){
        date_default_timezone_set("Asia/Jakarta");
           
        $insert = array();
        foreach (Input::get('material_code') as $key => $material_code) {
            $insert[$key]['material_code'] = $material_code;
        }
        foreach (Input::get('qty') as $key => $qty) {
            $insert[$key]['qty'] = $qty;
        }
        foreach (Input::get('status') as $key => $status) {
            $insert[$key]['status'] = $status;
        }
        foreach (Input::get('nolot') as $key => $nolot) {
            $insert[$key]['nolot'] = $nolot;
        }
        foreach (Input::get('uom') as $key => $uom) {
            $insert[$key]['uom'] = $uom;
        }
        $company = Auth::user()->company;
        $plant = Auth::user()->plant;
        $storage = Input::get('storage');
        $date_in = date("Y-m-d", strtotime(Input::get('date_in'))) ;
        //$material_code = Input::get('material_code');
        /*$lot_number = array(''=>'');
        foreach ($insert as $in) {
            $nicklot = Products::where('material_code','=',$in['material_code'])->get();
            foreach ($nicklot as $lot) {
                $lot_number[$lot->nicklot] = $lot->nicklot;
            }
        }*/
        $id_transaksi = Input::get('id_transaksi');
        $check = Transaksi::find($id_transaksi);
        if ($check == '') {
            
        $in = Transaksi::create([
        'company'       => $company,
        'plant'         => $plant,
        'id_transaksi'  => $id_transaksi,
        'date_in'       => $date_in,
        'storage'       => $storage,
        'no_suratjln'   => Input::get('no_suratjln'),
        'status'        => 'I',
        'remarks'       => Input::get('remarks'),
        'user_create'   => Auth::user()->employee_code,
        'user_update'   => Auth::user()->employee_code
        ]);
        foreach ($insert as $row ) {
            //$lot_number = array(''=>'');
            $nicklot = Products::where('material_code','=',$row['material_code'])->get();
            foreach ($nicklot as $lot) {
                if ($row['status'] == 'G' or $row['status'] == 'B') {
                    
                $in->InDetail()->attach($id_transaksi,[
                    'id_transaksi'  => $id_transaksi,
                    'material_code' => $row['material_code'],
                    'lot_number'    => $lot->nicklot.$row['nolot'],
                    'qty_um'           => $row['qty'],
                    'qty_uom'           => $row['uom'],
                    'status'        => $row['status']
                    ]);
                $in->InvDaily()->attach($id_transaksi,[
                    'id'            => $id_transaksi,
                    'company'       => $company,
                    'plant'         => $plant,
                    'material_code' => $row['material_code'],
                    'lot_number'    => $lot->nicklot.$row['nolot'],
                    'qty_um'        => $row['qty'],
                    'qty_uom'       => $row['uom'],
                    'storage'       => $storage,
                    'status'        => $row['status'],
                    'status2'       => 'I',
                    'date_ym'       => $date_in,
                    'created_at'    => date("Y-m-d H:i:s"),
                    'updated_at'    => date("Y-m-d H:i:s")
                    ]);
                }else{
                    $in->InDetail()->attach($id_transaksi,[
                        'id_transaksi'  => $id_transaksi,
                        'material_code' => $row['material_code'],
                        'lot_number'    => $lot->nicklot.$row['nolot'],
                        'qty_um'        => $row['qty'],
                        'qty_uom'       => $row['uom'],
                        'status'        => $row['status']
                    ]);
                }
            }
        }
            return Redirect::to('/inbound');
        }else{
            return Redirect::to('/inbound')->with('message','Nomor STO Telah Tersedia');
        }
    }
    public function getEdit($id_tx)
    {
        Session::put('id_tx',$id_tx);
        $inbound = DB::table('tx_itemin')->where('id_transaksi','=',$id_tx)->get();
        return View::make('inventory.editin')
                ->with('inbound',$inbound)
                ->with('storage',CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get());
    }

    public function postInEdit(){
        /*date_default_timezone_set("Asia/Jakarta");
           
        $insert = array();
        foreach (Input::get('material_code') as $key => $material_code) {
            $insert[$key]['material_code'] = $material_code;
        }
        foreach (Input::get('matcod') as $key => $matcod) {
            $insert[$key]['matcod'] = $matcod;
        }
        foreach (Input::get('qty') as $key => $qty) {
            $insert[$key]['qty'] = $qty;
        }
        foreach (Input::get('kuantity_um') as $key => $kuantity_um) {
            $insert[$key]['kuantity_um'] = $kuantity_um;
        }
        foreach (Input::get('kuantity_uom') as $key => $kuantity_uom) {
            $insert[$key]['kuantity_uom'] = $kuantity_uom;
        }
        foreach (Input::get('status') as $key => $status) {
            $insert[$key]['status'] = $status;
        }
        foreach (Input::get('stat') as $key => $stat) {
            $insert[$key]['stat'] = $stat;
        }
        foreach (Input::get('nolot') as $key => $nolot) {
            $insert[$key]['nolot'] = $nolot;
        }
        foreach (Input::get('no_lot') as $key => $no_lot) {
            $insert[$key]['no_lot'] = $no_lot;
        }
        foreach (Input::get('uom') as $key => $uom) {
            $insert[$key]['uom'] = $uom;
        }
        
        
        
        $company = Auth::user()->company;
        $plant = Auth::user()->plant;
        $storage = Input::get('storage');
        $stor = Input::get('stor');
        $date_in = date("Y-m-d", strtotime(Input::get('date_in')));
        //$material_code = Input::get('material_code');
        /*$lot_number = array(''=>'');
        foreach ($insert as $in) {
            $nicklot = Products::where('material_code','=',$in['material_code'])->get();
            foreach ($nicklot as $lot) {
                $lot_number[$lot->nicklot] = $lot->nicklot;
            }
        }
        //$id_transaksi = Input::get('id_transaksi');
        $in = Transaksi::find(Input::get('id'));
        $in->company        = $company;
        $in->plant          = $plant;
        $in->id_transaksi   = Input::get('id_transaksi');
        $in->date_in        = $date_in;
        $in->storage        = Input::get('storage');
        $in->no_suratjln    = Input::get('no_suratjln');
        $in->status         = 'I';
        $in->remarks        = Input::get('remarks');
        $in->user_update    = Auth::user()->employee_code;
        
        if ($in->save()) {
            foreach ($insert as $row ) {

            //$lot_number = array(''=>'');
                $nicklot = Products::where('material_code','=',$row['material_code'])->get();
                foreach ($nicklot as $lot) {
                    /*$cekdtl = TransaksiDetail::where('id_transaksi','=',Input::get('id'))->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['no_lot'])->where('status','=',$row['stat'])->where('qty_um','=',$row['kuantity_um'])->where('qty_uom','=',$row['kuantity_uom'])->orWhere('material_code','=',$row['material_code'])->orWhere('lot_number','=',$lot->nicklot.$row['nolot'])->orWhere('status','=',$row['status'])->orWhere('qty_um','=',$row['qty'])->orWhere('qty_uom','=',$row['uom'])->get();*/
                    
                    /*$cekdtl1 = TransaksiDetail::where('id_transaksi','=',Input::get('id'))->get();*/
                    
                        /*if ($row['matcod']=='' && $row['no_lot']=='' && $row['kuantity_um']=='' && $row['kuantity_uom']=='' && $row['stat']=='') 
                        if ($row['matcod'] == '' && $row['no_lot'] == '') {
                            DB::table('tx_itemindetail')->insert([
                            'id_transaksi'  => Input::get('id_transaksi'),
                            'material_code' => $row['material_code'],
                            'lot_number'    => $lot->nicklot.$row['nolot'],
                            'qty_um'        => $row['qty'],
                            'qty_uom'       => $row['uom'],
                            'status'        => $row['status']
                            ]);
                            $in->InvDaily()->attach(Input::get('id'),[
                                'id'            => Input::get('id_transaksi'),
                                'company'       => $company,
                                'plant'         => $plant,
                                'material_code' => $row['material_code'],
                                'lot_number'    => $lot->nicklot.$row['nolot'],
                                'qty_um'        => $row['qty'],
                                'qty_uom'       => $row['uom'],
                                'storage'       => $storage,
                                'status'        => $row['status'],
                                'status2'       => 'I',
                                'date_ym'       => $date_in,
                                'created_at'    => date("Y-m-d H:i:s"),
                                'updated_at'    => date("Y-m-d H:i:s")
                                ]);
                        }                        
                    else 
                        DB::table('tx_itemindetail')->where('id_transaksi','=',Input::get('id'))->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['no_lot'])->where('status','=',$row['stat'])->where('qty_um','=',$row['kuantity_um'])->where('qty_uom','=',$row['kuantity_uom'])
                            ->update([
                                'id_transaksi'  => Input::get('id_transaksi'),
                                'material_code' => $row['material_code'],
                                'lot_number'    => $lot->nicklot.$row['nolot'],
                                'qty_um'        => $row['qty'],
                                'qty_uom'       => $row['uom'],
                                'status'        => $row['status']
                                ]);
                        DB::table('ss_invdaily')->where('id','=',Input::get('id'))->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['no_lot'])->where('status','=',$row['stat'])->where('qty_um','=',$row['kuantity_um'])->where('qty_uom','=',$row['kuantity_uom'])->where('storage','=',$stor)->where('status2','=','I')
                            ->update([
                                'id'            => Input::get('id_transaksi'),
                                'company'       => $company,
                                'plant'         => $plant,
                                'material_code' => $row['material_code'],
                                'lot_number'    => $lot->nicklot.$row['nolot'],
                                'qty_um'        => $row['qty'],
                                'qty_uom'       => $row['uom'],
                                'storage'       => $storage,
                                'status'        => $row['status'],
                                'status2'       => 'I',
                                'date_ym'       => $date_in,
                                'created_at'    => date("Y-m-d H:i:s"),
                                'updated_at'    => date("Y-m-d H:i:s")
                                ]);                            
                    }

                }
                return Redirect::to('/inbound/edit/'.Session::get('id_tx'));
            } */
        $id = Input::get('id');

        DB::table('tx_itemin')->where('id_transaksi','=',$id)->delete();
        DB::table('tx_itemindetail')->where('id_transaksi','=',$id)->delete();
        DB::table('ss_invdaily')->where('id','=',$id)->delete();
        $insert = array();
        foreach (Input::get('material_code') as $key => $material_code) {
            $insert[$key]['material_code'] = $material_code;
        }
        foreach (Input::get('qty') as $key => $qty) {
            $insert[$key]['qty'] = $qty;
        }
        foreach (Input::get('status') as $key => $status) {
            $insert[$key]['status'] = $status;
        }
        foreach (Input::get('nolot') as $key => $nolot) {
            $insert[$key]['nolot'] = $nolot;
        }
        foreach (Input::get('uom') as $key => $uom) {
            $insert[$key]['uom'] = $uom;
        }
        $company = Auth::user()->company;
        $plant = Auth::user()->plant;
        $storage = Input::get('storage');
        $date_in = date("Y-m-d", strtotime(Input::get('date_in'))) ;
        $id_transaksi = Input::get('id_transaksi');
        $remarks = Input::get('remarks');
        $no_srtjln = Input::get('no_suratjln');
        $created_at = Input::get('created_at');
        $in = Transaksi::create([
            'company'       => $company,
            'plant'         => $plant,
            'id_transaksi'  => $id_transaksi,
            'date_in'       => $date_in,
            'storage'       => $storage,
            'no_suratjln'   => $no_srtjln,
            'status'        => 'I',
            'remarks'       => $remarks,
            'created_at'    => $created_at,
            'user_create'   => Auth::user()->employee_code,
            'user_update'   => Auth::user()->employee_code
        ]);
        foreach ($insert as $row ) {
            //$lot_number = array(''=>'');
            $nicklot = Products::where('material_code','=',$row['material_code'])->get();
            foreach ($nicklot as $lot) {
                if ($row['status'] == 'G' or $row['status'] == 'B') {
                    
                $in->InDetail()->attach($id_transaksi,[
                    'id_transaksi'  => $id_transaksi,
                    'material_code' => $row['material_code'],
                    'lot_number'    => $lot->nicklot.$row['nolot'],
                    'qty_um'        => $row['qty'],
                    'qty_uom'       => $row['uom'],
                    'status'        => $row['status'],
                    'created_at'    => $created_at
                    ]);
                $in->InvDaily()->attach($id_transaksi,[
                    'id'            => $id_transaksi,
                    'company'       => $company,
                    'plant'         => $plant,
                    'material_code' => $row['material_code'],
                    'lot_number'    => $lot->nicklot.$row['nolot'],
                    'qty_um'        => $row['qty'],
                    'qty_uom'       => $row['uom'],
                    'storage'       => $storage,
                    'status'        => $row['status'],
                    'status2'       => 'I',
                    'date_ym'       => $date_in,
                    'created_at'    => $created_at,
                    'updated_at'    => date("Y-m-d H:i:s")
                    ]);
                }else{
                    $in->InDetail()->attach($id_transaksi,[
                        'id_transaksi'  => $id_transaksi,
                        'material_code' => $row['material_code'],
                        'lot_number'    => $lot->nicklot.$row['nolot'],
                        'qty_um'        => $row['qty'],
                        'qty_uom'       => $row['uom'],
                        'status'        => $row['status'],
                        'created_at'    => $created_at
                    ]);
                }
            }
        }
        return Redirect::to('/inbound/edit/'.Session::get('id_tx'));
    }
    public function deleteItem($idtx,$mtcd,$ltno,$status,$storage,$qty_um,$qty_uom){
        DB::table('tx_itemindetail')->where('id_transaksi','=',$idtx)->where('material_code','=',$mtcd)->where('lot_number','=',$ltno)->where('status','=',$status)->where('qty_um','=',$qty_um)->where('qty_uom','=',$qty_uom)->delete();
        DB::table('ss_invdaily')->where('id','=',$idtx)->where('material_code','=',$mtcd)->where('lot_number','=',$ltno)->where('status','=',$status)->where('storage','=',$storage)->where('qty_um','=',$qty_um)->where('qty_uom','=',$qty_uom)->delete();
        
        return Redirect::to('/inbound/edit/'.Session::get('id_tx'));
    }
    public function getDelete($id_tx){
        DB::table('tx_itemin')->where('id_transaksi','=',$id_tx)->delete();
        DB::table('tx_itemindetail')->where('id_transaksi','=',$id_tx)->delete();
        DB::table('ss_invdaily')->where('id','=',$id_tx)->delete();
        return Redirect::back();
    }
    public function getReturn(){
        $inventory = array('' => '');
        foreach(DB::table('ss_invmonthly')->get() as $row)
            foreach (Products::where('material_code','=',$row->material_code)->get() as $prd) {
                $inventory[$row->material_code] = $row->material_code." - ".$prd->material_name;
            }
        $p_bad = DB::table('tx_itemin')->join('tx_itemindetail', 'tx_itemindetail.id_transaksi', '=', 'tx_itemin.id_transaksi')->where( 'tx_itemindetail.status','=','B')->get();
        $return = DB::table('ss_invmonthly')->where('status','=','B')->where('end_qty_um','!=',0)->get();
        return View::make('inventory.return', array(
            'products'  => $inventory,
            'return' => $return    
        ));
    }
    public function getCreateReturn()
    {
        session_start();
        session_destroy();
        $storage = DB::table('cd_code')->join('ss_invmonthly', 'cd_code.code', '=', 'ss_invmonthly.storage')->where( 'ss_invmonthly.status','=','B')->where('ss_invmonthly.end_qty_um','!=',0)->distinct()->select('ss_invmonthly.storage','cd_code.code','cd_code.code_name')->get();
        return View::make('inventory.createreturn')
            ->with('warehouse',CommonCode::where('hcode','LIKE','%'.'GD'.'%')->where('code','!=','*')->get())
            ->with('pabrik',CommonCode::where('hcode','LIKE','%'.'PB'.'%')->where('code','!=','*')->get());
    }
    public function getEditReturn($no_tx)
    {
        
        $ssom = DB::table('ss_outmaster')->where('no_transaksi','=',$no_tx)->get();
        return View::make('inventory.editreturn')
                ->with('ssom',$ssom)
                ->with('warehouse',CommonCode::where('hcode','LIKE','%'.'GD'.'%')->where('code','!=','*')->get())
                ->with('pabrik',CommonCode::where('hcode','LIKE','%'.'PB'.'%')->where('code','!=','*')->where('code','!=',7003)->where('code','!=',7004)->get());
    }
    public function getReturned(){
        $inventory = array('' => '');
        foreach(DB::table('ss_invmonthly')->get() as $row)
            foreach (Products::where('material_code','=',$row->material_code)->get() as $prd) {
                $inventory[$row->material_code] = $row->material_code." - ".$prd->material_name;
            }
        $p_bad = DB::table('tx_itemin')->join('tx_itemindetail', 'tx_itemindetail.id_transaksi', '=', 'tx_itemin.id_transaksi')->where( 'tx_itemindetail.status','=','B')->get();
        $returned = DB::table('ss_outmaster')->where('status','=','R')->get();
        return View::make('inventory.returned', array(
            'products'  => $inventory,
            'returned' => $returned    
        ));
    }
    
    public function postShow()
    {
        switch(Input::get('type')):
            case 'storage':
                $m = Input::get('id');
                $list = DB::table('ss_invmonthly')->join('cd_material','cd_material.material_code','=','ss_invmonthly.material_code')->where('storage','=',Input::get('id'))->where('end_qty_um','!=',0)->where('status','=','B')->get();
                if (count($list)==0) {
                    $return = "<script>alert('Not Found a Bad Product In Warehouse!!');window.location.reload();</script>";
                }else{
                    
                foreach(DB::select(DB::raw("select distinct ss_invmonthly.material_code, cd_material.material_name, cd_material.um, cd_material.uom from ss_invmonthly join cd_material on cd_material.material_code=ss_invmonthly.material_code where status = 'B' and end_qty_um != 0 and storage='{$m}'")) as $row){
                        session_start();

                        $_SESSION['m'] = $m;

                        
                    $return .=  "";
                            }
                  }
                return $return;
                
            break;
            case 'lis':
            $m = Input::get('id');
                $return = "<table class='table table-striped responsive-utilities jambo_table bulk_action'>
                              <thead>
                                <tr class='headings'>
                                  <th class='column-title' colspan='2'>Material </th>
                                  <th class='column-title'>Lot Number</th>
                                  <th class='column-title' >Qty BAD</th>
                                </tr>
                              </thead>
                              <tbody>";
                foreach(DB::select(DB::raw("select ss_invmonthly.*, cd_material.* from ss_invmonthly join cd_material on cd_material.material_code=ss_invmonthly.material_code where status = 'B' and end_qty_um != 0 and storage='{$m}'")) as $row){
                    $return .= "<tr class='even pointer'>
                                    <td class='col-md-6' colspan='2'>
                                        <input value='$row->material_code' name='material_code[]' id='s' type='text' class='sli col-md-2' >
                                        <input value='$row->material_name' name='mater' type='text' class='col-md-6' >
                                    </td>
                                    <td class='col-md-3'>
                                        <input name='end_qty[]' class='col-md-12' type='text' value='$row->lot_number'>
                                    </td>
                                    <td class='col-md-3' colspan='2'>
                                        <input name='end_qty[]' class='col-md-6' type='text' value=''>
                                        <input name='return_qty_bag' class='col-md-6' type='text' value='$row->um'>
                                    </td>
                                </tr>
                                ";
                       // }
                  }
                
                    return $return;
            break;
             case 'destination':
                if(Input::get('dt') != ''){
                $source = Input::get('id');
                $dt = date("Ymd",strtotime(Input::get('dt')));
                 if ($source == '8001' or $source == '8002') {
                        $src = 'A';
                    }elseif ($source == '8003') {
                        $src = 'B';
                    }
                foreach(DB::select(DB::raw("select max(substr(no_transaksi,-3,3)) as max from ss_outmaster where(select max(substr(no_transaksi,-3,3)) from ss_outmaster where substr(no_transaksi,3,8)= '{$dt}' ) and substr(no_transaksi,-4,1)='{$src}' and substr(no_transaksi,3,8)= '{$dt}'")) as $row)
                    $no_transaksi = 'DO'.date('Ymd',strtotime($dt)).$src.sprintf('%03d', $row->max+1);
                    $return = "<input  type='text' style='width: 250px;'' class='form-control' readonly='readonly' name='no_transaksi' value='$no_transaksi'>";
                return $return;
                }
                else{
                    $return = "<script>alert('Date Out is empty!!');window.location.reload();</script>";
                    return $return;
                }
            break;
            case 'sk':
                    
            break;
        endswitch;    
    }
    public function postReturn() {
        switch(Input::get('type')):
            case 'lotnumber':
                $return = '<option value=""></option>';
                foreach(Inventory::where('material_code', Input::get('id'))->get() as $row)
                    //$pro = Products::where('material_code',$row->material_code)->first();
                    $return .= "<option value='$row->lot_number'>$row->lot_number</option> ";
                return $return;
            break;
            case 'material':
                //$return = '<option value=""></option>';
                foreach(Inventory::where('lot_number', Input::get('id'))->get() as $row)
                    $pro = Products::where('material_code',$row->material_code)->first();
                    //$return .= "<option disable value='$row->lot_number'>$pro->material_size</option> ";
                    $return = " <table class='table table-striped responsive-utilities jambo_table bulk_action'>
                                    <thead>
                                      <tr class='headings'>
                                        <th class='column-title'>Qty Bad Bag </th>
                                        <th class='column-title'>Qty Bad Kgs </th>
                                        <th class='column-title'>Qty Return Bag</th>
                                        <th class='column-title'>Qty Return Kgs</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                        <tr class='even pointer'>
                                            <td class='col-md-2'><input name='bad_qty_bag' value='$row->bad_qty_bag' type='text' class='col-md-12' id='bad_bag' onkeyup='myFunction()''></input></td>
                                            <td class='col-md-2'><input name='bad_qty_kgs' type='text' id='result_bad' value='$row->bad_qty_kgs' readonly='readonly' class='col-md-12'></input></td>
                                            <td class='col-md-2'><input name='return_qty_bag' class='col-md-12' type='number' max='$row->bad_qty_bag' id='return_bag' onkeyup='myFunction()'></input></td>
                                            <td class='col-md-2'><input type='text' name='return_qty_kgs' id='result_return' readonly='readonly' class='col-md-12'></input> </td>
                                            
                                        </tr>
                                    </tbody>
                                </table>
                                <input type='hidden' id='return_kg' onkeyup='myFunction()' value='$pro->material_size'>
                                <input type='hidden' id='bad_kg' onkeyup='myFunction()' value='$pro->material_size'>
                                <input type='hidden' value='$row->material_name' name='material_name'>
                                <input type='hidden' value='$row->storage' name='storage'>
                                <input type='hidden' value='$row->good_qty_bag' name='good_qty_bag'>
                                <input type='hidden' value='$row->good_qty_kgs' name='good_qty_kgs'>
                                <input type='hidden' value='$row->good_qty_bag' name='good_qty_bag'>
                                ";
                return $return;
        endswitch;    
    }
    public function postCreateReturn(){
        
        $insert = array();
        foreach (Input::get('material_code') as $key => $material_code) {
            $insert[$key]['material_code'] = $material_code;
        }
        foreach (Input::get('qty_out_um') as $key => $qty_out_um) {
            $insert[$key]['qty_out_um'] = $qty_out_um;
        }
        foreach (Input::get('qty_out_uom') as $key => $qty_out_uom) {
            $insert[$key]['qty_out_uom'] = $qty_out_uom;
        }
        foreach (Input::get('lot_number') as $key => $lot_number) {
            $insert[$key]['lot_number'] = $lot_number;
        }
        
        $company = Auth::user()->company;
        $plant = Auth::user()->plant;
        
        
        $source = Input::get('source');
        $destination = Input::get('destination');
        
        $trucking   = Input::get('trucking');
        $no_srtjln  = Input::get('no_srtjln');
        $remarks    = Input::get('remarks');
        $date_out   = date("Y-m-d",strtotime(Input::get('date_out')));
        $user_create = Auth::user()->employee_code;
        $user_update = Auth::user()->employee_code;
        
        $notx = Input::get('no_transaksi');
        $return = ReturnMaster::create([
                'company'       => $company,
                'plant'         => $plant,
                'no_transaksi'  => $notx,
                'date_out'      => $date_out,
                'status'        => 'R',
                'destination'   => $destination,
                'source'        => $source,
                'trucking'      => $trucking,
                'no_srtjln'     => $no_srtjln,
                'remarks'       => $remarks,
                'user_create'   => $user_create,
                'user_update'   => $user_update
            ]);
        foreach ($insert as $row ) {
            //$lot_number = array(''=>'');
            
            if ($row['qty_out_um'] != 0) {
                
            $return->ReturnDetail()->attach($notx,[
                'no_transaksi'     => $notx,
                'material_code' => $row['material_code'],
                'lot_number'    => $row['lot_number'],
                'qty_out_um'    => $row['qty_out_um'],
                'qty_out_uom'    => $row['qty_out_uom'],
                'status'        => 'B'
                ]);
            $return->InvDaily()->attach($notx,[
                'id'            => $notx,
                'company'       => $company,
                'plant'         => $plant,
                'material_code' => $row['material_code'],
                'lot_number'    => $row['lot_number'],
                'qty_um'        => $row['qty_out_um'],
                'qty_uom'       => $row['qty_out_uom'],
                'storage'       => $source,
                'status'        => 'B',
                'status2'       => 'O',
                'date_ym'       => $date_out,
                'created_at'    => date("Y-m-d H:i:s"),
                'updated_at'    => date("Y-m-d H:i:s")
                ]);
            }
        }
            return Redirect::to('returned');
    }
    public function postCreateReturned(){
        $no_tx = Input::get('no_transaksi');
        $storage = Input::get('storage');
        $insert = array();
        foreach (Input::get('material_code') as $key => $material_code) {
            $insert[$key]['material_code'] = $material_code;
        }
        foreach (Input::get('lot_number') as $key => $lot_number) {
            $insert[$key]['lot_number'] = $lot_number;
        }
        foreach (Input::get('qty_out_um') as $key => $qty_out_um) {
            $insert[$key]['qty_out_um'] = $qty_out_um;
        }
        foreach (Input::get('qty_out_uom') as $key => $qty_out_uom) {
            $insert[$key]['qty_out_uom'] = $qty_out_uom;
        }

        DB::table('ss_outmaster')->where('no_transaksi','=',$no_tx)->delete();
        DB::table('ss_outdtl')->where('no_transaksi','=',$no_tx)->delete();
        DB::table('ss_invdaily')->where('id','=',$no_tx)->delete();
        
        return Redirect::to('return');
    }
    public function getReport()
    {
        $startTime = strtotime(Input::get('date_start'));
        $endTime = strtotime(Input::get('date_finish'));
        $times = date("Y-m-d",$startTime);
        $etime = date("Y-m-d",$endTime);
        
        $etimes = date("Y-m",$endTime);
        $tmmon = date("Ym",$startTime);
        
        $ktg = Input::get('kategori');
        $storage = Input::get('storage');
        if ($times == '1970-01-01' and $etime == '1970-01-01') {
            Session::put('startTime',date("Y-m-d"));
            Session::put('endTime',date("Y-m-d"));
            Session::put('skr',date("Y-m-d"));
            Session::put('ktg',$ktg);
            Session::put('stor',$storage);
            Session::put('etimes',$etimes);
            Session::put('tmmon',$tmmon);
            return View::make('reports.inbound', array(
            'products'  => Products::all(),
            'storage'   => CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get(),
            'transaksi' => DB::select(DB::raw("select (select sum(c.begin_qty_um) from ss_invmonthly c 
                where material_code = b.material_code and yymm='201606' )begin_qty,
                b.material_code,b.material_name,
                (select sum(qty_um) from ss_invdaily 
                    where date_ym = CURDATE()
                    and material_code=a.material_code 
                    and status='G' and status2='I') as i,
               (select sum(qty_um) from ss_invdaily 
                    where date_ym = CURDATE()
                    and material_code=a.material_code 
                    and status='B' and status2='I') as ib,
                (select sum(qty_um) from ss_invdaily 
                    where date_ym = CURDATE()
                    and material_code=a.material_code 
                    and status='G' and status2='O') as dn,
                (select sum(qty_um) from ss_invdaily 
                    where date_ym = CURDATE()
                    and material_code=a.material_code 
                    and status='B' and status2='O') as rtn
                from cd_material b
                left outer join ss_invdaily a on a.material_code = b.material_code
                where b.material_ktg = '' 
                group by b.material_code
               order by a.date_ym asc")),            
            'startTime' => $startTime,
            'endTime'   => $endTime
        ));
        }else{
            Session::put('startTime',$times);
            Session::put('endTime',$etime);
            Session::put('skr',$etime);
            Session::put('ktg',$ktg);
            Session::put('stor',$storage);
            Session::put('etimes',$etimes);
            Session::put('tmmon',$tmmon);
            return View::make('reports.inbound', array(
                'products'  => Products::all(),
                'storage'   => CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get(),
                'transaksi' => DB::select(DB::raw("select (select sum(c.begin_qty_uom) from ss_invmonthly c 
                                    where material_code = b.material_code and yymm='{$tmmon}' and status = 'G' and storage='{$storage}')begin_qty_uom_g,
                                    (select sum(c.begin_qty_uom) from ss_invmonthly c 
                                    where material_code = b.material_code and yymm='{$tmmon}' and status = 'B' and storage='{$storage}')begin_qty_uom_b,
                                    b.material_code,b.material_name,
                                    (select sum(qty_uom) from ss_invdaily 
                                        where date_ym between '{$times}' and '{$etime}'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='G' and status2='I') as i,
                                   (select sum(qty_uom) from ss_invdaily 
                                        where date_ym between '{$times}' and '{$etime}'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='B' and status2='I') as ib,
                                    (select sum(qty_uom) from ss_invdaily 
                                        where date_ym > '{$etime}'
                                        and date_ym <= date_ym
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='G' and status2='O') as dn,
                                    (select sum(qty_uom) from ss_invdaily 
                                        where date_ym LIKE '{$etimes}%'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='G' and status2='O') as dn_l,
                                    (select sum(qty_uom) from ss_invdaily 
                                        where date_ym <= '{$etime}'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='G' and status2='I') as i_l,
                                    (select sum(qty_uom) from ss_invdaily 
                                        where date_ym LIKE '{$etimes}%'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='B' and status2='O') as rtn,
                                    (select sum(qty_uom) from ss_invdaily 
                                        where date_ym <= '{$etimes}'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='B' and status2='O') as rtn_l
                                    from cd_material b
                                    left outer join ss_invdaily a on a.material_code = b.material_code
                                    where b.material_ktg = '{$ktg}'
                                    group by b.material_code
                                   order by a.date_ym asc")),
                'startTime' => $startTime,
                'endTime'   => $endTime
            ));
        }       
    }
    public function getReportDaily($det)
    {
        $startTime = strtotime(Session::get('startTime'));
        $endTime = strtotime(Session::get('endTime'));
        $times = date("Y-m-d",$startTime);
        $etime = date("Y-m-d",$endTime);
        $ktg = Session::get('ktg');
        Session::put('startTime',$times);
        Session::put('endTime',$etime);
        Session::put('skr',$det);
        return View::make('reports.inbound', array(
            'products'  => Products::all(),
            'storage'   => CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get(),
            'transaksi' => DB::select(DB::raw("select distinct a.material_code, a.lot_number, mt.material_name,mt.material_size, 
                            (select count(material_code) 
                                from ss_invdaily 
                            where material_code = a.material_code and status=a.status and status2=a.status2) as jumlah,
                            (select sum(qty_um) from ss_invdaily 
                                where date_ym < '{$det}' 
                                and material_code=a.material_code
                                and mt.material_ktg='{$ktg}' 
                                and lot_number = a.lot_number
                                and status='G' and status2='I') as sisa,
                            (select sum(qty_um) from ss_invdaily 
                                where date_ym = '{$det}'
                                and material_code=a.material_code 
                                and mt.material_ktg='{$ktg}'
                                and lot_number = a.lot_number
                                and status='G' and status2='I') as i,
                            (select sum(qty_um) from ss_invdaily 
                                where date_ym = '{$det}'
                                and material_code=a.material_code 
                                and mt.material_ktg='{$ktg}'
                                and lot_number = a.lot_number
                                and status='B' and status2='I') as i_b,
                            (select sum(qty_um) from ss_invdaily 
                                where date_ym = '{$det}'
                                and material_code=a.material_code 
                                and mt.material_ktg='{$ktg}'
                                and lot_number = a.lot_number 
                                and status='G' and status2='O') as jum_out_n,
                            (select sum(qty_um) from ss_invdaily 
                                where date_ym < '{$det}'
                                and material_code=a.material_code 
                                and mt.material_ktg='{$ktg}'
                                and lot_number = a.lot_number 
                                and status='G' and status2='O') as jum_out_l 
                        from ss_invdaily a 
                        join cd_material mt on a.material_code = mt.material_code
                        where a.status2='I' and mt.material_ktg='{$ktg}' order by a.date_ym DESC")),
            'startTime' => $startTime,
            'endTime'   => $endTime
        ));
    }
    public function exportexcel()
    {
        $times = Session::get('startTime');
        $etime = Session::get('endTime');
        $ktg   = Session::get('ktg');
        $kat = DB::table('cd_code')->where('code','=',$ktg)->first();
        $storage = Session::get('stor');
        $etimes = Session::get('etimes');
        $tmmon = Session::get('tmmon');
        // Library phpExcel
        require_once (app_path()."/plugins/phpExcel/PHPExcel.php");
        require_once (app_path()."/plugins/phpExcel/PHPExcel/Writer/Excel2007.php");

        // Buat object baru
        $object = new PHPExcel();

        // Pilih sheet active
        $sheet = $object->getActiveSheet();
        $styleContent = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => '#333'),
                ),
            ),
        );
        $styleTitle = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => '#333'),
                ),
            ),
            'font' => array(
                'bold' => true,
            )
        );
        // Pemformatan sederhana (lebih lengkap : cek dokumentasi phpExcel)
        $sheet->getDefaultRowDimension()->setRowHeight(15);
        $sheet->setAutoFilter('A3:M3');
        $sheet->freezePane('A4');
        $sheet->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A2:M3')->getAlignment()->setWrapText(true);
        $sheet->getStyle('C')->getAlignment()->setWrapText(true);
        

        // Ubah ukuran lebar cell C agar menyesuaikan content
        $sheet->getColumnDimension('A')->setWidth(6);
        $sheet->getColumnDimension('B')->setWidth(12);
        $sheet->getColumnDimension('C')->setWidth(24);
        $sheet->getColumnDimension('D')->setWidth(10);
        $sheet->getColumnDimension('E')->setWidth(12);
        $sheet->getColumnDimension('F')->setWidth(10);
        $sheet->getColumnDimension('G')->setWidth(12);
        $sheet->getColumnDimension('H')->setWidth(10);
        $sheet->getColumnDimension('I')->setWidth(10);
        $sheet->getColumnDimension('J')->setWidth(10);
        $sheet->getColumnDimension('K')->setWidth(10);
        $sheet->getColumnDimension('L')->setWidth(45);
        $sheet->getColumnDimension('M')->setWidth(45);

        // Tulis judul di B2
        $sheet->setCellValue('A1', $kat->code_name.' '.date("d M Y"));
        
        // Tulis header tabel di B4 sampai H4
        $sheet->mergeCells('A1:C1')->mergeCells('A2:A3')->mergeCells('B2:B3')->mergeCells('C2:C3')->mergeCells('D2:D3')->mergeCells('E2:F2')->mergeCells('A2:A3')->mergeCells('G2:G3')->mergeCells('H2:H3')->mergeCells('I2:I3')->mergeCells('J2:J3')->mergeCells('K2:K3')->mergeCells('L2:L3')->mergeCells('M2:M3');
        $sheet->setCellValue('A2', 'NO')
              ->setCellValue('B2', 'Product Code')
              ->setCellValue('C2', 'Product Name')
              ->setCellValue('D2', 'SAP (KG)-'.date("d M",strtotime($etime)))
              ->setCellValue('E2', 'Actual')
              ->setCellValue('E3', 'Good')
              ->setCellValue('F3', 'Damage')
              ->setCellValue('G2', 'Barang Reject Pabrik & Kurang kirim')
              ->setCellValue('H2', 'DO Tgl '.date("d M"))
              ->setCellValue('J2', 'Total')
              ->setCellValue('K2', 'Selisih')
              ->setCellValue('L2', 'Remarks')
              ->setCellValue('M2', 'Action Plan')
              ;
        $sheet->getStyle('A2:M3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('8ac52a');
        $sheet->getStyle('A1:C1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('8ac52a');
        $sheet->getStyle('A2:M3')->applyFromArray($styleTitle);

        
        $data = DB::select(DB::raw("select (select sum(c.begin_qty_uom) from ss_invmonthly c 
                                    where material_code = b.material_code and yymm='{$tmmon}' and status = 'G' and storage='{$storage}')begin_qty_uom_g,
                                    (select sum(c.begin_qty_uom) from ss_invmonthly c 
                                    where material_code = b.material_code and yymm='{$tmmon}' and status = 'B' and storage='{$storage}')begin_qty_uom_b,
                                    b.material_code,b.material_name,
                                    (select sum(qty_uom) from ss_invdaily 
                                        where date_ym between '{$times}' and '{$etime}'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='G' and status2='I') as i,
                                   (select sum(qty_uom) from ss_invdaily 
                                        where date_ym between '{$times}' and '{$etime}'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='B' and status2='I') as ib,
                                    (select sum(qty_uom) from ss_invdaily 
                                        where date_ym > '{$etime}'
                                        and date_ym <= date_ym
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='G' and status2='O') as dn,
                                    (select sum(qty_uom) from ss_invdaily 
                                        where date_ym LIKE '{$etimes}%'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='G' and status2='O') as dn_l,
                                    (select sum(qty_uom) from ss_invdaily 
                                        where date_ym <= '{$etime}'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='G' and status2='I') as i_l,
                                    (select sum(qty_uom) from ss_invdaily 
                                        where date_ym LIKE '{$etimes}%'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='B' and status2='O') as rtn,
                                    (select sum(qty_uom) from ss_invdaily 
                                        where date_ym <= '{$etimes}'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='B' and status2='O') as rtn_l
                                    from cd_material b
                                    left outer join ss_invdaily a on a.material_code = b.material_code
                                    where b.material_ktg = '{$ktg}'
                                    group by b.material_code
                                   order by a.date_ym asc"));
        // Tulis data, mulai dari BARIS KE-5 (karena 1-4 diisi judul)
        $i = 4;
        $number = 1;
        foreach ($data as $row) {
            $sheet->setCellValue('A'.$i, $number++);
            $sheet->setCellValue('B'.$i, $row->material_code);
            $sheet->setCellValue('C'.$i, $row->material_name);
            $sheet->setCellValue('D'.$i, '');
            $sheet->setCellValue('E'.$i, ($row->i + $row->begin_qty_uom_g) - $row->dn_l);
            $sheet->setCellValue('F'.$i, ($row->ib + $row->begin_qty_uom_b) - $row->rtn);
            $sheet->setCellValue('G'.$i, $row->rtn);
            $sheet->setCellValue('H'.$i, $row->dn);
            $sheet->setCellValue('J'.$i, (($row->i + $row->begin_qty_uom_g) - $row->dn_l) + (($row->ib + $row->begin_qty_uom_b) - $row->rtn) + $row->rtn + $row->dn);
            $sheet->setCellValue('K'.$i, '');
            $sheet->setCellValue('L'.$i, '');
            $sheet->setCellValue('M'.$i, '');
            
            $sheet->getStyle('A'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('B'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('C'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('D'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('E'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('F'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('G'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('H'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('I'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('J'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('K'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('L'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('M'.$i)->applyFromArray($styleContent);
            
            // iterasi i agar ganti baris
            $i++;
        }

        // Beri nama sheet
        $st = DB::table('cd_code')->where('code','=',$storage)->first();
        $sheet->setTitle("GLS-".$st->code_name."_".date("d M Y"));
        
        // Pilih sheet yang akan aktif
        $object->setActiveSheetIndex(0);
        
        // Output
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Rekonsel Stok Opname GLS ('.date("d M Y").').xlsx"'); // beri nama file
        header('Cache-Control: max-age=0');
        $objWriter = PHPExcel_IOFactory::createWriter($object, 'Excel2007');
        $objWriter->save('php://output');
    }
    public function stok(){
        $show = DB::select(DB::raw("select distinct a.lot_number,a.material_code,mt.material_name, 
                                    (select count(material_code) from ss_invdaily where material_code = a.material_code) as jumlah,
                                    (select sum(qty_um) from ss_invdaily 
                                        where date_ym <= date('Y-m-d')
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='G' and status2='I') as i,
                                   (select sum(qty_um) from ss_invdaily 
                                        where date_ym <= '{$etime}'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='B' and status2='I') as ib,
                                    (select sum(qty_um) from ss_invdaily 
                                        where date_ym > '{$etime}'
                                        and date_ym = date_ym
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='G' and status2='O') as dn,
                                    (select sum(qty_um) from ss_invdaily 
                                        where date_ym <= '{$etime}'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='G' and status2='O') as dn_l,
                                    (select sum(qty_um) from ss_invdaily 
                                        where date_ym between '{$times}' and '{$etime}'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='B' and status2='O') as rtn,
                                    (select sum(qty_um) from ss_invdaily 
                                        where date_ym <= '{$etime}'
                                        and material_code=a.material_code 
                                        and a.storage = '{$storage}'
                                        and status='B' and status2='O') as rtn_l from ss_invdaily a left join cd_material mt on mt.material_code=a.material_code  order by a.material_code"));
        return View::make('reports.stok')
                ->with('transaksi',$show)
                ->with('storage', CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get());
    }
    public function stokMinus()
    {
        $storage = Input::get('storage');
        $sales = Input::get('sales');
        if ($sales == '' and $storage == '') {
        Session::put('ktg',$sales);
        Session::put('stor',$storage);
        return View::make('reports.stok_minus')
            ->with('storage', CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get())
            ->with('item', DB::select(DB::raw("select (select count(material_code) from tx_itemindetail where material_code = txi.material_code) as jumlah, txi.*, mt.material_name 
                from tx_itemindetail txi
                left join cd_material mt on mt.material_code=txi.material_code  
                left join tx_itemin it on it.id_transaksi= txi.id_transaksi
                where txi.`status`='S'
                order by txi.material_code")));
        }else{
            Session::put('ktg',$sales);
            Session::put('stor',$storage);
            return View::make('reports.stok_minus')
            ->with('storage', CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get())
            ->with('item', DB::select(DB::raw("select (select count(material_code) from tx_itemindetail where material_code = txi.material_code) as jumlah, txi.*, mt.material_name, mt.material_ktg
                from tx_itemindetail txi
                left join cd_material mt on mt.material_code=txi.material_code  
                left join tx_itemin it on it.id_transaksi= txi.id_transaksi
                where txi.`status`='S' and mt.material_ktg = '{$sales}' and it.storage = '{$storage}'
                order by txi.material_code")));
        }
    }
	public function exportShortage(){
        $storage = Session::get('stor');
        $sales = Session::get('ktg');
        // Library phpExcel
        require_once (app_path()."/plugins/phpExcel/PHPExcel.php");
        require_once (app_path()."/plugins/phpExcel/PHPExcel/Writer/Excel2007.php");

        // Buat object baru
        $object = new PHPExcel();

        // Pilih sheet active
        $sheet = $object->getActiveSheet();
        $styleContent = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => '#333'),
                ),
            ),
        );
        $styleTitle = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => '#333'),
                ),
            ),
            'font' => array(
                'bold' => true,
            )
        );
        // Pemformatan sederhana (lebih lengkap : cek dokumentasi phpExcel)
        $sheet->getDefaultRowDimension()->setRowHeight(15);
        $sheet->setAutoFilter('A2:F2');
        $sheet->freezePane('A3');
        $sheet->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        //$sheet->getStyle('A2:M3')->getAlignment()->setWrapText(true);
        $sheet->getStyle('C')->getAlignment()->setWrapText(true);
        

        // Ubah ukuran lebar cell C agar menyesuaikan content
        $sheet->getColumnDimension('A')->setWidth(9);
        $sheet->getColumnDimension('B')->setWidth(40);
        $sheet->getColumnDimension('C')->setWidth(15);
        $sheet->getColumnDimension('D')->setWidth(10);
        $sheet->getColumnDimension('E')->setWidth(10);
        $sheet->getColumnDimension('F')->setWidth(15);

        // Tulis judul di B2
        //$sheet->setCellValue('A1', $kat->code_name.' '.date("d M Y"));
        
        // Tulis header tabel di B4 sampai H4
        //$sheet->mergeCells('A1:C1')->mergeCells('A2:A3')->mergeCells('B2:B3')->mergeCells('C2:C3')->mergeCells('D2:D3')->mergeCells('E2:F2')->mergeCells('A2:A3')->mergeCells('G2:G3')->mergeCells('H2:H3')->mergeCells('I2:I3')->mergeCells('J2:J3')->mergeCells('K2:K3')->mergeCells('L2:L3')->mergeCells('M2:M3');
        $sheet->setCellValue('A2', 'Code')
              ->setCellValue('B2', 'Product Name')
              ->setCellValue('C2', 'Lot Number')
              ->setCellValue('D2', 'Shortage (KG)')
              ->setCellValue('E2', 'Shortage (BAG)')
              ->setCellValue('F2', 'Warehouse')
              ;
        /*$sheet->getStyle('A2:M3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('8ac52a');
        $sheet->getStyle('A1:C1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('8ac52a');
        $sheet->getStyle('A2:M3')->applyFromArray($styleTitle);*/

        if ($sales == '' and $storage == '') {
            $data = DB::select(DB::raw("select (select count(material_code) from tx_itemindetail where material_code = txi.material_code) as jumlah, txi.*, mt.material_name,cc.*, mt.material_ktg 
                from tx_itemindetail txi
                left join cd_material mt on mt.material_code=txi.material_code  
                left join tx_itemin it on it.id_transaksi= txi.id_transaksi
                left join cd_code cc on cc.code = it.storage
                where txi.`status`='S'
                order by txi.material_code"));
        }else{
            $data = DB::select(DB::raw("select (select count(material_code) from tx_itemindetail where material_code = txi.material_code) as jumlah, txi.*, mt.material_name, mt.material_ktg, cc.*
                from tx_itemindetail txi
                left join cd_material mt on mt.material_code=txi.material_code  
                left join tx_itemin it on it.id_transaksi= txi.id_transaksi
                left join cd_code cc on cc.code = it.storage
                where txi.`status`='S' and mt.material_ktg = '{$sales}' and it.storage = '{$storage}'
                order by txi.material_code"));
        }
        // Tulis data, mulai dari BARIS KE-5 (karena 1-4 diisi judul)
        $i = 4;
        $number = 1;
        foreach ($data as $row) {
            $sheet->setCellValue('A'.$i, $row->material_code);
            $sheet->setCellValue('B'.$i, $row->material_name);
            $sheet->setCellValue('C'.$i, $row->lot_number);
            $sheet->setCellValue('D'.$i, $row->qty_um);
            $sheet->setCellValue('E'.$i, $row->qty_uom);
            $sheet->setCellValue('F'.$i, $row->code_name);
           
            
            $sheet->getStyle('A'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('B'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('C'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('D'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('E'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('F'.$i)->applyFromArray($styleContent);
            
            
            // iterasi i agar ganti baris
            $i++;
        }

        // Beri nama sheet
        $sheet->setTitle("Shortage Product");
        
        // Pilih sheet yang akan aktif
        $object->setActiveSheetIndex(0);
        
        // Output
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Shortage Product.xlsx"'); // beri nama file
        header('Cache-Control: max-age=0');
        $objWriter = PHPExcel_IOFactory::createWriter($object, 'Excel2007');
        $objWriter->save('php://output');
    }
    public function stokDaily()
    {
        $tgl = date("Y-m-d",strtotime(Input::get('tgl')));
        $sales = Input::get('sales');
        $storage = Input::get('storage');
        $ktg= Auth::user()->emp_ktg;
        $now = date("Ym");
        if ($tgl == '1970-01-01' or $sales == '' or $storage == '') {
            Session::put('tgl',date("Y-m-d"));
            Session::put('ktg',$sales);
            Session::put('stor',$storage);
            $dt = date("Y-m-d");
            $dtstr = substr($dt, 0,7);
            $now = date("Ym");
            return View::make('reports.stok')
                    ->with('transaksi', DB::select(DB::raw("select im.*, mt.material_name,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}') out_qty_um_gl,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}') out_qty_uom_gl,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') out_qty_um_gn,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') out_qty_uom_gn,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') in_qty_um_gn,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') in_qty_uom_gn,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}' ) in_qty_um_gl,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}' ) in_qty_uom_gl
                            from ss_invmonthly im
                            left join cd_material mt on mt.material_code = im.material_code
                            where im.`storage`='{$storage}'  and mt.material_ktg='{$sales}' and yymm='{$now}'")))
                    ->with('storage', DB::table('cd_code')->where('hcode','LIKE','%GD%')->where('code','!=','*')->get());
        }else{
            Session::put('tgl',$tgl);
            Session::put('ktg',$sales);
            Session::put('stor',$storage);
            $dt = $tgl;
            $dtstr = substr($dt, 0,7);
            $now = date("Ym", strtotime($tgl));
            return View::make('reports.stok')
                    ->with('transaksi', DB::select(DB::raw("select im.*, mt.material_name,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}') out_qty_um_gl,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}') out_qty_uom_gl,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') out_qty_um_gn,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') out_qty_uom_gn,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') in_qty_um_gn,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') in_qty_uom_gn,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}' ) in_qty_um_gl,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}' ) in_qty_uom_gl
                            from ss_invmonthly im
                            left join cd_material mt on mt.material_code = im.material_code
                            where im.`storage`='{$storage}'  and mt.material_ktg='{$sales}' and yymm='{$now}'")))
                    ->with('storage', DB::table('cd_code')->where('hcode','LIKE','%GD%')->where('code','!=','*')->get());
        }
    }
    public function stokDailyExcel(){
        $dt = Session::get('tgl');
        $dtstr = substr($dt, 0,7);
        $now = date("Ym", strtotime($dt));
        $sales = Session::get('ktg');
        $storage = Session::get('stor');
        // Library phpExcel
        require_once (app_path()."/plugins/phpExcel/PHPExcel.php");
        require_once (app_path()."/plugins/phpExcel/PHPExcel/Writer/Excel2007.php");

        // Buat object baru
        $object = new PHPExcel();

        // Pilih sheet active
        $sheet = $object->getActiveSheet();
        $styleContent1 = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => '#333'),
                ),
            ),
            'fill' => array(
                'type' => PHPExcel_Style_Fill::FILL_SOLID,
                'color' => array('rgb' => 'FF3737')
            )
        );
        $styleContent = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => '#333'),
                ),
            ),
        );
        $styleTitle = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => '#333'),
                ),
            ),
            'font' => array(
                'bold' => true,
            )
        );
        // Pemformatan sederhana (lebih lengkap : cek dokumentasi phpExcel)
        $sheet->getDefaultRowDimension()->setRowHeight(15);
        $sheet->freezePane('A6');
        $sheet->setAutoFilter('A5:N5');
        $sheet->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        
        // Ubah ukuran lebar cell C agar menyesuaikan content
        $sheet->getColumnDimension('A')->setWidth(5);
        $sheet->getColumnDimension('B')->setWidth(8);
        $sheet->getColumnDimension('C')->setWidth(28);
        $sheet->getColumnDimension('D')->setWidth(20);
        $sheet->getColumnDimension('E')->setWidth(11);
        $sheet->getColumnDimension('F')->setWidth(11);
        $sheet->getColumnDimension('G')->setWidth(11);
        $sheet->getColumnDimension('H')->setWidth(11);
        $sheet->getColumnDimension('I')->setWidth(11);
        $sheet->getColumnDimension('J')->setWidth(11);
        $sheet->getColumnDimension('K')->setWidth(11);
        $sheet->getColumnDimension('L')->setWidth(11);
        $sheet->getColumnDimension('M')->setWidth(11);
        $sheet->getColumnDimension('N')->setWidth(11);

        // Tulis header tabel di B4 sampai H4
        $sheet->mergeCells('A2:A4')->mergeCells('B2:B4')->mergeCells('C2:C4')->mergeCells('D2:D4')->mergeCells('E2:H2')->mergeCells('E3:F3')->mergeCells('G3:H3')->mergeCells('I2:J3')->mergeCells('K2:L3')->mergeCells('M2:N3');
        $sheet->setCellValue('A2', 'No')
              ->setCellValue('B2', 'Code')
              ->setCellValue('C2', 'Product Name')
              ->setCellValue('D2', 'Lot Number')
              ->setCellValue('E2', 'Quantity')
              ->setCellValue('E3', 'Good')
              ->setCellValue('E4', 'BAG')
              ->setCellValue('F4', 'Kgs')
              ->setCellValue('G3', 'Demage')
              ->setCellValue('G4', 'BAG / EA')
              ->setCellValue('H4', 'Kgs')
              ->setCellValue('I2', 'DO')
              ->setCellValue('I4', 'BAG / EA')
              ->setCellValue('J4', 'Kgs')
              ->setCellValue('K2', 'STO')
              ->setCellValue('K4', 'BAG / EA')
              ->setCellValue('L4', 'Kgs')
              ->setCellValue('M2', 'Result')
              ->setCellValue('M4', 'BAG / EA')
              ->setCellValue('N4', 'Kgs')
              ;
        $sheet->getStyle('A2:N4')->applyFromArray($styleTitle);

        if ($dt == '1970-01-01' or $sales == '' or $storage == '') {
            $data = DB::select(DB::raw("select im.*, mt.material_name,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}') out_qty_um_gl,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}') out_qty_uom_gl,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') out_qty_um_gn,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') out_qty_uom_gn,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') in_qty_um_gn,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') in_qty_uom_gn,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}' ) in_qty_um_gl,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}' ) in_qty_uom_gl
                            from ss_invmonthly im
                            left join cd_material mt on mt.material_code = im.material_code
                            where im.`storage`='{$storage}'  and mt.material_ktg='{$sales}' and yymm='{$now}'"));
        }else{
            $data = DB::select(DB::raw("select im.*, mt.material_name,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}') out_qty_um_gl,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}') out_qty_uom_gl,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') out_qty_um_gn,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='O' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') out_qty_uom_gn,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') in_qty_um_gn,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym = '{$dt}' and storage ='{$storage}') in_qty_uom_gn,
                            (select sum(qty_um) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}' ) in_qty_um_gl,
                            (select sum(qty_uom) from ss_invdaily where lot_number = im.lot_number and material_code=im.material_code and status2='I' 
                            and status=im.status and date_ym < '{$dt}' and date_ym like '%{$dtstr}%' and storage ='{$storage}' ) in_qty_uom_gl
                            from ss_invmonthly im
                            left join cd_material mt on mt.material_code = im.material_code
                            where im.`storage`='{$storage}'  and mt.material_ktg='{$sales}' and yymm='{$now}'"));
        }
        // Tulis data, mulai dari BARIS KE-5 (karena 1-4 diisi judul)
        $i = 6;
        $number = 1;
        foreach ($data as $row) {
            if ($row->status == 'G') {
                $sheet->setCellValue('A'.$i, '');
                $sheet->setCellValue('B'.$i, $row->material_code);
                $sheet->setCellValue('C'.$i, $row->material_name);
                $sheet->setCellValue('D'.$i, $row->lot_number);
                $sheet->setCellValue('E'.$i, ($row->begin_qty_um + $row->in_qty_um_gl) - $row->out_qty_um_gl);
                $sheet->setCellValue('F'.$i, ($row->begin_qty_uom + $row->in_qty_uom_gl) - $row->out_qty_uom_gl);
                $sheet->setCellValue('G'.$i, '-');
                $sheet->setCellValue('H'.$i, '-');
                $sheet->setCellValue('I'.$i, $row->out_qty_um_gn);
                $sheet->setCellValue('J'.$i, $row->out_qty_uom_gn);
                $sheet->setCellValue('K'.$i, $row->in_qty_um_gn);
                $sheet->setCellValue('L'.$i, $row->in_qty_uom_gn);
                $sheet->setCellValue('M'.$i, ((($row->begin_qty_um + $row->in_qty_um_gl) - $row->out_qty_um_gl) - $row->out_qty_um_gn) + $row->in_qty_um_gn);
                $sheet->setCellValue('N'.$i, ((($row->begin_qty_uom + $row->in_qty_uom_gl) - $row->out_qty_uom_gl) - $row->out_qty_uom_gn)+ $row->in_qty_uom_gn);
            }else{
                $sheet->setCellValue('A'.$i, '');
                $sheet->setCellValue('B'.$i, $row->material_code);
                $sheet->setCellValue('C'.$i, $row->material_name);
                $sheet->setCellValue('D'.$i, $row->lot_number);
                $sheet->setCellValue('E'.$i, '-');
                $sheet->setCellValue('F'.$i, '-');
                $sheet->setCellValue('G'.$i, ($row->begin_qty_um + $row->in_qty_um_gl) - $row->out_qty_um_gl);
                $sheet->setCellValue('H'.$i, ($row->begin_qty_uom + $row->in_qty_uom_gl) - $row->out_qty_uom_gl);
                $sheet->setCellValue('I'.$i, $row->out_qty_um_gn);
                $sheet->setCellValue('J'.$i, $row->out_qty_uom_gn);
                $sheet->setCellValue('K'.$i, $row->in_qty_um_gn);
                $sheet->setCellValue('L'.$i, $row->in_qty_uom_gn);
                $sheet->setCellValue('M'.$i, ((($row->begin_qty_um + $row->in_qty_um_gl) - $row->out_qty_um_gl) - $row->out_qty_um_gn) + $row->in_qty_um_gn);
                $sheet->setCellValue('N'.$i, ((($row->begin_qty_uom + $row->in_qty_uom_gl) - $row->out_qty_uom_gl) - $row->out_qty_uom_gn)+ $row->in_qty_uom_gn);
            }
            
            
            if ($row->status == 'G') {
                
                $sheet->getStyle('A'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('B'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('C'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('D'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('E'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('F'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('G'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('H'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('I'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('J'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('K'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('L'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('M'.$i)->applyFromArray($styleContent);
                $sheet->getStyle('N'.$i)->applyFromArray($styleContent);
            }else{
                $sheet->getStyle('A'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('B'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('C'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('D'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('E'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('F'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('G'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('H'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('I'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('J'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('K'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('L'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('M'.$i)->applyFromArray($styleContent1);
                $sheet->getStyle('N'.$i)->applyFromArray($styleContent1);
            }
            
            
            // iterasi i agar ganti baris
            $i++;
        }
        if ($sales == 'B2B01') {
            $nm = 'Feed';
        }elseif ($sales =='B2B02') {
            $nm = 'Food';
        }elseif ($sales == 'B2C01') {
            $nm = 'Masita';
        }
        if ($storage == 8001) {
            $wh = 'Cikarang';
        }elseif ($storage == 8002) {
            $wh = 'Cakung';
        }elseif ($storage == 8003) {
            $wh = 'Surabaya';
        }
        // Beri nama sheet
        $sheet->setTitle(date("d-M-Y",strtotime($dt)));
        
        // Pilih sheet yang akan aktif
        $object->setActiveSheetIndex(0);
        
        // Output
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Stok '.$nm.' '.$wh.' Date '.date("d-M-Y",strtotime($dt)).'.xlsx"'); // beri nama file
        header('Cache-Control: max-age=0');
        $objWriter = PHPExcel_IOFactory::createWriter($object, 'Excel2007');
        $objWriter->save('php://output');
    
    }
    public function moving(){
        return View::make('inventory.moving');
    }
    public function juli(){
        $sales = Input::get('sales');
        $storage = Input::get('storage');
        

        if ($sales =='' or $storage =='') {
            Session::put('ktg',$sales);
            Session::put('stor',$storage);
        return View::make('inventory.juli')
            ->with('stok', DB::select(DB::raw("select im.yymm, im.status, mt.material_size,im.material_code, im.lot_number, im.begin_qty_um, im.in_qty_um, im.out_qty_um, im.end_qty_um,im.storage,
                (select  sum(qty_um) 
                from ss_invdaily where material_code =  im.material_code and lot_number = im.lot_number 
                and storage=im.storage and DATE_FORMAT(date_ym , '%Y%m') = '201608' and status=im.status and status2='O')sm_out,
                (select  sum(qty_um) 
                from ss_invdaily where material_code =  im.material_code and lot_number = im.lot_number 
                and storage=im.storage and DATE_FORMAT(date_ym ,'%Y%m') = '201608' and status=im.status and status2='I')sm_in
                from ss_invmonthly im
                left join cd_material mt on mt.material_code = im.material_code
                where yymm ='201607'")))
            ->with('storage', DB::table('cd_code')->where('hcode','LIKE','%GD%')->where('code','!=','*')->get());
        }else{
            Session::put('ktg',$sales);
            Session::put('stor',$storage);
            return View::make('inventory.juli')
            ->with('stok', DB::select(DB::raw("select im.yymm,im.status, mt.material_size,im.material_code, im.lot_number, im.begin_qty_um, im.in_qty_um, im.out_qty_um, im.end_qty_um,im.storage,
                (select  sum(qty_um) 
                from ss_invdaily where material_code =  im.material_code and lot_number = im.lot_number 
                and storage=im.storage and DATE_FORMAT(date_ym , '%Y%m') = '201608' and status=im.status and status2='O')sm_out,
                (select  sum(qty_um) 
                from ss_invdaily where material_code =  im.material_code and lot_number = im.lot_number 
                and storage=im.storage and DATE_FORMAT(date_ym ,'%Y%m') = '201608' and status=im.status and status2='I')sm_in
                from ss_invmonthly im
                left join cd_material mt on mt.material_code = im.material_code
                where yymm ='201607' and mt.material_ktg ='{$sales}' and im.storage ='{$storage}'")))
            ->with('storage', DB::table('cd_code')->where('hcode','LIKE','%GD%')->where('code','!=','*')->get());
        }
    }
    public function update_juli(){
        
        $insert = array();
        foreach (Input::get('matcod') as $key => $matcod) {
            $insert[$key]['matcod'] = $matcod;
        }
        foreach (Input::get('lotno') as $key => $lotno) {
            $insert[$key]['lotno'] = $lotno;
        }
        foreach (Input::get('matsize') as $key => $matsize) {
            $insert[$key]['matsize'] = $matsize;
        }
        foreach (Input::get('storage') as $key => $storage) {
            $insert[$key]['storage'] = $storage;
        }
        foreach (Input::get('status') as $key => $status) {
            $insert[$key]['status'] = $status;
        }
        foreach (Input::get('bgnum') as $key => $bgnum) {
            $insert[$key]['bgnum'] = $bgnum;
        }
        foreach (Input::get('inum') as $key => $inum) {
            $insert[$key]['inum'] = $inum;
        }
        foreach (Input::get('outum') as $key => $outum) {
            $insert[$key]['outum'] = $outum;
        }
        foreach (Input::get('endum') as $key => $endum) {
            $insert[$key]['endum'] = $endum;
        }
        foreach (Input::get('yymm') as $key => $yymm) {
            $insert[$key]['yymm'] = $yymm;
        }
        
        foreach ($insert as $row) {
            DB::table('ss_invmonthly')->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['lotno'])->where('storage','=',$row['storage'])->where('status','=',$row['status'])->where('yymm','=',$row['yymm'])->update([
                    'end_qty_um'    => $row['endum'],
                    'end_qty_uom'   => $row['endum']*$row['matsize']
                    ]);
            return Redirect::back();
        }
    }
    public function move(){
        
        $insert = array();
        foreach (Input::get('mtcd') as $key => $mtcd) {
            $insert[$key]['mtcd'] = $mtcd;
        }
        foreach (Input::get('lotno') as $key => $lotno) {
            $insert[$key]['lotno'] = $lotno;
        }
        foreach (Input::get('qty') as $key => $qty) {
            $insert[$key]['qty'] = $qty;
        }
        foreach (Input::get('storage') as $key => $storage) {
            $insert[$key]['storage'] = $storage;
        }
    }
}