<?php
Route::get('add', 'InventoryController@add' );
Route::get('sku',function(){
	return View::make('inventory.sku');
});
Route::get('auto',function(){
	return View::make('inventory.auto');
});
Route::get('data',function(){
	return View::make('item-data.php');
});
Route::get('/', 'LoginController@auth');
Route::post('/masuk',array('as' => 'masuk', 'uses'=> 'LoginController@postAuth'));
Route::get('/logout','LoginController@getLogout');
Route::get('/beranda','IndexController@index');
Route::get('api', 'IndexController@getApi');
//Common-Code
Route::get('/common-code','CommoncodeController@getIndex');
Route::post('/common-code/tambah','CommoncodeController@postTambah');
Route::get('/common-code/{hcode}','CommoncodeController@postHcode');
Route::post('/common-code/update','CommoncodeController@postUpdate');
Route::get('/common-code/delete/{id}','CommoncodeController@getDelete');
//Users
Route::get('/users','UserController@getIndex');
Route::post('/create-users','UserController@postCreate');
Route::get('/users/{code}','UserController@getCode');
//Products
Route::get('/products','ProductController@getIndex');
Route::get('/products/{code}','ProductController@getCode');
Route::get('/products/delete/{code}','ProductController@destroy');
Route::post('/edit-products','ProductController@update');
Route::get('/table',function(){
	return View::make('products.table');
});
Route::post('/create-product','ProductController@postCreate');
//inventory
Route::get('/inbound', 'InventoryController@getIndex');
Route::get('/report-inv', 'InventoryController@getReport');
Route::get('/export-inv', 'InventoryController@exportexcel');
//Route::get('/stok-daily','InventoryController@stok');
Route::get('/shortage','InventoryController@stokMinus');
Route::get('/export-shortage','InventoryController@exportShortage');
Route::post('/shortage','InventoryController@stokMinus');
Route::post('/report-inv', 'InventoryController@getReport');
Route::get('/report-inv/{det}', 'InventoryController@getReportDaily');
Route::post('inbound-create','InventoryController@postCreate');
Route::post('inbound-edit','InventoryController@postInEdit');
Route::get('delete/{idtx}/{mtcd}/{ltno}/{status}/{storage}/{qty_um}/{qty_uom}',array(
	'as'	=> 'del',
	'uses'=>'InventoryController@deleteItem'));
Route::get('/inbound/edit/{id_tx}','InventoryController@getEdit');
Route::get('/inbound/delete/{id_tx}','InventoryController@getDelete');
Route::get('/return','InventoryController@getReturn');
Route::get('/returned','InventoryController@getReturned');
Route::post('/return-create','InventoryController@postCreateReturn');
Route::post('/returned-create','InventoryController@postCreateReturned');
Route::get('/create/return','InventoryController@getCreateReturn');
Route::get('/returned/edit/{no_tx}','InventoryController@getEditReturn');
Route::controller('site', 'InventoryController');
//PO
Route::get('/purchase-order','PurchaseOrderController@getIndex');
Route::post('/purchase-order','PurchaseOrderController@getIndex');
Route::get('report-po','PurchaseOrderController@getReport');
Route::post('report-po','PurchaseOrderController@getReport');
Route::post('/purchase-order/create','PurchaseOrderController@postCreate');
Route::post('/po/edit','PurchaseOrderController@edit');
Route::get('/purchase-order/edit',array('as'=>'ed','uses'=>'PurchaseOrderController@view'));
Route::get('/purchase-order/delete','PurchaseOrderController@destroy');
Route::controller('purchase-o', 'PurchaseOrderController');
Route::get('delete/{idtx}/{pono}/{mtcd}/{qty}',array(
	'as'	=> 'del-po',
	'uses'=>'PurchaseOrderController@deleteItem'));
Route::get('export-ex','PurchaseOrderController@exportexcel');
Route::get('export-pdf','PurchaseOrderController@exportpdf');
//Customer
Route::get('/customers','CustomersController@getIndex');
Route::post('/customers-create','CustomersController@postCreate');
Route::get('/customers/{code}','CustomersController@getCode');
Route::post('customers-update','CustomersController@postUpdate');
Route::get('customer/delete/{customer_code}','CustomersController@destroy');
// DO
Route::get('/delivery-order','DeliveryOrderController@index');
Route::post('/delivery-order','DeliveryOrderController@index');
Route::get('/delivery-order/create','DeliveryOrderController@getCreate');
Route::get('/do/edit/{id_tx}','DeliveryOrderController@getEdit');
Route::post('/create-delivery-order','DeliveryOrderController@create');
Route::post('/update-delivery-order','DeliveryOrderController@update');
Route::post('/send-delivery-order','DeliveryOrderController@postMultipleSend');
Route::post('/send', 'DeliveryOrderController@postSend');
Route::controller('delivery', 'DeliveryOrderController');
Route::get('/do-view/{do_no}','DeliveryOrderController@getShow');
Route::get('/do-delete/{do_no}','DeliveryOrderController@destroy');
//currency
Route::get('/currency','CurrencyController@index');
Route::post('/create-currency','CurrencyController@store');
Route::post('/update-currency','CurrencyController@update');
Route::get('/delete-currency/{exchange_date}','CurrencyController@delete');
//
Route::get('/search',function()
{
	return View::make('search');
});
Route::post('executeSearch',array('uses'=>'SearchController@executeSearch'));
Route::controller('execute', 'SearchController');
Route::get('export', array('uses' => 'UserController@export', 'as' => 'admin.users.export'));
Route::get('stok-daily', 'InventoryController@stokDaily');
Route::post('stok-daily', 'InventoryController@stokDaily');
Route::get('export-stok-daily','InventoryController@stokDailyExcel');
//Carrying Forward
Route::get('carrying-forward','CarryingForwardController@index');
Route::get('export-carrying-forward','CarryingForwardController@export');
Route::post('carrying-forward','CarryingForwardController@index');
Route::post('input-carrying-forward','CarryingForwardController@postCarryingForward');
Route::get('/stok-monthly', 'CarryingForwardController@show');
Route::get('/textar',function(){
	return View::make('textar');
});