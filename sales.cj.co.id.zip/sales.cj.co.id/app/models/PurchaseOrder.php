<?php
/**
* 
*/
class PurchaseOrder extends Eloquent
{
	protected $table = 'ss_pomaster';
	protected $primaryKey = 'po_no';
	protected $fillable = array(
		'company',
		'plant',
		'po_no',
		'po_date',
		'customer_code',
		'ship_to_party',
		'currency_code',
		'currency_rate',
		'source',
		'user_create',
		'user_update'
		);
	public function PoDetail(){
		return $this->belongsToMany('Products','ss_podetail','material_code','po_no')->withPivot('material_code','qty_um','qty_uom', 'u_price_idr','u_price_usd','exclude_idr','exclude_usd','include');
	}
}