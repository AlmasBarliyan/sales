<?php
/**
* 
*/
class Customers extends Eloquent
{
	protected $table = 'ss_customers';
	protected $primaryKey = 'customer_code';
	protected $fillable = array(
		'company',
		'plant',
		'customer_code',
		'customer_ktg',
		'customer_name',
		'sales_district'
		);
}