<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" type="image/png" href="{{{ asset('images/logo_CJ.png') }}}"/>
  <title>Sales</title>
  
  <!-- Bootstrap core CSS -->
  
  <style type="text/css" title="currentStyle">
    @import "../../css/css/layout-styles.css";
    @import "../../css/css/themes/smoothness/jquery-ui-1.8.4.custom.css";
  </style>
  {{ HTML::style('css/bootstrap.min.css')}}
  {{ HTML::style('fonts/css/font-awesome.min.css')}}
  {{ HTML::style('css/animate.min.css')}}
  
  <!-- Custom styling plus plugins -->
  {{HTML::style('css/custom.css')}}
  {{HTML::style('css/icheck/flat/green.css')}}
  
  {{HTML::style('js/datatables/jquery.dataTables.min.css')}}
  {{HTML::style('js/datatables/buttons.bootstrap.min.css')}}
  {{HTML::style('js/datatables/fixedHeader.bootstrap.min.css')}}
  {{HTML::style('js/datatables/responsive.bootstrap.min.css')}}
  {{HTML::style('js/datatables/scroller.bootstrap.min.css')}}
  <!-- select2 -->
  {{ HTML::style('css/select/select2.min.css')}}
  
  <!-- jQuery libs -->
  <!-- {{HTML::script('js/jquery.min.js')}} -->
  {{ HTML::script('js/jquery.js')}}
  {{ HTML::script('js/js/jquery-ui.min.js')}}
  <!-- {{ HTML::script('js/js/jq-ac-script3.js')}} -->
    

  <!--
  <script src="https://ajax.aspnetcdn.com/ajax/jquery.ui/1.9.2/jquery-ui.min.js"></script> -->
  <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
        <![endif]-->

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>


<body class="nav-md" >

  <div class="container body">


    <div class="main_container">

      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">

          @include('../layouts/sidebar')
        </div>
      </div>

      <!-- top navigation -->
      <div class="top_nav">

        @include('../layouts/nav')

      </div>
      <!-- /top navigation -->

      <!-- page content -->
      <div class="right_col" role="main">
        @foreach($ssom as $som)
        <div class="">
          <div class="x_panel">
            <div class="x_title" style="margin-bottom:0px">
              <h2><button class="btn btn-round btn-info" onclick="goBack()" type="button"><i class="fa fa-arrow-circle-left"></i> Back</button> Product Returned</h2>
              <ul class="nav navbar-right panel_toolbox">
                
              </ul>
              <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_content">
                  <div class="">          
                    <div class="clearfix"></div>
                      <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <div class="x_content">
                            <form class="form-horizontal form-label-left input_mask" action="{{URL::to('/returned-create')}}" method="post">
                              <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:20px">  
                                <tbody>
                                    <tr>
                                      <td>
                                        <div class="item form-group" style="margin-bottom:0px">
                                          <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">No. Return</label>
                                          <div class="col-md-4 col-sm-2 col-xs-10">
                                           <p id="dono"><input name="no_transaksi" value="{{$som->no_transaksi}}" type="text" style="width: 250px;" readonly="" class="form-control" /></p>
                                                                      </div>
                                        </div>
                                      </td>
                                      <td>
                                        <div class="item form-group" style="margin-bottom:0px">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Warehouse </label>
                                            <div class="col-md-8 col-sm-8 col-xs-12">
                                              <select name="source" class="select2_single form-control" id="sStorage">
                                                <option disabled selected value>-- Select Warehouse --</option>
                                                @foreach($warehouse as $storage)
                                                  <option value="{{$storage->code}}" <?php if ($storage->code==$som->source) echo 'selected="selected"'; ?>>{{$storage->code_name}}</option>
                                                @endforeach
                                              </select>
                                            </div>
                                        </div>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <div class="item form-group" >
                                          <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">Date Out</label>
                                          <div class="col-md-4 col-sm-2 col-xs-10">
                                            <input type="text" style="z-index: 100000;width: 250px;" value="{{date('d-m-Y',strtotime($som->date_out))}}" name="date_out" id="idTourDateDetails1" class="form-control has-feedback-left""> 
                                            <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                            <span id="inputSuccess2Status" class="sr-only">(success)</span>
                                                                      </div>
                                        </div>
                                      </td>
                                      <td>
                                        <div class="item form-group" >
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Destination </label>
                                            <div class="col-md-8 col-sm-8 col-xs-12">
                                              <select name="destination" class="select2_single form-control" id="sDestination">
                                                <option></option>
                                                @foreach($pabrik as $pb)
                                                  <option value="{{$pb->code}}" <?php if ($pb->code==$som->destination) echo 'selected="selected"'; ?>>{{$pb->code_name}}</option>
                                                @endforeach
                                              </select>
                                            </div>
                                        </div>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <div class="item form-group">
                                          <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">No. Surat Jalan</label>
                                          &emsp;&emsp;&emsp;&emsp;
                                          <div class="col-md-4 col-sm-2 col-xs-10">
                                            <input style="width: 250px;" type="text" class="form-control"  name="no_srtjln" value="{{$som->no_srtjln}}">
                                          </div>
                                        </div>
                                      </td>
                                      <td>
                                        <div class="item form-group" >
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Trucking </label>
                                            <div class="col-md-8 col-sm-8 col-xs-12">
                                              <input type="text" class="form-control" required="" value="{{$som->trucking}}" name="trucking">
                                            </div>
                                        </div>
                                      </td>
                                    </tr>
                                     <tr>
                                      <td>
                                        <div class="item form-group" style="margin-bottom:0px">
                                      <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Remarks</label>
                                      <div class="col-md-9 col-sm-9 col-xs-12">
                                        <input type="text" style="width:250px" value="{{$som->remarks}}" class="form-control" name="remarks">
                                        <p id="sProducts"></p>
                                      </div>
                                    </div>
                                      </td>
                                      <td>
                                        
                                      </td>
                                    </tr>
                                </tbody>
                              </table>
                              <div>
                              <table id="itemsTable" class="table table-bordered dt-responsive nowrap order-list ">
                                <thead>
                                <tr>
                                    <th style="text-align:center;width:1%">Item</th>
                                    <th style="text-align:center;width:1%">Product Description</th>
                                    <th style="text-align:center;width:1%">Lot Number</th>
                                    <th style="text-align:center;width:1%" colspan="2">Qty Retun</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php 
                                  $ssodt = DB::table('ss_outdtl')->leftJoin('cd_material','ss_outdtl.material_code','=','cd_material.material_code')->where('no_transaksi','=',$som->no_transaksi)->get(); 
                                ?>
                                @foreach($ssodt as $sod)
                                  <tr class="item-row">
                                    <td>
                                      <input type="text" id="sku" name="material_code[]" value="{{$sod->material_code}}">
                                    </td>
                                    <td>
                                      <input type="text" name="material_name[]" value="{{$sod->material_name}}" id="pir" />
                                    </td>
                                    <td>
                                      <input type="text" name="lot_number[]" value="{{$sod->lot_number}}" id="lot" />
                                    </td>
                                    <td>
                                      <input style="width:80px" type="text" id="qty_out_um" required="required" value="{{$sod->qty_out_um}}" name="qty_out_um[]" />
                                      <input type="hidden" name="size[]" id="size" class="tInput" value="{{$sod->material_size}}" />
                                      <input style="width:40px" id="out_um" class="tInput" readonly="readonly" value="{{$sod->um}}"/>
                                    </td>
                                    <td>
                                      <input style="width:80px" type="text" id="qty_out_uom" required="required" value="{{$sod->qty_out_uom}}" name="qty_out_uom[]" />
                                      <input style="width:40px" id="out_uom" class="tInput" readonly="readonly" value="{{$sod->uom}}"/>
                                    </td>
                                  </tr>
                                @endforeach                      
                                </tbody>
                              </table>
                              <div class="ln_solid"></div>
                              <div class="form-group">
                                <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
                                  <button type="submit" class="btn btn-success">Save to Bad Product</button>
                                </div>
                              </div>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        @endforeach

        <div id="custom_notifications" class="custom-notifications dsp_none">
          <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
          </ul>
          <div class="clearfix"></div>
          <div id="notif-group" class="tabbed_notifications"></div>
        </div>
        {{HTML::script('js/bootstrap/bootstrap.2.3.1.min.js')}}
        
        <!-- bootstrap progress js -->
        {{ HTML::script('js/progressbar/bootstrap-progressbar.min.js')}}
        <!-- icheck -->
        {{ HTML::script('js/icheck/icheck.min.js')}}

        {{ HTML::script('js/custom.js')}}
        <script>
        function goBack() {
            window.history.back();
        }
        </script>
        <script type="text/javascript">
          $('#idTourDateDetails1').datepicker({
               dateFormat: 'dd-mm-yy',
               changeMonth: true,
               changeYear: true,
               altField: "#idTourDateDetailsHidden",
               altFormat: "yy-mm-dd"
           });
        </script>
        
        <!-- form validation -->
        {{ HTML::script('js/validator/validator.js')}}
        
        <script>
          // initialize the validator function
          validator.message['date'] = 'not a real date';

          // validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
          $('form')
            .on('blur', 'input[required], input.optional, select.required', validator.checkField)
            .on('change', 'select.required', validator.checkField)
            .on('keypress', 'input[required][pattern]', validator.keypress);

          $('.multi.required')
            .on('keyup blur', 'input', function() {
              validator.checkField.apply($(this).siblings().last()[0]);
            });

          // bind the validation to the form submit event
          //$('#send').click('submit');//.prop('disabled', true);

          $('form').submit(function(e) {
            e.preventDefault();
            var submit = true;
            // evaluate the form using generic validaing
            if (!validator.checkAll($(this))) {
              submit = false;
            }

            if (submit)
              this.submit();
            return false;
          });

          /* FOR DEMO ONLY */
          $('#vfields').change(function() {
            $('form').toggleClass('mode2');
          }).prop('checked', false);

          $('#alerts').change(function() {
            validator.defaults.alerts = (this.checked) ? false : true;
            if (this.checked)
              $('form .alert').remove();
          }).prop('checked', false);
        </script>

        @yield('script')

        <!-- Datatables -->
        <!-- <script src="js/datatables/js/jquery.dataTables.js"></script>
  <script src="js/datatables/tools/js/dataTables.tableTools.js"></script> -->

        <!-- Datatables-->
        {{HTML::script('js/datatables/jquery.dataTables.min.js')}}
        {{HTML::script('js/datatables/dataTables.bootstrap.js')}}
        {{HTML::script('js/datatables/dataTables.buttons.min.js')}}
        {{HTML::script('js/datatables/buttons.bootstrap.min.js')}}
        {{HTML::script('js/datatables/jszip.min.js')}}
        {{HTML::script('js/datatables/pdfmake.min.js')}}
        {{HTML::script('js/datatables/vfs_fonts.js')}}
        {{HTML::script('js/datatables/buttons.html5.min.js')}}
        {{HTML::script('js/datatables/buttons.print.min.js')}}
        {{HTML::script('js/datatables/dataTables.fixedHeader.min.js')}}
        
        {{HTML::script('js/datatables/dataTables.responsive.min.js')}}
        {{HTML::script('js/datatables/responsive.bootstrap.min.js')}}
        {{HTML::script('js/datatables/dataTables.scroller.min.js')}}
        {{HTML::script('js/pace/pace.min.js')}}
        <script type="text/javascript">
            $(document).ready(function() {
                $("#currency_code").on('change', function(){
                $.post('{{ URL::to('purchase-o/data1') }}', {type: 'currency_rate', id: $("#currency_code").val()}, function(e){
                    $("#currency_rate").html(e);
                });
                
                $('#sMaterial').html('');
                $('#sDesa').html('');
              });
            });
        </script>
        
        
<script type="text/javascript">  
  function showUser(userNumber, str)  
  {  
    if (str=="")  
    {  
      document.getElementById("txtHint" + userNumber).innerHTML="";  
      return;  
    }    
    if (window.XMLHttpRequest)  
    {// code for IE7+, Firefox, Chrome, Opera, Safari  
      xmlhttp=new XMLHttpRequest();  
    }  

    xmlhttp.onreadystatechange=function()  
    {  
      if (xmlhttp.readyState==4 && xmlhttp.status==200)  
      {  
        //document.getElementById("txtHint" + userNumber).innerHTML=xmlhttp.responseText; 
        var responseText = xmlhttp.responseText; 
        var description = responseText; 
        var warehouse = ""; 
        var sellingUnits = ""; 
        if (responseText.indexOf("NOT A VALID") == -1) 
        { 
          description = responseText.substring(12, responseText.indexOf(",Warehouse:"));  
          warehouse = responseText.substring(responseText.indexOf(",Warehouse:")+11, responseText.indexOf(",SellingUnits:"));  
          sellingUnits = responseText.substring(responseText.indexOf(",SellingUnits:")+15);  
        } 

        document.getElementById("whse" + userNumber).innerHTML = warehouse;  
        document.getElementById("txtHint" + userNumber).innerHTML = description;  
        document.getElementById("su" + userNumber).innerHTML = sellingUnits; 

      }  
    }  
    xmlhttp.open("GET","getdata1.php?q="+str,true);  
    xmlhttp.send(); 
  } 
</script> 
<script type="text/javascript">  


function updateValue(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue1(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue2(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue3(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue4(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue5(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue6(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue7(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue8(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;
    
}
function updateValue9(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}

</script>
<!-- <script type="text/javascript">  
$(function() {
  $('#btnLaunch').click(function() {
    $('#myModal').modal('show');
  });
 
  $('#btnSave').click(function() {
    
    var value = $('.sli').val();
    $('h1').html(value);
    $('.bs-example-modal-lg').modal('hide');
  });
  
});
</script> -->
<script>
          $(document).ready(function () {
            var counter = 1;
            var co = 1;
            $("#addrow").on("click", function () {
              counter++;
              co++;
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><a class="deleteRow"><i class="fa fa-trash"></i> </a><input type="text" id="sku'+ co +'" name="material_code[]" style="width:80px"> <input type="button" name="choice" onClick="selectValue(\''+'sku'+co+'\',\''+'pir'+co+'\',\''+'lot'+co+'\',\''+'qty_um'+co+'\',\''+'um'+co+'\',\''+'qty_uom'+co+'\',\''+'uom'+co+ '\',\''+'out_um'+co+'\',\''+'out_uom'+co+'\',\''+'size'+co+'\')" value="..." style="width:20px"></td>';
              cols += '<td><input type="text" id="pir'+ co +'" name="material_name[]"/></td>';
              cols += '<td><input type="text" id="lot'+ co +'" name="lot_number[]" style="width:100px"/></td>';
              cols += '<td><input style="width:60px" type="text" id="qty_um'+ co +'" name="qty_um[]" readonly="readonly" /><input type="hidden" name="size[]" id="size'+ co +'" class="tInput" /> <input style="width:40px" id="um'+ co +'" class="tInput" readonly="readonly"/></td><td><input style="width:60px" type="text" id="qty_uom'+ co +'" name="qty_uom[]" readonly="readonly" /> <input style="width:30px" id="uom'+ co +'" class="tInput" readonly="readonly"/></td>';
              cols += '<td><input style="width:60px" type="text" id="qty_out_um" required="required" name="qty_out_um[]" /> <input style="width:40px" id="out_um'+ co +'" class="tInput" readonly="readonly"/></td><td><input style="width:60px" type="text" id="qty_out_uom" name="qty_out_uom[]" /> <input style="width:30px" id="out_uom'+ co +'" class="tInput" readonly="readonly"/></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);

            });
            
            $("table.order-list").on("change", 'input[name^="price"], input[name^="qty_out_um"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
          function selectValue(id,pir,lot,qty_um,um,qty_uom,uom,out_um,out_uom,size)
              {
                 var counter = 1;
                 var co = 1;
                  var myData = new Array('sku'+co, 'pir=pir'+co);
                  var url = myData.join('&');
                  // open popup window and pass field id
                  
                    window.open('../sku.php?id=' + encodeURIComponent(id)+'&pir='+encodeURIComponent(pir)+'&lot='+encodeURIComponent(lot)+'&qty_um='+encodeURIComponent(qty_um)+'&um='+encodeURIComponent(um)+'&qty_uom='+encodeURIComponent(qty_uom)+'&uom='+encodeURIComponent(uom)+'&out_um='+encodeURIComponent(out_um)+'&out_uom='+encodeURIComponent(out_uom)+'&size='+encodeURIComponent(size),'popuppage',
                    'width=1050,toolbar=1,resizable=1,scrollbars=yes,height=400,top=100,left=100');  
                  
                  
              }
          function calculateRow(row) {
            var size = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty_out_um"]').val();
            var qty_um = +row.find('input[name^="qty_um"]').val();
            if (qty > qty_um ) {
              alert("Quantity Melebihi Stok BAD");
              row.find('input[name^="qty_out_um"]').val("");
              row.find('input[name^="qty_out_uom"]').val("");
            }
            else{
              row.find('input[name^="qty_out_uom"]').val((size * qty));  
            }
            
            
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#sStorage').on('change', function(){
        $.post('{{ URL::to('site/show') }}', {type: 'storage', id: $('#sStorage').val()}, function(e){
            $('#sProducts').html(e);

        });
        /*$.post('{{ URL::to('site/show') }}', {type: 'lis', id: $('#sStorage').val()}, function(e){
            $('#sLi').html(e);

        });*/
        });
        $('#sMaterial').html('');
        $('#sDesa').html('');
        
    
    $('#sLotnumber').on('change', function(){
        $.post('{{ URL::to('site/return') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
            $('#sMaterial').html(e);
        });
        $('#sDesa').html('');
    });
    $('#sKecamatan').on('change', function(){
        $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
            $('#sDesa').html(e);
        });
    });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#sDestination').on('change', function(){
        $.post('{{ URL::to('site/show') }}', {type: 'destination', id: $('#sDestination').val(),dt: $('#idTourDateDetails1').val()}, function(e){
            $('#dono').html(e);
        });
        
        $('#sMaterial').html('');
        $('#sDesa').html('');
        
    });
   
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#sku').on('change', function(){
        $.post('{{ URL::to('site/show') }}', {type: 'sku', id: $('#sku').val()}, function(e){
            $('#pri').html(e);
        });
        
        $('#sMaterial').html('');
        $('#sDesa').html('');
        
    });
   
    });
</script>
</body>

</html>