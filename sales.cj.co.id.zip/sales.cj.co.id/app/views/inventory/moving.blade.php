@extends('products.table')
@section('content')
        <div class="">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2><a href="{{URL::to('/delivery-order')}}"><button class="btn btn-round btn-info" type="button"><i class="fa fa-arrow-circle-left"></i> Back</button></a> Moving Quantity </h2>
                  
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <form class="form-horizontal form-label-left input_mask" action="{{URL::to('/move-quantity')}}" method="post">
                    <div>
                      <table class="hovertable order-list" cellspacing="0" width="100%">
                        <thead>
                          <tr>
                            <th colspan="4" rowspan="1" style="text-align:center">From</th>
                           
                            <th rowspan="1" colspan="4" style="text-align:center">To</th>
                            <th rowspan="2" style="text-align:center">Qty Move</th>
                          </tr>
                          
                          <tr>
                            <th style="text-align:center;width:12%">Code</th>
                            <th style="text-align:center">Lot No</th>
                            <th style="text-align:center;border-right-width:1px">Qty</th>
                            <th style="text-align:center">Warehouse</th>
                            <th style="text-align:center;width:12%">Code</th>
                            <th style="text-align:center">Lot No</th>
                            <th style="text-align:center">Qty</th>
                            <th style="text-align:center">Warehouse</th>                             
                          </tr>
                        </thead>
                        <tbody>
                          <tr class='even pointer'>
                            <td>
                              <a style="margin-left:14px"> </a>
                              <input type="text" id="mtcd" name="mtcd[]" style="width:60px">
                              <input type="button" name="choice" onClick="selectValue('mtcd','lotno','qty','storage')" value="..." title="Cari Item" style="width:20px">
                            </td>
                            <td>
                              <input type="text" name="lot_no[]" id="lotno">
                            </td>
                            <td>
                              <input type="text" name="qty[]" id="qty">
                            </td>
                            <td>
                              <input type="text" name="storage[]" id="storage">
                            </td>
                            <td>
                              <input type="text" id="matcd" name="matcd[]" style="width:80px">
                              <input type="button" name="choice" onClick="selectValue1('matcd','lotnum','qtty','stor')" value="..." title="Cari Item" style="width:20px">
                            </td>
                            <td>
                              <input type="text" name="lotnum[]" id="lotnum">
                            </td>
                            <td>
                              <input type="text" name="qtty[]" id="qtty">
                            </td>
                            <td>
                              <input type="text" name="stor[]" id="stor">
                            </td>
                            <td>
                              <input type="text" name="qty_move[]">
                            </td>
                          </tr>  
                        </tbody>
                      </table>
                    </div>                    
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12" style="text-align:left">
                        <a href="#" id="addrow" class="btn btn-primary"><span> + Add Row</span></a>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
                        <button type="submit" class="btn btn-success">Save</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
@stop
@section('style')
{{ HTML::style('css/css/layout-styles.css')}}
{{HTML::style('css/css/themes/smoothness/jquery-ui-1.8.4.custom.css')}}
<!-- editor -->
{{ HTML::style('css/editor/external/google-code-prettify/prettify.css')}}
{{ HTML::style('css/editor/index.css')}}
<style type="text/css">
    table.hovertable {
      font-family: verdana,arial,sans-serif;
      font-size:11px;
      color:#333333;
      border-width: 1px;
      border-color: #999999;
      border-collapse: collapse;
    }
    table.hovertable th {
      background-color:#c3dde0;
      border-width: 1px;
      padding: 8px;
      border-style: solid;
      border-color: #a9c6c9;
    }
    table.hovertable tr {
      background-color:#d4e3e5;
    }
    table.hovertable td {
      border-width: 1px;
      padding: 8px;
      border-style: solid;
      border-color: #a9c6c9;
    }
  </style>
@stop
@section('script')
<!-- richtext editor -->
{{ HTML::script('js/editor/bootstrap-wysiwyg.js')}}
{{ HTML::script('js/editor/external/jquery.hotkeys.js')}}
{{ HTML::script('js/editor/external/google-code-prettify/prettify.js')}}
<!-- editor -->
  <script>
    $(document).ready(function() {
      $('.xcxc').click(function() {
        $('#descr').val($('#editor').html());
      });
    });

    $(function() {
      function initToolbarBootstrapBindings() {
        var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
            'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
            'Times New Roman', 'Verdana'
          ],
          fontTarget = $('[title=Font]').siblings('.dropdown-menu');
        $.each(fonts, function(idx, fontName) {
          fontTarget.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
        });
        $('a[title]').tooltip({
          container: 'body'
        });
        $('.dropdown-menu input').click(function() {
            return false;
          })
          .change(function() {
            $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
          })
          .keydown('esc', function() {
            this.value = '';
            $(this).change();
          });

        $('[data-role=magic-overlay]').each(function() {
          var overlay = $(this),
            target = $(overlay.data('target'));
          overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
        });
        if ("onwebkitspeechchange" in document.createElement("input")) {
          var editorOffset = $('#editor').offset();
          $('#voiceBtn').css('position', 'absolute').offset({
            top: editorOffset.top,
            left: editorOffset.left + $('#editor').innerWidth() - 35
          });
        } else {
          $('#voiceBtn').hide();
        }
      };

      function showErrorAlert(reason, detail) {
        var msg = '';
        if (reason === 'unsupported-file-type') {
          msg = "Unsupported format " + detail;
        } else {
          console.log("error uploading file", reason, detail);
        }
        $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
          '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
      };
      initToolbarBootstrapBindings();
      $('#editor').wysiwyg({
        fileUploadError: showErrorAlert
      });
      window.prettyPrint && prettyPrint();
    });
  </script>
  <!-- /editor -->
<script type="text/javascript">
  $('#idTourDateDetails1').datepicker({
       dateFormat: 'dd-mm-yy',
       changeMonth: true,
       changeYear: true,
       altField: "#idTourDateDetailsHidden",
       altFormat: "yy-mm-dd"
   });
  document.getElementById("idTourDateDetails1").focus();
</script>
{{ HTML::script('js/select/select2.full.js')}}
<script>
    $(document).ready(function() {
        $(".select2_single").select2({
            placeholder: "Select...",
            allowClear: true
        });
        $(".select2_group").select2({});
        $(".select2_multiple").select2({
            maximumSelectionLength: 4,
            placeholder: "With Max Selection limit 4",
            allowClear: true
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#sCustomer").on('change', function(){
        $.post('{{ URL::to('delivery/data1') }}', {type: 'dl', id: $("#sCustomer").val()}, function(e){
            $("#dl").html(e);
        });
        
        $('#sMaterial').html('');
        $('#sDesa').html('');
        
    });
    $('#sLotnumber').on('change', function(){
        $.post('{{ URL::to('delivery/data') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
            $('#sMaterial').html(e);
        });
        $('#sDesa').html('');
    });
    $('#sKecamatan').on('change', function(){
        $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
            $('#sDesa').html(e);
        });
    });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#cu").on('change', function(){
        $.post('{{ URL::to('delivery/show') }}', {type: 'po', id: $("#cu").val(), dt: $("#idTourDateDetails1").val() }, function(e){
            $("#sPo").html(e);
        });
        /*$.post('{{ URL::to('delivery/show') }}', {type: 'sip', id: $("#sPo").val()}, function(e){
            $("#sip").html(e);
        });*/
        $('#sMaterial').html('');
        $('#sDesa').html('');
    });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#sPo").on('change', function(){
        $.post('{{ URL::to('delivery/show') }}', {type: 'sip', id: $("#sPo").val()}, function(e){
            $("#sip").html(e);
        });
        $('#sMaterial').html('');
        $('#sDesa').html('');
    });
    });
</script>
<script type="text/javascript">
  $(document).ready(function() {
        $("#sWh").on('change', function(){
          $.post('{{ URL::to('delivery/show') }}', {type: 'dono', wh: $("#sWh").val(), dt: $("#idTourDateDetails1").val(), pono: $("#sPo").val()  },function(e){
              $("#dono").html(e);
          });
          /*$.post('{{ URL::to('delivery/show') }}', {type: 'po', wh: $("#sWh").val(), pono: $("#pono").val(), d: $("#idTourDateDetails1").val()}, function(e){
              $("#inv").html(e);
          });*/
        });
    });
</script>
<script type="text/javascript">
  $(document).ready(function() {
    $("#idTourDateDetails1").on('change', function(){
      $.post('{{ URL::to('delivery/show') }}', {type: 'dono', wh: $("#sWh").val(), dt: $("#idTourDateDetails1").val() },function(e){
          $("#dono").html(e);
      });
    });
  });
</script>
<script type="text/javascript">
function updateValue(mtcd, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(mtcd).value = value;

}
function updateValue1(lotno, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(lotno).value = value;

}
function updateValue2(qty, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(qty).value = value;

}
function updateValue3(storage, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(storage).value = value;

}
function updateValue4(matcd, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(matcd).value = value;

}
function updateValue5(lotnum, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(lotnum).value = value;

}
function updateValue6(qtty, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(qtty).value = value;

}
function updateValue7(stor, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(stor).value = value;

}
function updateValue8(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue9(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue10(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    /*if (localStorage.getItem("sisa")!=null) {
      if (localStorage.getItem("sisa")==0) {
        alert("Kuantitas Terpenuhi");
        document.getElementById(id).value = value;  
      }else{
        alert("Kuantitas pada DO masih kurang "+localStorage.getItem("sisa"));
        document.getElementById(id).value = value;
      }
    }else{*/
      document.getElementById(id).value = value;
    //}
}
function updateValue11(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
</script>
<script>
          $(document).ready(function () {
            var counter = 1;
            var co = 1;
            $("#addrow").on("click", function () {
              counter++;
              co++;
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><a class="deleteRow"><i class="fa fa-trash"></i> </a><input type="text" id="mtcd'+ co +'" name="mtcd[]" style="width:60px"> <input type="button" name="choice" onClick="selectValue(\''+'mtcd'+co+'\',\''+'lotno'+co+'\',\''+'qty'+co+'\',\''+'storage'+co+'\')" value="..." title="Cari Item" style="width:20px"></td>';
              cols += '<td><input type="text" name="lot_no[]" id="lotno'+co+'"></td>';
              cols += '<td><input type="text" name="qty[]" id="qty'+co+'"></td>';
              cols += '<td><input type="text" name="storage" id="storage'+co+'"></td>';
              cols += '<td><input type="text" id="matcd'+co+'" name="matcd[]" style="width:80px"> <input type="button" name="choice" onClick="selectValue1(\''+'matcd'+co+'\',\''+'lotnum'+co+'\',\''+'qtty'+co+'\',\''+'stor'+co+'\')" value="..." title="Cari Item" style="width:20px"></td>';
              cols += '<td><input type="text" name="lotnum[]" id="lotnum'+co+'"></td>';
              cols += '<td><input type="text" name="qtty[]" id="qtty'+co+'"></td>';
              cols += '<td><input type="text" name="stor[]" id="stor'+co+'"></td>';
              cols += '<td><input type="text" name="qty_move[]"></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);

            });
            
            $("table.order-list").on("change", 'input[name^="price"], input[name^="qty_out_um"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
          function selectValue(mtcd,lotno,qty,storage)
          {
            // open popup window and pass field id
              
            window.open('./mv.php?mtcd=' + encodeURIComponent(mtcd)+'&lotno='+encodeURIComponent(lotno)+'&qty='+encodeURIComponent(qty)+'&storage='+encodeURIComponent(storage),'popuppage',
                'width=1050,toolbar=1,resizable=1,scrollbars=yes,height=600,top=100,left=100');  
              
              
          }
          function selectValue1(matcd,lotnum,qtty,stor)
          {
            // open popup window and pass field id
              
            window.open('./mv1.php?matcd=' + encodeURIComponent(matcd)+'&lotnum='+encodeURIComponent(lotnum)+'&qtty='+encodeURIComponent(qtty)+'&stor='+encodeURIComponent(stor),'popuppage',
                'width=1050,toolbar=1,resizable=1,scrollbars=yes,height=600,top=100,left=100');  
              
              
          }
          function calculateRow(row) {
            var size = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty_out_um"]').val();
            var qty_um = +row.find('input[name^="qty_um"]').val();
            if (qty > qty_um ) {
              alert("Quantity Melebihi Stok");
              row.find('input[name^="qty_out_um"]').val("");
              row.find('input[name^="qty_out_uom"]').val("");
            }
            else{
              row.find('input[name^="qty_out_uom"]').val((size * qty));  
            }
            
            
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
        <script type="text/javascript">
          localStorage.clear();
          localStorage.setItem("sisa", 0);
        </script>
@stop