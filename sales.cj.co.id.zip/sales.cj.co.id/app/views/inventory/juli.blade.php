@extends('products.table')
@section('content')
        <div class="">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2><a href="{{URL::to('/delivery-order')}}"><button class="btn btn-round btn-info" type="button"><i class="fa fa-arrow-circle-left"></i> Back</button></a> Moving Quantity </h2>
                  
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <form action="{{URL::to('/stok-juli')}}" method="POST">
                <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">
                  <tbody>
                    <tr>
                      <td>
                        <div class="form-group" >
                          <label class="control-label col-md-1 col-sm-1 col-xs-12" style="margin-top:10px">Sales</label>
                          <div class="col-md-3 col-sm-3 col-xs-12">
                            <select name="sales" class="form-control">
                              <option disabled selected value>Choose</option>
                              @if(Session::get('ktg') == 'B2B02')
                              <option value="B2B02" selected="selected">B2B FOOD</option>
                              <option value="B2B01">B2B FEED</option>
                              <option value="B2C01">B2C Masita</option>
                              @elseif(Session::get('ktg') == 'B2B01')
                              <option value="B2B02">B2B FOOD</option>
                              <option value="B2B01" selected="selected">B2B FEED</option>
                              <option value="B2C01">B2C Masita</option>
                              @elseif(Session::get('ktg') == 'B2C01')
                              <option value="B2B02">B2B FOOD</option>
                              <option value="B2B01">B2B FEED</option>
                              <option value="B2C01" selected="selected">B2C Masita</option>
                              @else
                              <option value="B2B02">B2B FOOD</option>
                              <option value="B2B01">B2B FEED</option>
                              <option value="B2C01">B2C Masita</option>
                              @endif
                            </select>
                          </div>
                          <label class="control-label col-md-1 col-sm-1 col-xs-12" style="margin-top:10px;margin-left:10px">Warehouse</label>
                          <div class="col-md-3 col-sm-3 col-xs-12">
                            <select name="storage" class="form-control">
                              <option disabled selected value>Choose</option>
                              @foreach($storage as $stor)
                                <option value="{{$stor->code}}" <?php if ($stor->code == Session::get('stor')) echo "selected='selected'"; ?>>{{$stor->code_name}}</option>
                              @endforeach
                            </select>
                          </div>
                          <div class="col-md-1 col-sm-1 col-xs-12">
                            <button type="submit" title="Search" class="btn btn-primary btn-xs" style="margin-top:5px"><i class="fa fa-search"></i></button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
                </form>
                  <form action="{{URL::to('update-inv-monthly')}}" method="post">
                    <div>
                      <table  class="hovertable" cellspacing="0" width="100%">
                          <thead>
                            <tr>
                              <th style="text-align:center">Month</th>
                              <th style="text-align:center">Material code</th>
                              <th style="text-align:center">Lot Number</th>
                              <th style="text-align:center">Begin Qty (KG)</th>
                              <th style="text-align:center">In Qty (KG)</th>
                              <th style="text-align:center">Out Qty (KG)</th>
                              <th style="text-align:center">End Qty (KG) / (BAG)</th>
                              <th style="text-align:center">Warehouse</th>
                            </tr>
                          </thead>
                          <tbody>
                          @foreach($stok as $st)
  <tr class='even pointer'>
                              <td>{{$st->yymm}}<input type="hidden" name="yymm[]" value="{{$st->yymm}}"></td>
                              <td>{{$st->material_code}}<input type="hidden" name="matcod[]" value="{{$st->material_code}}"></td>
                              <td>{{$st->lot_number}}<input type="hidden" name="lotno[]" value="{{$st->lot_number}}"></td>
                              <td>
                                <input type="text" name="bgnum[]" value="{{$st->begin_qty_um}}" style="width:100px;text-align:right">
                                <input type="hidden" name="matsize[]" value="{{$st->material_size}}"></td>
                              <td>
                                <input type="text" name="inum[]" value="{{$st->in_qty_um - $st->sm_in}}" style="width:100px;text-align:right">
                              </td>
                              <td>
                                <input type="text" name="outum[]" value="{{$st->out_qty_um - $st->sm_out}}" style="width:100px;text-align:right">
                              </td>
                              <td>
                                <input type="text" name="endum[]" value="{{(($st->begin_qty_um + ($st->in_qty_um - $st->sm_in)) - ($st->out_qty_um - $st->sm_out))}}" style="width:100px;text-align:right">
                              </td>
                              <td>{{$st->storage}}<input type="hidden" name="storage[]" value="{{$st->storage}}"><input type="hidden" name="status[]" value="{{$st->status}}"></td>
                            </tr>
                          @endforeach
                          </tbody>
                      </table>
                    </div>                    
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
                        <button type="submit" class="btn btn-success">Save</button>
                      </div>
                    </div>  
                  </form>                
                </div>
              </div>
            </div>
          </div>
        </div>
@stop
@section('style')
{{ HTML::style('css/css/layout-styles.css')}}
{{HTML::style('css/css/themes/smoothness/jquery-ui-1.8.4.custom.css')}}
<!-- editor -->
{{ HTML::style('css/editor/external/google-code-prettify/prettify.css')}}
{{ HTML::style('css/editor/index.css')}}
<style type="text/css">
    table.hovertable {
      font-family: verdana,arial,sans-serif;
      font-size:11px;
      color:#333333;
      border-width: 1px;
      border-color: #999999;
      border-collapse: collapse;
    }
    table.hovertable th {
      background-color:#c3dde0;
      border-width: 1px;
      padding: 8px;
      border-style: solid;
      border-color: #a9c6c9;
    }
    table.hovertable tr {
      background-color:#d4e3e5;
    }
    table.hovertable td {
      border-width: 1px;
      padding: 8px;
      border-style: solid;
      border-color: #a9c6c9;
    }
  </style>
@stop
@section('script')
<!-- richtext editor -->
{{ HTML::script('js/editor/bootstrap-wysiwyg.js')}}
{{ HTML::script('js/editor/external/jquery.hotkeys.js')}}
{{ HTML::script('js/editor/external/google-code-prettify/prettify.js')}}
<!-- editor -->
  <script>
    $(document).ready(function() {
      $('.xcxc').click(function() {
        $('#descr').val($('#editor').html());
      });
    });

    $(function() {
      function initToolbarBootstrapBindings() {
        var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
            'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
            'Times New Roman', 'Verdana'
          ],
          fontTarget = $('[title=Font]').siblings('.dropdown-menu');
        $.each(fonts, function(idx, fontName) {
          fontTarget.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
        });
        $('a[title]').tooltip({
          container: 'body'
        });
        $('.dropdown-menu input').click(function() {
            return false;
          })
          .change(function() {
            $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
          })
          .keydown('esc', function() {
            this.value = '';
            $(this).change();
          });

        $('[data-role=magic-overlay]').each(function() {
          var overlay = $(this),
            target = $(overlay.data('target'));
          overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
        });
        if ("onwebkitspeechchange" in document.createElement("input")) {
          var editorOffset = $('#editor').offset();
          $('#voiceBtn').css('position', 'absolute').offset({
            top: editorOffset.top,
            left: editorOffset.left + $('#editor').innerWidth() - 35
          });
        } else {
          $('#voiceBtn').hide();
        }
      };

      function showErrorAlert(reason, detail) {
        var msg = '';
        if (reason === 'unsupported-file-type') {
          msg = "Unsupported format " + detail;
        } else {
          console.log("error uploading file", reason, detail);
        }
        $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
          '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
      };
      initToolbarBootstrapBindings();
      $('#editor').wysiwyg({
        fileUploadError: showErrorAlert
      });
      window.prettyPrint && prettyPrint();
    });
  </script>
  <!-- /editor -->
<script type="text/javascript">
  $('#idTourDateDetails1').datepicker({
       dateFormat: 'dd-mm-yy',
       changeMonth: true,
       changeYear: true,
       altField: "#idTourDateDetailsHidden",
       altFormat: "yy-mm-dd"
   });
  document.getElementById("idTourDateDetails1").focus();
</script>
{{ HTML::script('js/select/select2.full.js')}}
<script>
    $(document).ready(function() {
        $(".select2_single").select2({
            placeholder: "Select...",
            allowClear: true
        });
        $(".select2_group").select2({});
        $(".select2_multiple").select2({
            maximumSelectionLength: 4,
            placeholder: "With Max Selection limit 4",
            allowClear: true
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#sCustomer").on('change', function(){
        $.post('{{ URL::to('delivery/data1') }}', {type: 'dl', id: $("#sCustomer").val()}, function(e){
            $("#dl").html(e);
        });
        
        $('#sMaterial').html('');
        $('#sDesa').html('');
        
    });
    $('#sLotnumber').on('change', function(){
        $.post('{{ URL::to('delivery/data') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
            $('#sMaterial').html(e);
        });
        $('#sDesa').html('');
    });
    $('#sKecamatan').on('change', function(){
        $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
            $('#sDesa').html(e);
        });
    });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#cu").on('change', function(){
        $.post('{{ URL::to('delivery/show') }}', {type: 'po', id: $("#cu").val(), dt: $("#idTourDateDetails1").val() }, function(e){
            $("#sPo").html(e);
        });
        /*$.post('{{ URL::to('delivery/show') }}', {type: 'sip', id: $("#sPo").val()}, function(e){
            $("#sip").html(e);
        });*/
        $('#sMaterial').html('');
        $('#sDesa').html('');
    });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#sPo").on('change', function(){
        $.post('{{ URL::to('delivery/show') }}', {type: 'sip', id: $("#sPo").val()}, function(e){
            $("#sip").html(e);
        });
        $('#sMaterial').html('');
        $('#sDesa').html('');
    });
    });
</script>
<script type="text/javascript">
  $(document).ready(function() {
        $("#sWh").on('change', function(){
          $.post('{{ URL::to('delivery/show') }}', {type: 'dono', wh: $("#sWh").val(), dt: $("#idTourDateDetails1").val(), pono: $("#sPo").val()  },function(e){
              $("#dono").html(e);
          });
          /*$.post('{{ URL::to('delivery/show') }}', {type: 'po', wh: $("#sWh").val(), pono: $("#pono").val(), d: $("#idTourDateDetails1").val()}, function(e){
              $("#inv").html(e);
          });*/
        });
    });
</script>
<script type="text/javascript">
  $(document).ready(function() {
    $("#idTourDateDetails1").on('change', function(){
      $.post('{{ URL::to('delivery/show') }}', {type: 'dono', wh: $("#sWh").val(), dt: $("#idTourDateDetails1").val() },function(e){
          $("#dono").html(e);
      });
    });
  });
</script>
<script type="text/javascript">
function updateValue(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue1(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue2(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue3(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue4(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue5(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue6(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue7(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue8(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue9(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue10(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    /*if (localStorage.getItem("sisa")!=null) {
      if (localStorage.getItem("sisa")==0) {
        alert("Kuantitas Terpenuhi");
        document.getElementById(id).value = value;  
      }else{
        alert("Kuantitas pada DO masih kurang "+localStorage.getItem("sisa"));
        document.getElementById(id).value = value;
      }
    }else{*/
      document.getElementById(id).value = value;
    //}
}
function updateValue11(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
</script>
<script>
          $(document).ready(function () {
            var counter = 1;
            var co = 1;
            $("#addrow").on("click", function () {
              counter++;
              co++;
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><a class="deleteRow"><i class="fa fa-trash"></i> </a><input type="text" id="sku'+ co +'" name="material_code[]" style="width:80px"> <input type="button" name="choice" onClick="selectValue(\''+'sku'+co+'\',\''+'pir'+co+'\',\''+'lot'+co+'\',\''+'qty_um'+co+'\',\''+'um'+co+'\',\''+'qty_uom'+co+'\',\''+'uom'+co+ '\',\''+'out_um'+co+'\',\''+'out_uom'+co+'\',\''+'size'+co+'\',\''+'qty_out_um'+co+'\',\''+'qty_out_uom'+co+'\')" value="..." style="width:20px"></td>';
              cols += '<td><input type="text" id="pir'+ co +'" name="material_name[]"/></td>';
              cols += '<td><input type="text" id="lot'+ co +'" name="lot_number[]" style="width:100px"/></td>';
              cols += '<td><input style="width:80px" type="text" id="qty_um'+ co +'" name="qty_um[]" readonly="readonly" /><input type="hidden" name="size[]" id="size'+ co +'" class="tInput" /> <input style="width:40px" id="um'+ co +'" class="tInput" readonly="readonly"/></td><td><input style="width:80px" type="text" id="qty_uom'+ co +'" name="qty_uom[]" readonly="readonly" /> <input style="width:30px" id="uom'+ co +'" class="tInput" readonly="readonly"/></td>';
              cols += '<td><input style="width:80px" type="text" id="qty_out_um'+ co +'" name="qty_out_um[]" /> <input style="width:40px" id="out_um'+ co +'" class="tInput" readonly="readonly"/></td><td><input style="width:80px" type="text" id="qty_out_uom'+ co +'" name="qty_out_uom[]" /> <input style="width:30px" id="out_uom'+ co +'" class="tInput" readonly="readonly"/></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);

            });
            
            $("table.order-list").on("change", 'input[name^="price"], input[name^="qty_out_um"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
          function selectValue(id,pir,lot,qty_um,um,qty_uom,uom,out_um,out_uom,size,qty_out_um,qty_out_uom)
          {
             var counter = 1;
             var co = 1;
              var myData = new Array('sku'+co, 'pir=pir'+co);
              var url = myData.join('&');
              // open popup window and pass field id
              
                window.open('../sku1.php?id=' + encodeURIComponent(id)+'&pir='+encodeURIComponent(pir)+'&lot='+encodeURIComponent(lot)+'&qty_um='+encodeURIComponent(qty_um)+'&um='+encodeURIComponent(um)+'&qty_uom='+encodeURIComponent(qty_uom)+'&uom='+encodeURIComponent(uom)+'&out_um='+encodeURIComponent(out_um)+'&out_uom='+encodeURIComponent(out_uom)+'&size='+encodeURIComponent(size)+'&qty_out_um='+encodeURIComponent(qty_out_um)+'&qty_out_uom='+encodeURIComponent(qty_out_uom),'popuppage',
                'width=1050,toolbar=1,resizable=1,scrollbars=yes,height=400,top=100,left=100');  
              
              
          }
          function selectValue1()
          {
             var counter = 1;
             var co = 1;
              var myData = new Array('sku'+co, 'pir=pir'+co);
              var url = myData.join('&');
              // open popup window and pass field id
              
                window.open('../send-delivery-order','popuppage',
                'width=1050,toolbar=1,resizable=1,scrollbars=yes,height=400,top=100,left=100');  
              
              
          }  
          function calculateRow(row) {
            var size = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty_out_um"]').val();
            var qty_um = +row.find('input[name^="qty_um"]').val();
            if (qty > qty_um ) {
              alert("Quantity Melebihi Stok");
              row.find('input[name^="qty_out_um"]').val("");
              row.find('input[name^="qty_out_uom"]').val("");
            }
            else{
              row.find('input[name^="qty_out_uom"]').val((size * qty));  
            }
            
            
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
        <script type="text/javascript">
          localStorage.clear();
          localStorage.setItem("sisa", 0);
        </script>
@stop