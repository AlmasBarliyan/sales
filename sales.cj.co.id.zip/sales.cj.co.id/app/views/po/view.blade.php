<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" type="image/png" href="{{{ asset('images/logo_CJ.png') }}}"/>
  <title>Sales</title>
  
  <!-- Bootstrap core CSS -->
  <style type="text/css">
    table.hovertable {
      font-family: verdana,arial,sans-serif;
      font-size:11px;
      color:#333333;
      border-width: 1px;
      border-color: #999999;
      border-collapse: collapse;
    }
    table.hovertable th {
      background-color:#c3dde0;
      border-width: 1px;
      padding: 8px;
      border-style: solid;
      border-color: #a9c6c9;
    }
    
    table.hovertable td {
      border-width: 1px;
      padding: 8px;
      border-style: solid;
      border-color: #a9c6c9;
    }
  </style>
  {{ HTML::style('css/css/layout-styles.css')}}
  {{ HTML::style('css/css/themes/smoothness/jquery-ui-1.8.4.custom.css')}}
  
  {{ HTML::style('css/bootstrap.min.css')}}
  {{ HTML::style('fonts/css/font-awesome.min.css')}}
  {{ HTML::style('css/animate.min.css')}}
  
  <!-- Custom styling plus plugins -->
  {{HTML::style('css/custom.css')}}
  {{HTML::style('css/icheck/flat/green.css')}}
  
  {{HTML::style('js/datatables/jquery.dataTables.min.css')}}
  {{HTML::style('js/datatables/buttons.bootstrap.min.css')}}
  {{HTML::style('js/datatables/fixedHeader.bootstrap.min.css')}}
  {{HTML::style('js/datatables/responsive.bootstrap.min.css')}}
  {{HTML::style('js/datatables/scroller.bootstrap.min.css')}}
  <!-- select2 -->
  {{ HTML::style('css/select/select2.min.css')}}
  
  <!-- jQuery libs -->
  {{HTML::script('js/jquery.js')}}
    
  {{HTML::script('js/js/jquery-ui.min.js')}}

  <!-- Our jQuery Script to make everything work -->
  {{ HTML::script('js/js/jq-ac-script4.js')}}
  

  <!--
  <script src="https://ajax.aspnetcdn.com/ajax/jquery.ui/1.9.2/jquery-ui.min.js"></script> -->
  <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
        <![endif]-->

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>


<body class="nav-md">

  <div class="container body">


    <div class="main_container">

      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">

          @include('../layouts/sidebar')
        </div>
      </div>

      <!-- top navigation -->
      <div class="top_nav">
        @include('../layouts/nav')
      </div>
      <!-- /top navigation -->

      <!-- page content -->
      <div class="right_col" role="main">
        <div class="">
          <div class="x_panel">
            <div class="x_title">
              @foreach($view_po as $vp)
              <h2><a href="{{URL::to('purchase-order')}}"><button class="btn btn-round btn-info" type="button"><i class="fa fa-arrow-circle-left"></i> Back</button></a> Edit ID Transaction PO {{$vp->po_no}} </h2>
              <div class="clearfix"></div>

            </div>
            <?php 
              $podtl = DB::table('performance_detail as pd')->join('cd_material as mt','mt.material_code','=','pd.material_code')->where('pd.po_no','=',$vp->po_no)->get();
              $pp = DB::table('ss_podetail')->get();
            ?>
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_content">
                <form class="form-horizontal form-label-left input_mask" action="{{URL::to('/po/edit')}}" method="post" novalidate>
                  <table class="table table-striped responsive-utilities jambo_table" style="margin-bottom:0px;">
                    <tbody>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">PO No.</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <input type="hidden" name="pono" value="{{$vp->po_no}}">
                                <input type="text" style="width: 200px;" name="po_no" value="{{$vp->po_no}}" required="required" class="form-control"  />
                              </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Customers </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                  <select name="customer" required="required" class="select2_single form-control" style="width:100%">
                                  <option></option>
                                    @foreach($sold_to_party as $stp)
                                      <option value="{{$stp->ship_to_party}}" <?php if ($vp->customer_code==$stp->ship_to_party) echo 'selected="selected"'; ?>>{{$stp->ship_to_party}} - {{$stp->name}}</option>
                                    @endforeach
                                  </select>
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">PO Date</label>
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <input type="text" style="z-index: 100000;width: 200px;" value="{{date('d-m-Y', strtotime($vp->po_date))}}" name="po_date" id="idTourDateDetails" class="form-control has-feedback-left"> 
                                <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                <span id="inputSuccess2Status" class="sr-only">(success)</span>
                              </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Ship To</label>
                              <div class="col-md-8 col-sm-8 col-xs-10">
                                <select name="ship_to_party" required="required" class="select2_single form-control" style="width:100%" >
                                  <option></option>
                                  @foreach($ship_to_party as $stp)
                                    <option value="{{$stp->ship_to_party}}" <?php if ($vp->ship_to_party==$stp->ship_to_party) echo 'selected="selected"'; ?>>{{$stp->ship_to_party }} - {{$stp->name}}</option>
                                  @endforeach
                                </select>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <!-- <div class="item form-group">
                <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">Estimasi Time</label>
                &emsp;&emsp;&emsp;&emsp;
                <div class="col-md-4 col-sm-2 col-xs-10">
                  <button class="btn btn-primary" data-toggle="modal" href="#stack2">Estimasi Time +</button>
                </div>
                            </div> -->
                          </td>
              <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Source</label>
                              <div class="col-md-8 col-sm-8 col-xs-10">
                                <select name="source" class="form-control" style="width:100%">
                                  @foreach($source as $src)
                                    <option value="{{$src->code}}" <?php if ($vp->source==$src->code) echo 'selected="selected"'; ?>>{{$src->code_name}}</option>
                                  @endforeach
                                </select>
                              </div>
                            </div>
                          </td>
                        </tr>
                    </tbody>
                  </table>
                  <div style="overflow-x: scroll;width:100%">
                  <table id="itemsTable" class="hovertable order-list " style="width:1450px">
                    <thead>
                      <tr>
                        <th rowspan="2" style="text-align:center;width:1%">Item</th>
                        <th rowspan="2" style="text-align:center;width:1%">Product Description</th>
                        <th rowspan="2" style="text-align:center;width:6%" colspan="4">Quantity</th>
                        <th rowspan="2" style="text-align:center;width:1%">ETD</th>
                        <th rowspan="2" style="text-align:center;width:1%">SO No</th>
                        <th rowspan="2" style="text-align:center;width:1%">Invoice</th>
                        <th rowspan="2" style="text-align:center;width:1%">Bill Date</th>
                        <th rowspan="2" style="text-align:center;width:1%">U/Price</th>
                        <th rowspan="2" style="text-align:center;width:1%">ETA</th>
                        <th rowspan="2" style="text-align:center;width:1%">SO Date</th>
                    </tr>
                    <tr>
                        
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($podtl as $podl)
                      <tr class="item-row">

                        <td style="width:50px">

                        <a href="{{URL::route('delete-po',[$podl->id,$podl->po_no, $podl->material_code,$podl->qty_um])}}" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fa fa-trash"></i></a>
                          <input type="hidden" name="id[]" value="{{$podl->id}}">
                          <input style="width:50px" name="material_code[]" value="{{$podl->material_code}}" class="tInput" id="itemCode" />
                          <input style="width:50px" name="matcod[]" value="{{$podl->material_code}}" class="tInput" type="hidden"/>
                        </td>
                        <td style="width:200px">
                          <input style="width:140px" name="material_name[]" value="{{$podl->material_name}}" class="tInput" id="itemDesc"  readonly="readonly" />
                        </td>
                        <td style="width:150px" colspan="4">
                          <input style="width:60px;text-align:right" type="hidden" name="h_uom[]" value="{{$podl->qty_uom}}"/>
                          <input style="width:60px;text-align:right" type="text" name="uom[]" value="{{$podl->qty_uom}}"/>
                          <input style="width:30px" id="uom" class="tInput" name="om[]" readonly="readonly" value="{{$podl->uom}}" />
                          <input type="hidden" style="width:40px;text-align:right" name="h_qty[]" value="{{$podl->qty_um}}" class="tInput" id="itemQty" tabindex="1" />
                          <input style="width:40px;text-align:right" name="qty[]" value="{{$podl->qty_um}}" class="tInput" id="itemQty" tabindex="1" />
                          <input  type="hidden" name="size[]" value="{{$podl->material_size}}" id="itemSize" class="tInput" />
                          <input style="width:30px" class="tInput" id="um" name="um[]" value="{{$podl->um}}" readonly="readonly" />
                        </td>
                        <td><input type="date" style="width:118px" name="etd[]" value="{{$podl->etd}}"></td>
                        <td><input style="width:100px" type="text" name="so_no[]" value="{{$podl->so_no}}"></td>
                        <td><input style="width:100px" type="text" name="invoice[]" value="{{$podl->invoice}}"></td>
                        <td><input type="date" style="width:118px" name="bill_date[]" value="{{$podl->bill_date}}"></td>
                        <td><input style="width:80px;text-align:right" name="price_idr[]" value="{{$podl->u_price_idr}}" class="tInput" tabindex="2" /></td>
                        <td><input style="width:118px" type="date" name="eta_po[]" value="{{$podl->eta}}"></td>
                        <td><input style="width:118px" type="date" name="so_date[]" value="{{$podl->so_date}}"></td>
                      </tr>
                    @endforeach
                    </tbody>
                  </table>
                  </div>
                    <div class="form-group" style="margin-top:10px">
                      <div class="col-md-12 col-sm-12 col-xs-12" style="text-align:left">
                        <a href="#" id="addRow" class="btn btn-primary"><span> + Add Item</span></a>
                      </div>
                    </div>
                  <div class="form-group">
                    <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
                      <button type="submit" class="btn btn-success">Save</button>
                    </div>
                  </div>
                </form>           
                </div>
            </div>
          </div>
          @endforeach
          </div>
        </div>
      </div>
      
      <!-- /page content -->
          </div>

        </div>
        {{HTML::script('js/bootstrap/bootstrap.2.3.1.min.js')}}
        
        <!-- bootstrap progress js -->
        {{ HTML::script('js/progressbar/bootstrap-progressbar.min.js')}}
        <!-- icheck -->
        {{ HTML::script('js/icheck/icheck.min.js')}}

        {{ HTML::script('js/custom.js')}}
        <script>
        function goBack() {
            window.history.back();
        }
        
        @yield('script')
        <script type="text/javascript">
          var timerid;  
        $("#input").on("input",function(e){
                var value = $(this).val();
          if($(this).data("lastval")!= value){
            $(this).data("lastval",value);
                    

            clearTimeout(timerid);
            timerid = setTimeout(function() {

              //change action
              $('textarea').text(value);
              

            },500);

          };
        });
        </script>
        <script type="text/javascript">
           $('#idTourDateDetails').datepicker({
               dateFormat: 'dd-mm-yy',
               changeMonth: true,
               changeYear: true,
               altField: "#idTourDateDetailsHidden",
               altFormat: "yy-mm-dd"
           });
           $('#idTourDateDetails1').datepicker({
               dateFormat: 'dd-mm-yy',
               changeMonth: true,
               changeYear: true,
               altField: "#idTourDateDetailsHidden",
               altFormat: "yy-mm-dd"
           });
           $('#idTourDateDetails2').datepicker({
               dateFormat: 'dd-mm-yy',
               changeMonth: true,
               changeYear: true,
               altField: "#idTourDateDetailsHidden",
               altFormat: "yy-mm-dd"
           });
        </script>
        <!-- Datatables -->
        <!-- <script src="js/datatables/js/jquery.dataTables.js"></script>
  <script src="js/datatables/tools/js/dataTables.tableTools.js"></script> -->
        <!-- select2 -->
        {{ HTML::script('js/select/select2.full.js')}}
        <script>
            $(document).ready(function() {
                $(".select2_single").select2({
                    placeholder: "Select...",
                    allowClear: true
                });
                $(".select2_group").select2({});
                $(".select2_multiple").select2({
                    maximumSelectionLength: 4,
                    placeholder: "With Max Selection limit 4",
                    allowClear: true
                });
            });
        </script>
         <script type="text/javascript">
            $(document).ready(function() {
                $("#sCustomer").on('change', function(){
                $.post('{{ URL::to('purchase-o/data') }}', {type: 'dl', id: $("#sCustomer").val()}, function(e){
                    $("#dl").html(e);
                });
                
                $('#sMaterial').html('');
                $('#sDesa').html('');
                
            });
            $('#sLotnumber').on('change', function(){
                $.post('{{ URL::to('delivery/data') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
                    $('#sMaterial').html(e);
                });
                $('#sDesa').html('');
            });
            $('#sKecamatan').on('change', function(){
                $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
                    $('#sDesa').html(e);
                });
            });
            });
        </script>
        <script type="text/javascript">
            $(document).ready(function() {
                $("#currency_code").on('change', function(){
                $.post('{{ URL::to('purchase-o/data1') }}', {type: 'currency_rate', id: $("#currency_code").val()}, function(e){
                    $("#currency_rate").html(e);
                });
                
                $('#sMaterial').html('');
                $('#sDesa').html('');
              });
            });
        </script>
        <script>
          $(document).ready(function () {
            var counter = 1;
            
            $("#addrow").on("click", function () {
              counter++;
              
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><a title="Delete Row" class="deleteRow" style="color:white"><i class="fa fa-trash"></i> </a><input type="date" style="width:150px" name="etd[]"></td>';
              cols += '<td><input style="width:150px" type="date" name="eta_po[]"></td>';
              /*cols += '<td><input type="text" name="product' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="price' + counter + '"/></td>';
              cols += '<td><input type="text" name="qty' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="linetotal' + counter + '" readonly="readonly"/></td>';*/
              newRow.append(cols);
              
              $("table.list").append(newRow);
            });
            
            $("table.order-list").on("input", 'input[name^="price_idr"], input[name^="uom"], input[name^="currency_rate"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
            
          function calculateRow(row) {
            var price = +row.find('input[name^="price_idr"]').val();
            var size  = +row.find('input[name^="size"]').val();
            var uom = +row.find('input[name^="uom"]').val();
            
            //row.find('input[name^="usd"]').val((price / row.find('input[name^="currency_rate"]').val()));

            row.find('input[name^="qty"]').val((uom / size));
            row.find('input[name^="exclude_idr"]').val((price * row.find('input[name^="uom"]').val()).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());
            row.find('input[name^="include"]').val(((price * row.find('input[name^="uom"]').val()) * 1.1).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());
            row.find('input[name^="price_usd"]').val(parseFloat(price / document.getElementById('cr').value ).toFixed(3).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());
            row.find('input[name^="exclude_usd"]').val(parseFloat(row.find('input[name^="uom"]').val() * row.find('input[name^="price_usd"]').val()).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString());
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
        <!-- Datatables-->
        {{HTML::script('js/datatables/jquery.dataTables.min.js')}}
        {{HTML::script('js/datatables/dataTables.bootstrap.js')}}
        {{HTML::script('js/datatables/dataTables.buttons.min.js')}}
        {{HTML::script('js/datatables/buttons.bootstrap.min.js')}}
        {{HTML::script('js/datatables/jszip.min.js')}}
        {{HTML::script('js/datatables/pdfmake.min.js')}}
        {{HTML::script('js/datatables/vfs_fonts.js')}}
        {{HTML::script('js/datatables/buttons.html5.min.js')}}
        {{HTML::script('js/datatables/buttons.print.min.js')}}
        {{HTML::script('js/datatables/dataTables.fixedHeader.min.js')}}
        {{HTML::script('js/datatables/dataTables.keyTable.min.js')}}
        {{HTML::script('js/datatables/dataTables.responsive.min.js')}}
        {{HTML::script('js/datatables/responsive.bootstrap.min.js')}}
        {{HTML::script('js/datatables/dataTables.scroller.min.js')}}
        {{HTML::script('js/pace/pace.min.js')}}
        
        <script>
          var handleDataTableButtons = function() {
              "use strict";
              0 !== $("#datatable-buttons").length && $("#datatable-buttons").DataTable({
                dom: "Bfrtip",
                buttons: [{
                  extend: "copy",
                  className: "btn-sm"
                }, {
                  extend: "csv",
                  className: "btn-sm"
                }, {
                  extend: "excel",
                  className: "btn-sm"
                }, {
                  extend: "pdf",
                  className: "btn-sm"
                }, {
                  extend: "print",
                  className: "btn-sm"
                }],
                responsive: !0
              })
            },
            TableManageButtons = function() {
              "use strict";
              return {
                init: function() {
                  handleDataTableButtons()
                }
              }
            }();
        </script>
        <script type="text/javascript">
          $(document).ready(function() {
            $('#datatable').dataTable();
            $('#datatable-keytable').DataTable({
              keys: true
            });
            $('#datatable-responsive').DataTable();
            $('#datatable-scroller').DataTable({
              ajax: "js/datatables/json/scroller-demo.json",
              deferRender: true,
              scrollY: 380,
              scrollCollapse: true,
              scroller: true
            });
            var table = $('#datatable-fixed-header').DataTable({
              fixedHeader: true
            });
          });
          TableManageButtons.init();
        </script>

</body>

</html>
