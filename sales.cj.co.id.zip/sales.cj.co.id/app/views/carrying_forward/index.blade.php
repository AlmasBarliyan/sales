<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="keywords" content="jquery,ui,easy,easyui,web">
	<meta name="description" content="easyui help you build your web page easily!">
	<title>Build CRUD DataGrid with jQuery EasyUI - jQuery EasyUI Demo</title>
	<link rel="stylesheet" type="text/css" href="http://www.jeasyui.com/easyui/themes/default/easyui.css">
	<link rel="stylesheet" type="text/css" href="http://www.jeasyui.com/easyui/themes/icon.css">
	<link rel="stylesheet" type="text/css" href="http://www.jeasyui.com/easyui/demo/demo.css">
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.6.min.js"></script>
	<script type="text/javascript" src="http://www.jeasyui.com/easyui/jquery.easyui.min.js"></script>
	<script type="text/javascript" src="http://www.jeasyui.com/easyui/jquery.edatagrid.js"></script>
	<script type="text/javascript" src="http://jeasyui.com/easyui/datagrid-filter.js"></script>
	<script type="text/javascript">
		$(function(){
			$('#dg').edatagrid({
				url: './get_inv.php',
				saveUrl: './save_inv.php',
				updateUrl: './update_inv.php',
				destroyUrl: './destroy_inv.php'
			});
		});
	</script>
	<script type="text/javascript">
		$(function(){
			var dg = $('#dg');
			dg.datagrid();    // create datagrid
			dg.datagrid('enableFilter');    // enable filter
		});
	</script>
</head>
<body>
	<h2>CRUD DataGrid</h2>
	<div class="demo-info" style="margin-bottom:10px">
		<div class="demo-tip icon-tip">&nbsp;</div>
		<div>Double click the row to begin editing.</div>
	</div>
	
	<table id="dg" title="My Users" style="width:100%;height:350px"
			toolbar="#toolbar" pagination="true" idField="id"
			rownumbers="true" fitColumns="true" singleSelect="true">
		<thead>
			<tr>
				<th field="yymm" width="10">Month</th>
				<th field="material_code" width="10" >Material Code</th>
				<th field="material_name" width="10" >Material Name</th>
				<th field="lot_number" width="10" editor="{type:'validatebox',options:{required:true}}">Lot Number</th>
				<th field="begin_qty_um" width="10" >Begin (BAG)</th>
				<th field="begin_qty_uom" width="10" >Begin (KG)</th>
				<th field="in_qty_um" width="10" >In (BAG)</th>
				<th field="in_qty_uom" width="10" >In (KG)</th>
				<th field="out_qty_um" width="10" >Out (BAG)</th>
				<th field="out_qty_uom" width="10" >Out (KG)</th>
				<th field="end_qty_um" width="10" editor="{type:'validatebox',options:{required:true}}">End (BAG)</th>
				<th field="end_qty_uom" width="10" editor="{type:'validatebox',options:{required:true}}">End (KG)</th>
				<th field="code_name" width="10" >Warehouse</th>
				<th field="status" width="10" >Status</th>
			</tr>
		</thead>
	</table>
	<div id="toolbar">
		<a href="#" class="easyui-linkbutton" iconCls="icon-add" plain="true" onclick="javascript:$('#dg').edatagrid('addRow')">New</a>
		<a href="#" class="easyui-linkbutton" iconCls="icon-remove" plain="true" onclick="javascript:$('#dg').edatagrid('destroyRow')">Destroy</a>
		<a href="#" class="easyui-linkbutton" iconCls="icon-save" plain="true" onclick="javascript:$('#dg').edatagrid('saveRow')">Save</a>
		<a href="#" class="easyui-linkbutton" iconCls="icon-undo" plain="true" onclick="javascript:$('#dg').edatagrid('cancelRow')">Cancel</a>
	</div>
	
	

</body>
</html>