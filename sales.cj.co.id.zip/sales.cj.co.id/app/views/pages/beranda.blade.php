@extends('products.table')
@section('content')
        <!-- top tiles -->
@if(Auth::check())

<div class="clearfix"></div>
<!-- /bar charts group -->
<div class="col-md-6">
  <div class="x_panel">
    <div class="x_title">
      <h2>Coming Soon <small>Create Delivery Order</small></h2>
      <div class="clearfix"></div>
    </div>
    <div class="x_content">
    @foreach($create_do as $cdo)
      <?php 
      	$pomaster = DB::table('ss_pomaster')->leftJoin('ss_customers','ss_customers.customer_code','=','ss_pomaster.customer_code')->where('po_no','=',$cdo->po_no)->first();
      ?>
      <article class="media event">
        <a class="pull-left date" style="background:#d89619">
          <p class="month">{{date("M",strtotime($cdo->etd))}}</p>
          <p class="day">{{date("d",strtotime($cdo->etd))}}</p>
        </a>
        <div class="media-body">
          <a class="title" href="#">{{$cdo->po_no}} - {{$pomaster->customer_name}}</a>
          <p>{{$cdo->material_name}} - {{$cdo->qty_uom}} {{$cdo->uom}}</p>
        </div>
      </article>
     @endforeach
    </div>
  </div>
</div>
@endif
@endsection
@section('script')
<!-- moris js -->
<script src="js/moris/raphael-min.js"></script>
<script src="js/moris/morris.min.js"></script>
<script src="js/moris/example.js"></script>
@stop