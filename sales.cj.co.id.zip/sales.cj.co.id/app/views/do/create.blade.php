@extends('products.table')
@section('content')
        <div class="">
          <div class="clearfix"></div>

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>List Delivery Order </h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a href="{{URL::to('/delivery-order/create')}}"><button type="button" class="btn btn-round btn-primary">+ Create DO </button></a></li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <form action="{{URL::to('/delivery-order')}}" method="POST">
                <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">
                  <tbody>
                    <tr>
                      <td>
                      <?php
                        $warehouse = DB::table('cd_code')->where('hcode','LIKE','%'.'GD'.'%')->where('code','!=','*')->get();
                      ?>
                        <div class="form-group" >
                          <label class="control-label col-md-1 col-sm-1 col-xs-12" style="margin-top:10px;margin-left:10px">Warehouse</label>
                          <div class="col-md-3 col-sm-3 col-xs-12">
                            <select name="storage" class="form-control">
                              <option disabled selected value>Choose</option>
                              @foreach($warehouse as $stor)
                                <option value="{{$stor->code}}" <?php if ($stor->code == Session::get('stor')) echo "selected='selected'"; ?>>{{$stor->code_name}}</option>
                              @endforeach
                            </select>
                          </div>
                          <div class="col-md-1 col-sm-1 col-xs-12">
                            <button type="submit" title="Search" class="btn btn-primary btn-xs" style="margin-top:5px"><i class="fa fa-search"></i></button>
                          </div>
                        </div>
                      </td>
                      <td>
                      </td>
                    </tr>
                  </tbody>
                </table>
                </form>
                <form action="{{URL::to('/send-delivery-order')}}" method="post">
                  <div style="overflow-x: scroll;width:100%">
                  <table id="datatable" class="hovertable" style="width:1500px">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>DO No.</th>
                          <th>Date Out</th>
                          <th>Warehouse</th>
                          <th>SO No.</th>
                          <th>Invoice</th>
                          <th>Customer</th>
                          <th>Destination</th>
                          <th>Trucking</th>
                          <th>PO No.</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php $no = 1 ?>
                        @foreach($delivery_order as $list_do)
                        <?php
                          $outdetail = DB::table('ss_outdtl')->join('cd_material','cd_material.material_code','=','ss_outdtl.material_code')->where('no_transaksi','=',$list_do->no_transaksi)->get();
                          //$customers = DB::table('ss_customers')->join('ss_customerdtl','ss_customers.customer_code','=','ss_customerdtl.sold_to_party')->where('ss_customers.customer_code','=',$list_do->customer_code)->where('ss_customerdtl.ship_to_party','=',$list_do->destination)->first();
            						  $customers = DB::table('cd_customers')->where('ship_to_party','=',$list_do->customer_code)->first();
            						  $customer_dtl = DB::table('cd_customers')->where('ship_to_party','=',$list_do->destination)->first();
                        ?>
                        <tr>
                          <td>{{ $no++ }} 
                            <input type="checkbox" name="ck_do[]" value="{{$list_do->no_transaksi}}" id="check-all" class="flat">
                             <a href="{{URL::to('/do-view/'.$list_do->no_transaksi)}}"><button title="Edit" type="button" class="btn btn-info btn-xs" ><i class="fa fa-edit"></i></button></a>
                            <a href="{{URL::to('/do-delete/'.$list_do->no_transaksi)}}"><button title="Delete" type="button" class="btn btn-danger btn-xs" onclick="return confirm('Are you sure you want to delete this delivery order?');"><i class="fa fa-trash"></i></button></a>
                          </td>
                          <td style="width:1%">
                            <p data-toggle="tooltip" data-placement="right" title="<?php foreach($outdetail as $out_dl){ echo $out_dl->material_name.' - '.$out_dl->lot_number."\r\n" ; }; ?>">{{$list_do->no_transaksi}}</p>
                          </td>
                          <td>{{$list_do->date_out}}</td>
                          <td style="width:1%">
                          @foreach($warehouse as $stor)
                          @if($list_do->source == $stor->code)
                          <h6 >{{ $stor->code_name}} </h6>
                          @endif
                          @endforeach</td>
                          <td style="width:1%"><h6 >{{$list_do->so_no}}</h6></td>
                          <td style="width:1%"><h6 >{{$list_do->invoice}}</h6></td>
                          <td><h6 >{{$customers->name}} </h6></td>
                          <td><h6 >{{$customer_dtl->name}} </h6></td>
                          <td><h6 >{{$list_do->trucking}} </h6></td>
                          <td style="width:1%"><h6 >{{$list_do->po_no}}</h6> </td>
                        </tr>
                        @endforeach
                      </tbody>
                    </table>
                  </div>
                  <div class="control-group" >
                    <div class="col-md-9 col-sm-9 col-xs-12" style="margin-top:15px">
                      <button type="submit" class="btn btn-warning">Preview Send Email</button>
                    </div>
                  </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
@stop
@section('script')
<script>
function myFunction() {
    var table = document.getElementById("myTable");
    var row = table.insertRow(2);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    
    cell1.innerHTML = '{{ Form::select("lotnumber[]", array(), null, array("id" => "sLotnumber", "class"=>"select2_single form-control"))  }}';
    cell2.innerHTML = "<input class='form-control' type='text' name='qty_bag[]'>";
    
}
</script>
<script type="text/javascript">
            $(document).ready(function() {
                $("select[name='material_code']").on('change', function(){
                $.post('{{ URL::to('delivery/data') }}', {type: 'lotnumber', id: $("select[name='material_code']").val()}, function(e){
                    $("select[name='lotnumber[]']").html(e);
                });
                
                $('#sMaterial').html('');
                $('#sDesa').html('');
                
            });
            $('#sLotnumber').on('change', function(){
                $.post('{{ URL::to('delivery/data') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
                    $('#sMaterial').html(e);
                });
                $('#sDesa').html('');
            });
            $('#sKecamatan').on('change', function(){
                $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
                    $('#sDesa').html(e);
                });
            });
            });
        </script>
@stop
@section('style')
<style type="text/css">
  table.hovertable {
    font-family: verdana,arial,sans-serif;
    font-size:11px;
    color:#333333;
    border-width: 1px;
    border-color: #999999;
    border-collapse: collapse;
  }
  table.hovertable th {
    background-color:#c3dde0;
    border-width: 1px;
    padding: 8px;
    border-style: solid;
    border-color: #a9c6c9;
  }
  
  table.hovertable td {
    border-width: 1px;
    padding: 8px;
    border-style: solid;
    border-color: #a9c6c9;
  }
</style>
@stop