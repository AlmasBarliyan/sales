<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" type="image/png" href="{{{ asset('images/logo_CJ.png') }}}"/>
  <title>Sales</title>
  
  <!-- Bootstrap core CSS -->
  {{ HTML::style('css/css/layout-styles.css')}}
  {{ HTML::style('css/css/themes/smoothness/jquery-ui-1.8.4.custom.css')}}
  
  {{ HTML::style('css/bootstrap.min.css')}}
  {{ HTML::style('fonts/css/font-awesome.min.css')}}
  {{ HTML::style('css/animate.min.css')}}
  
  <!-- Custom styling plus plugins -->
  {{HTML::style('css/custom.css')}}
  {{HTML::style('css/icheck/flat/green.css')}}
  
  {{HTML::style('js/datatables/jquery.dataTables.min.css')}}
  {{HTML::style('js/datatables/buttons.bootstrap.min.css')}}
  {{HTML::style('js/datatables/fixedHeader.bootstrap.min.css')}}
  {{HTML::style('js/datatables/responsive.bootstrap.min.css')}}
  {{HTML::style('js/datatables/scroller.bootstrap.min.css')}}
  <!-- select2 -->
  {{ HTML::style('css/select/select2.min.css')}}
  
  <!-- jQuery libs -->
  <!-- {{HTML::script('js/jquery.min.js')}} -->
  {{ HTML::script('js/jquery.js')}}
  {{ HTML::script('js/js/jquery-ui.min.js')}}
  {{ HTML::script('js/js/jq-ac-script2.js')}}
    

  <!--
  <script src="https://ajax.aspnetcdn.com/ajax/jquery.ui/1.9.2/jquery-ui.min.js"></script> -->
  <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
        <![endif]-->

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>


<body class="nav-md">

  <div class="container body">


    <div class="main_container">

      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">

          @include('../layouts/sidebar')
        </div>
      </div>

      <!-- top navigation -->
      <div class="top_nav">

        @include('../layouts/nav')

      </div>
      <!-- /top navigation -->

      <!-- page content -->
      <div class="right_col" role="main">
        
          <div class="">
          <div class="x_panel">
            <div class="x_title">
            @foreach($do as $in)
              <h2><a href="{{URL::to('/delivery-order')}}"><button class="btn btn-round btn-info" type="button"><i class="fa fa-arrow-circle-left"></i> Back</button></a> {{$in->no_transaksi}} </h2>
              <ul class="nav navbar-right panel_toolbox">
                
              </ul>
              <div class="clearfix"></div>
            </div>
          <div class="clearfix"></div>

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_content">			
                  <form class="form-horizontal form-label-left input_mask" action="{{URL::to('/update-delivery-order')}}" method="post">
                  <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">  
                    <tbody>
                      <tr>
                        <td>
                          <div class="item form-group">
                            <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">DO No.</label>
                            &emsp;&emsp;&emsp;&emsp;
                            <div class="col-md-4 col-sm-2 col-xs-10">
                              <input type="hidden" name="dotx" value="{{$in->no_transaksi}}">
                              <p id="dono"><input name="no_transaksi" id="dn" value="{{$in->no_transaksi}}" type="text" style="width: 250px;" readonly="" class="form-control" /></p>
                            </div>
                          </div>
                        </td>
                        <td>
                          <div class="item form-group" >
                              <label class="control-label col-md-3 col-sm-3 col-xs-12">PO NO. </label>
                              <div class="col-md-9 col-sm-9 col-xs-12">
                              <input type="hidden" name="pn" value="{{$in->po_no}}">
                              <select name="po" readonly='readonly' class="select2_single form-control" style="width:100%" id="sPo">
                                @foreach($po as $poo)
                                <?php 
                                  $podetail = DB::table('ss_podetail')->where('po_no','=',$in->po_no)->first();
                                ?>
                                  <option value="{{$poo->po_no}}" <?php if ($poo->po_no==$in->po_no) echo 'selected="selected"'; ?>>{{$poo->po_no}}</option>
                                @endforeach
                              </select>
                              </div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <div class="item form-group">
                            <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">Date Out</label>
                            &emsp;&emsp;&emsp;&emsp;
                            <div class="col-md-4 col-sm-2 col-xs-10">
                              <input type="text" style="z-index: 100000;width: 250px;" value="{{date('d-m-Y', strtotime($in->date_out ))}}" name="date_out" id="idTourDateDetails1" class="form-control has-feedback-left""> 
                              <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                              <span id="inputSuccess2Status" class="sr-only">(success)</span>
                            </div>
                          </div>
                        </td>
                        <td>
                          <div class="item form-group" >
                              <label class="control-label col-md-3 col-sm-3 col-xs-12">Customer </label>
                              <div class="col-md-9 col-sm-9 col-xs-12">
                                <select readonly='readonly' name="customer" required="required" class="select2_single form-control" style="width:100%" id="sCustomer">
                                <option></option>
                                  @foreach($customerdtl as $customer)
                                    <option value="{{$customer->ship_to_party}}" <?php if ($in->customer_code==$customer->ship_to_party) echo 'selected="selected"'; ?>>{{$customer->ship_to_party }} - {{$customer->name}}</option>
                                  @endforeach
                                </select>
                              </div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <div class="item form-group" >
                              <label class="control-label col-md-3 col-sm-3 col-xs-12">Trucking </label>
                              <div class="col-md-9 col-sm-9 col-xs-12">
                                <p ><input required="" type="text" style="width: 250px;" class="form-control" value="{{$in->trucking}}" name="trucking"></p>
                              </div>
                          </div>
                        </td>
                        <td>
                          <div class="item form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Destination</label>
                            <div class="col-md-9 col-sm-9 col-xs-12">
                              <select readonly='readonly' name="ship_to_party" required="required" class="select2_single form-control" style="width:100%" id="dl">
                                <option></option>
                                @foreach($customerdtl as $cdtl)
                                  <option value="{{$cdtl->ship_to_party}}" <?php if ($in->destination==$cdtl->ship_to_party) echo 'selected="selected"'; ?>>{{$cdtl->ship_to_party }} - {{$cdtl->name}}</option>
                                @endforeach
                              </select>
                            </div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <div class="item form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Remarks</label>
                            <div class="col-md-9 col-sm-9 col-xs-12">
                              <input type="text" style="width:250px" value="{{$in->remarks}}" class="form-control" name="remarks">
                            </div>
                          </div>
                        </td>
                        <td>
                          <div class="item form-group" >
                              <label class="control-label col-md-3 col-sm-3 col-xs-12">Warehouse </label>
                              <div class="col-md-9 col-sm-9 col-xs-12">
                              <?php
                                    session_start();
                                    $_SESSION["mo"] = $in->source;
                                    $_SESSION["p"] = $in->po_no;
                                  ?>
                              <input type="hidden" name="wrhs" value="{{$in->source}}">
                              <select name="source" required="required" class="select2_single form-control" style="width:100%" id="sWh">
                                <option></option>
                                  @foreach($warehouse as $wh)
                                    <option value="{{$wh->code}}" <?php if ($in->source==$wh->code) echo 'selected="selected"'; ?>>{{$wh->code_name}}</option>
                                  @endforeach
                              </select>
                              </div>
                          </div>
                        </td>
                      </tr>

                      <tr>
                        <td>
                          <div class="item form-group" >
                              <label class="control-label col-md-3 col-sm-3 col-xs-12">SO No. </label>
                              <div class="col-md-9 col-sm-9 col-xs-12">
                              <input type="text" name="so_no" value="{{$in->so_no}}" style="width:250px" class="form-control">
                              </div>
                          </div>
                        </td>
                        <td>
                          <div class="item form-group" >
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">SO Date </label>
                            <div class="col-md-9 col-sm-9 col-xs-12">
                              <input value="{{$in->so_date}}" type="date" name="so_date" class="form-control">
                            </div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <div class="item form-group" >
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Invoice </label>
                            <div class="col-md-9 col-sm-9 col-xs-12">
                              <input type="text" value="{{$in->invoice}}" name="invoice" style="width:250px" class="form-control">
                            </div>
                          </div>
                        </td>
                        <td>
                          <div class="item form-group" >
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Bill Date </label>
                            <div class="col-md-9 col-sm-9 col-xs-12">
                              <input type="date" name="bill_date" value="{{$in->bill_date}}" class="form-control">
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                      <table id="inv" class='table table-striped responsive-utilities jambo_table bulk_action order-list' cellspacing="0">
                      <!-- <table class='table table-striped responsive-utilities jambo_table bulk_action order-list ' id="sProducts"> -->
                          <thead>
                            <tr class='headings'>
                              <th class='column-title' colspan='2' style='text-align:center'>Material </th>
                              <th class='column-title' style='text-align:center'>Lot Number</th>
                              <th class='column-title' style='text-align:center' colspan='2'>Qty In Warehouse</th>
                              <th class='column-title' style='text-align:center' colspan='2'>Qty DO</th>
                            </tr>
                          </thead>
                          <tbody>
                          <?php 
                            $dodetail = DB::table('ss_outdtl')->join('cd_material','cd_material.material_code','=','ss_outdtl.material_code')->where('no_transaksi','=',$in->no_transaksi)->get();
                            $i = 0;
                            $nd = array();

                          ?>
                          @foreach($dodetail as $dd)
                          <?php $produ = DB::table('cd_material')->where('material_code','=',$dd->material_code)->first();
                            $i++;
                            $nd[] = $i;
                            
                           ?>
                            <tr class='even pointer'>
                              <td>
                                <a href="{{URL::route('del-do',[$in->no_transaksi,$in->po_no, $dd->material_code,$dd->lot_number,$dd->qty_out_um,$dd->qty_out_uom,$in->source])}}" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fa fa-trash"></i></a>
                                <input type="text" id="sku{{$i}}" name="material_code[]" value="{{$dd->material_code}}" style="width:80px">
                                <input type="hidden" name="matcod[]" value="{{$dd->material_code}}">
                                <input type="button" name="choice" onClick="selectValue('sku{{$i}}','pir{{$i}}','lot{{$i}}','qty_um{{$i}}','um{{$i}}','qty_uom{{$i}}','uom{{$i}}','out_um{{$i}}','out_uom{{$i}}','size{{$i}}','qty_out_um{{$i}}','qty_out_uom{{$i}}')" value="..." title="Cari Item" style="width:20px">
                              </td>
                              <td>
                                <input type="text" name="material_name[]" value="{{$dd->material_name}}" id="pir{{$i}}" />
                              </td>
                              <td>
                                <input type="hidden" name="lotno[]" value="{{$dd->lot_number}}" />
                                <input type="text" name="lot_number[]" id="lot{{$i}}" style="width:85px" value="{{$dd->lot_number}}" />
                              </td>
                              <td>
                                <input style="width:80px;background-color: #cabebe;" id="qty_um{{$i}}" type="text" readonly="readonly" />
                                <input style="width:40px;background-color: #cabebe;" id="um{{$i}}" readonly="readonly"/>
                              </td>
                              <td>
                                <input style="width:80px;background-color: #cabebe;" id="qty_uom{{$i}}"  type="text" readonly="readonly" />
                                <input style="width:30px;background-color: #cabebe;" id="uom{{$i}}" class="tInput" readonly="readonly"/>
                              </td>
                              <td>
                                <input type="hidden" name="size[]" id="size{{$i}}" class="tInput" value="{{$produ->material_size}}" />
                                <input style="width:80px" type="hidden" name="q_o_u[]" value="{{$dd->qty_out_um}}" />
                                <input style="width:80px" type="text" id="qty_out_um{{$i}}" name="qty_out_um[]" value="{{$dd->qty_out_um}}" />
                                <input style="width:40px" id="out_um{{$i}}" class="tInput" readonly="readonly" value="{{$dd->um}}" />
                              </td>
                              <td>
                                <input style="width:80px" type="hidden" name="q_o_uo[]" value="{{$dd->qty_out_uom}}" />
                                <input style="width:80px" type="text" id="qty_out_uom{{$i}}" name="qty_out_uom[]" value="{{$dd->qty_out_uom}}" />
                                <input style="width:30px" id="out_uom{{$i}}" class="tInput" readonly="readonly" value="{{$dd->uom}}" />
                              </td>
                            </tr>  
                            @endforeach
                          </tbody>
                      </table>
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12" style="text-align:left">
                        <a href="#" id="addrow" class="btn btn-primary"><span> + Add Row</span></a>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
                        <button type="submit" class="btn btn-success">Save</button>
                      </div>
                    </div>

                  </form>
              	@endforeach
             	</div>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
      </div>

        <div id="custom_notifications" class="custom-notifications dsp_none">
          <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
          </ul>
          <div class="clearfix"></div>
          <div id="notif-group" class="tabbed_notifications"></div>
        </div>
        {{HTML::script('js/bootstrap/bootstrap.2.3.1.min.js')}}
        
        <!-- bootstrap progress js -->
        {{ HTML::script('js/progressbar/bootstrap-progressbar.min.js')}}
        <!-- icheck -->
        {{ HTML::script('js/icheck/icheck.min.js')}}

        {{ HTML::script('js/custom.js')}}
        <!-- CK Editor -->
        {{ HTML::script('https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js')}}
        <script type="text/javascript">
          $('#idTourDateDetails1').datepicker({
               dateFormat: 'dd-mm-yy',
               changeMonth: true,
               changeYear: true,
               altField: "#idTourDateDetailsHidden",
               altFormat: "yy-mm-dd"
           });
        </script>
        <!-- form validation -->
        {{ HTML::script('js/validator/validator.js')}}
        <script type="text/javascript">
          $(document).ready(function() {
                $("#sWh").on('change', function(){
                  $.post('{{ URL::to('delivery/show') }}', {type: 'dono', wh: $("#sWh").val(), dt: $("#idTourDateDetails1").val() },function(e){
                      $("#dono").html(e);
                  });
                  $.post('{{ URL::to('delivery/show') }}', {type: 'po', wh: $("#sWh").val(), pono: $("#pono").val(), d: $("#idTourDateDetails1").val()}, function(e){
                      $("#inv").html(e);
                  });
                });
            });
        </script>
        <script type="text/javascript">
          $(document).ready(function() {
            $("#idTourDateDetails1").on('change', function(){
              $.post('{{ URL::to('delivery/show') }}', {type: 'dono', wh: $("#sWh").val(), dt: $("#idTourDateDetails1").val() },function(e){
                  $("#dono").html(e);
              });
            });
          });
        </script>
        <script>
          // initialize the validator function
          validator.message['date'] = 'not a real date';

          // validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
          $('form')
            .on('blur', 'input[required], input.optional, select.required', validator.checkField)
            .on('change', 'select.required', validator.checkField)
            .on('keypress', 'input[required][pattern]', validator.keypress);

          $('.multi.required')
            .on('keyup blur', 'input', function() {
              validator.checkField.apply($(this).siblings().last()[0]);
            });

          // bind the validation to the form submit event
          //$('#send').click('submit');//.prop('disabled', true);

          $('form').submit(function(e) {
            e.preventDefault();
            var submit = true;
            // evaluate the form using generic validaing
            if (!validator.checkAll($(this))) {
              submit = false;
            }

            if (submit)
              this.submit();
            return false;
          });

          /* FOR DEMO ONLY */
          $('#vfields').change(function() {
            $('form').toggleClass('mode2');
          }).prop('checked', false);

          $('#alerts').change(function() {
            validator.defaults.alerts = (this.checked) ? false : true;
            if (this.checked)
              $('form .alert').remove();
          }).prop('checked', false);
        </script>

        {{ HTML::script('js/select/select2.full.js')}}
        <script>
            $(document).ready(function() {
                $(".select2_single").select2({
                    placeholder: "Select...",
                    allowClear: true
                });
                $(".select2_group").select2({});
                $(".select2_multiple").select2({
                    maximumSelectionLength: 4,
                    placeholder: "With Max Selection limit 4",
                    allowClear: true
                });
            });
        </script>

        <!-- Datatables -->
        {{HTML::script('js/datatables/jquery.dataTables.min.js')}}
        {{HTML::script('js/datatables/dataTables.bootstrap.js')}}
        {{HTML::script('js/datatables/dataTables.buttons.min.js')}}
        {{HTML::script('js/datatables/buttons.bootstrap.min.js')}}
        {{HTML::script('js/datatables/jszip.min.js')}}
        {{HTML::script('js/datatables/pdfmake.min.js')}}
        {{HTML::script('js/datatables/vfs_fonts.js')}}
        {{HTML::script('js/datatables/buttons.html5.min.js')}}
        {{HTML::script('js/datatables/buttons.print.min.js')}}
        {{HTML::script('js/datatables/dataTables.fixedHeader.min.js')}}
        
        {{HTML::script('js/datatables/dataTables.responsive.min.js')}}
        {{HTML::script('js/datatables/responsive.bootstrap.min.js')}}
        {{HTML::script('js/datatables/dataTables.scroller.min.js')}}
        {{HTML::script('js/pace/pace.min.js')}}
        <script type="text/javascript">
            $(document).ready(function() {
                $("#sCustomer").on('change', function(){
                $.post('{{ URL::to('delivery/show') }}', {type: 'cus', id: $("#sCustomer").val()}, function(e){
                    $("#dl").html(e);
                });
                
                $('#sMaterial').html('');
                $('#sDesa').html('');
            });
            });
        </script>
        <script type="text/javascript">
function updateValue(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue1(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue2(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue3(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue4(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue5(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue6(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue7(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue8(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue9(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue10(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue11(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
</script>
<script>
          $(document).ready(function () {
            var counter = 1;
            var co = <?php echo end($nd); ?> ;
            $("#addrow").on("click", function () {
              counter++;
              co++;
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><a class="deleteRow"><i class="fa fa-trash"></i> </a><input type="hidden" name="matcod[]"><input type="text" id="sku'+ co +'" name="material_code[]" style="width:80px"> <input type="button" name="choice" onClick="selectValue(\''+'sku'+co+'\',\''+'pir'+co+'\',\''+'lot'+co+'\',\''+'qty_um'+co+'\',\''+'um'+co+'\',\''+'qty_uom'+co+'\',\''+'uom'+co+ '\',\''+'out_um'+co+'\',\''+'out_uom'+co+'\',\''+'size'+co+'\',\''+'qty_out_um'+co+'\',\''+'qty_out_uom'+co+'\')" value="..." style="width:20px"></td>';
              cols += '<td><input type="text" id="pir'+ co +'" name="material_name[]"/></td>';
              cols += '<td><input type="text" id="lot'+ co +'" name="lot_number[]" style="width:85px"/><input type="hidden" name="lotno[]"</td>';
              cols += '<td><input style="width:80px" type="text" id="qty_um'+ co +'" name="qty_um[]" readonly="readonly" /><input type="hidden" name="size[]" id="size'+ co +'" class="tInput" /> <input style="width:40px" id="um'+ co +'" class="tInput" readonly="readonly"/></td><td><input style="width:80px" type="text" id="qty_uom'+ co +'" name="qty_uom[]" readonly="readonly" /> <input style="width:30px" id="uom'+ co +'" class="tInput" readonly="readonly"/></td>';
              cols += '<td><input style="width:80px" type="text" id="qty_out_um'+ co +'" name="qty_out_um[]" /> <input style="width:40px" id="out_um'+ co +'" class="tInput" readonly="readonly"/></td><td><input style="width:80px" type="text" id="qty_out_uom'+ co +'" name="qty_out_uom[]" /> <input style="width:30px" id="out_uom'+ co +'" class="tInput" readonly="readonly"/></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);

            });
            
            $("table.order-list").on("input", 'input[name^="price"], input[name^="qty_out_um"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
          function selectValue(id,pir,lot,qty_um,um,qty_uom,uom,out_um,out_uom,size,qty_out_um,qty_out_uom)
              {
                 var counter = 1;
                 var co = 1;
                  var myData = new Array('sku'+co, 'pir=pir'+co);
                  var url = myData.join('&');
                  // open popup window and pass field id
                  
                    window.open('../sku1.php?id=' + encodeURIComponent(id)+'&pir='+encodeURIComponent(pir)+'&lot='+encodeURIComponent(lot)+'&qty_um='+encodeURIComponent(qty_um)+'&um='+encodeURIComponent(um)+'&qty_uom='+encodeURIComponent(qty_uom)+'&uom='+encodeURIComponent(uom)+'&out_um='+encodeURIComponent(out_um)+'&out_uom='+encodeURIComponent(out_uom)+'&size='+encodeURIComponent(size)+'&qty_out_um='+encodeURIComponent(qty_out_um)+'&qty_out_uom='+encodeURIComponent(qty_out_uom),'popuppage',
                    'width=1050,toolbar=1,resizable=1,scrollbars=yes,height=400,top=100,left=100');  
                  
                  
              }
          function selectValue1(dn)
          {
             var counter = 1;
             var co = 1;
              var myData = new Array('sku'+co, 'pir=pir'+co);
              var url = myData.join('&');
              // open popup window and pass field id
              
                window.open('../send.php?do_no='+ encodeURIComponent(dn),'popuppage',
                'width=1050,toolbar=1,resizable=1,scrollbars=yes,height=900,top=100,left=100');  
              
              
          }  
          function calculateRow(row) {
            var size = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty_out_um"]').val();
            var qty_um = +row.find('input[name^="qty_um"]').val();
            if (qty > qty_um ) {
              alert("Quantity Melebihi Stok");
              row.find('input[name^="qty_out_um"]').val("");
              row.find('input[name^="qty_out_uom"]').val("");
            }
            else{
              row.find('input[name^="qty_out_uom"]').val((size * qty));  
            }
            
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
        <script>
          var handleDataTableButtons = function() {
              "use strict";
              0 !== $("#datatable-buttons").length && $("#datatable-buttons").DataTable({
                dom: "Bfrtip",
                buttons: [{
                  extend: "copy",
                  className: "btn-sm"
                }, {
                  extend: "csv",
                  className: "btn-sm"
                }, {
                  extend: "excel",
                  className: "btn-sm"
                }, {
                  extend: "pdf",
                  className: "btn-sm"
                }, {
                  extend: "print",
                  className: "btn-sm"
                }],
                responsive: !0
              })
            },
            TableManageButtons = function() {
              "use strict";
              return {
                init: function() {
                  handleDataTableButtons()
                }
              }
            }();
        </script>
        <script type="text/javascript">
          $(document).ready(function() {
            $('#datatable').dataTable();
            $('#datatable-keytable').DataTable({
              keys: true
            });
            $('#datatable-responsive').DataTable();
            $('#datatable-scroller').DataTable({
              ajax: "js/datatables/json/scroller-demo.json",
              deferRender: true,
              scrollY: 380,
              scrollCollapse: true,
              scroller: true
            });
            var table = $('#datatable-fixed-header').DataTable({
              fixedHeader: true
            });
          });
          TableManageButtons.init();
        </script>
</body>

</html>