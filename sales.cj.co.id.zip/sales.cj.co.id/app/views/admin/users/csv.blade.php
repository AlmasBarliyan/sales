<table>
 <tbody>
  <tr>
   <td>Created At</td>
   <td>Name</td>
   <td>Email</td>
  </tr>
  @foreach($users as $user)
  <tr>
   <td></td>
   <td>{{$user['employee_name']}}</td>
   <td>{{$user['email']}}</td>
  </tr>
  @endforeach
 </tbody>
</table>