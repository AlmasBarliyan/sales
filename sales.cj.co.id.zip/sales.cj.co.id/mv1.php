
<?php
  session_start();
  $con = mysql_connect('localhost', 'root', 'admin1234'); 
 if (!$con) 
   { 
   die('Could not connect to server: ' . mysql_error()); 
   } 
   $db=mysql_select_db("cj_local_sales_do", $con); 

    if (!$db) 
   { 
   die('Could not connect to DB: ' . mysql_error()); 
   } 



 ?> 
<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Product God In Warehouse</title>
  <!-- Bootstrap core CSS -->
  <style type="text/css">
    table.hovertable {
      font-family: verdana,arial,sans-serif;
      font-size:11px;
      color:#333333;
      border-width: 1px;
      border-color: #999999;
      border-collapse: collapse;
    }
    table.hovertable th {
      background-color:#c3dde0;
      border-width: 1px;
      padding: 8px;
      border-style: solid;
      border-color: #a9c6c9;
    }
    table.hovertable tr {
      background-color:#d4e3e5;
    }
    table.hovertable td {
      border-width: 1px;
      padding: 8px;
      border-style: solid;
      border-color: #a9c6c9;
    }
  </style>  
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="js/datatables/jquery.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="js/datatables/responsive.bootstrap.min.css">
  <script type="text/javascript" src="js/jquery.min.js"> </script>
  
  <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
        <![endif]-->

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>


<body class="nav-md">
<div class="container body">


  <div class="main_container">
  <!-- page content -->
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>

        </h3>
      </div>

      <div class="title_right">
        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
          <div class="input-group">
            
          </div>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_content">
          <form action="" method="POST">
            <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">
              <tbody>
                <tr>
                  <td>
                    <div class="form-group" >
                      <label class="control-label col-md-1 col-sm-1 col-xs-12" style="margin-top:10px">Sales</label>
                      <div class="col-md-3 col-sm-3 col-xs-12">
                        <select name="kategori" class="form-control">
                          <option disabled selected value>Choose</option>
                          <?php if ($_SESSION['ktg'] == 'B2B01') { ?>
                            <option value="B2B02" >B2B FOOD</option>
                            <option value="B2B01" selected="selected">B2B FEED</option>
                            <option value="B2C01">B2C Masita</option>
                          <?php } elseif ($_SESSION['ktg'] == 'B2B02') { ?>
                            <option value="B2B02" selected="selected">B2B FOOD</option>
                            <option value="B2B01" >B2B FEED</option>
                            <option value="B2C01">B2C Masita</option>
                          <?php } elseif ($_SESSION['ktg'] == 'B2C01') { ?>
                            <option value="B2B02" >B2B FOOD</option>
                            <option value="B2B01">B2B FEED</option>
                            <option value="B2C01" selected="selected">B2C Masita</option>
                          <?php }else{ ?>
                            <option value="B2B02">B2B FOOD</option>
                            <option value="B2B01">B2B FEED</option>
                            <option value="B2C01">B2C Masita</option>
                            <?php } ?>                          
                        </select>
                      </div>
                      <label class="control-label col-md-2 col-sm-2 col-xs-12" style="margin-top:10px;margin-left:10px">Warehouse</label>
                      <div class="col-md-3 col-sm-3 col-xs-12">
                        <select name="storage" class="form-control">
                          <option disabled selected value>Choose</option>
                          <?php if ($_SESSION['storage'] == '8001') { ?>
                            <option value="8001" selected="selected">Cikarang</option>
                            <option value="8002">Cakung</option>
                            <option value="8003">Surabaya</option>
                          <?php } elseif ($_SESSION['storage'] == '8002') {?>
                            <option value="8001">Cikarang</option>
                            <option value="8002" selected="selected">Cakung</option>
                            <option value="8003">Surabaya</option>
                          <?php } elseif ($_SESSION['storage'] == '8003') { ?>
                            <option value="8001">Cikarang</option>
                            <option value="8002">Cakung</option>
                            <option value="8003" selected="selected">Surabaya</option>
                          <?php }?>
                        </select>
                      </div>
                      <div class="col-md-1 col-sm-1 col-xs-12">
                        <button type="submit" title="Search" class="btn btn-primary btn-xs" style="margin-top:5px">Search</button>
                      </div>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
            </form>
            <table id="datatable-responsive" class="hovertable" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>Material Code</th>                       
                  <th>Material Name</th> 
                  <th>Lot Number</th> 
                  <th>Qty In Warehouse</th>  
                </tr> 
              </thead>
              <tbody>
              <?php 
                if (!empty($_REQUEST['storage']) and !empty($_REQUEST['kategori'])) {
                
                $storage = $_REQUEST['storage'];   
                $ktg = $_REQUEST['kategori'];   
                
                $_SESSION['storage'] = $storage;
                $_SESSION['ktg'] = $ktg;
                $sql = "select * from ss_invmonthly im left join cd_material mt on mt.material_code = im.material_code
                        where im.storage ='$storage' and mt.material_ktg='$ktg'";
                //$sql="select * from cd_material ";
                $result=mysql_query($sql);
                 while($rows=mysql_fetch_array($result)){
                  if ($rows['status'] == 'B') {
                    
              ?> 

                <tr style="cursor:pointer;background-color:red" title="Click To Choose" onClick="sendValue('<?php echo $rows['material_code']; ?>','<?php echo $rows['lot_number']; ?>','<?php echo $rows['end_qty_um']; ?>','<?php echo $rows['storage']; ?>')"> 
                    <td><center><?php echo $rows['material_code']; ?></td> 
                    <td><center><?php echo $rows['material_name']; ?></td> 
                    <td><center><?php echo $rows['lot_number']; ?></td> 
                    <td><center><?php echo $rows['end_qty_um']; ?> <?php echo $rows['um']; ?></td> 
                </tr>                                    

              <?php              
                }elseif ($rows['status'] == 'G') { ?>
                  <tr style="cursor:pointer" title="Click To Choose" onClick="sendValue('<?php echo $rows['material_code']; ?>','<?php echo $rows['lot_number']; ?>','<?php echo $rows['end_qty_um']; ?>','<?php echo $rows['storage']; ?>')"> 
                    <td><center><?php echo $rows['material_code']; ?></td> 
                    <td><center><?php echo $rows['material_name']; ?></td> 
                    <td><center><?php echo $rows['lot_number']; ?></td> 
                    <td><center><?php echo $rows['end_qty_um']; ?> <?php echo $rows['um']; ?></td> 
                </tr>  
                  <?php
                }      
                }
              }
              ?> 
              </tbody> 
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="custom_notifications" class="custom-notifications dsp_none">
    <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
    </ul>
    <div class="clearfix"></div>
    <div id="notif-group" class="tabbed_notifications"></div>
  </div>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  
  <!-- bootstrap progress js -->
  <script type="text/javascript" src="js/progressbar/bootstrap-progressbar.min.js"></script>
  <!-- icheck -->
  <script type="text/javascript" src="js/icheck/icheck.min.js"></script>
  
  <script type="text/javascript" src="js/custom.js"></script>        
  <script type="text/javascript">
    function sendValue(value,value1,value2,value3)
    {
        var matcd = <?php echo json_encode($_GET['matcd']); ?>;
        var lotnum = <?php echo json_encode($_GET['lotnum']); ?>;
        var qtty = <?php echo json_encode($_GET['qtty']); ?>;
        var stor = <?php echo json_encode($_GET['stor']); ?>;
        
        
        window.opener.updateValue4(matcd, value);
        window.opener.updateValue5(lotnum, value1);
        window.opener.updateValue6(qtty, value2);
        window.opener.updateValue7(stor, value3);
        window.close();
        
    }
  </script>
  <!-- Datatables-->
  <script type="text/javascript" src="js/datatables/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="js/datatables/dataTables.bootstrap.js"></script>
  <script type="text/javascript" src="js/datatables/dataTables.buttons.min.js"></script>
  <script type="text/javascript" src="js/datatables/buttons.bootstrap.min.js"></script>
  <script type="text/javascript" src="js/datatables/jszip.min.js"></script>
  <script type="text/javascript" src="js/datatables/pdfmake.min.js"></script>
  <script type="text/javascript" src="js/datatables/vfs_fonts.js"></script>
  <script type="text/javascript" src="js/datatables/buttons.html5.min.js"></script>
  <script type="text/javascript" src="js/datatables/buttons.print.min.js"></script>
  <script type="text/javascript" src="js/datatables/dataTables.fixedHeader.min.js"></script>
  <script type="text/javascript" src="js/datatables/dataTables.keyTable.min.js"></script>
  <script type="text/javascript" src="js/datatables/dataTables.responsive.min.js"></script>
  <script type="text/javascript" src="js/datatables/responsive.bootstrap.min.js"></script>
  <script type="text/javascript" src="js/datatables/dataTables.scroller.min.js"></script>
  <script type="text/javascript" src="js/pace/pace.min.js"></script>        
  <script type="text/javascript">
    $(document).ready(function() {
      $('#datatable').dataTable();
      $('#datatable-keytable').DataTable({
        keys: true
      });
      $('#datatable-responsive').DataTable();
      $('#datatable-scroller').DataTable({
        ajax: "js/datatables/json/scroller-demo.json",
        deferRender: true,
        scrollY: 380,
        scrollCollapse: true,
        scroller: true
      });
      var table = $('#datatable-fixed-header').DataTable({
        fixedHeader: true
      });
    });
    TableManageButtons.init();
  </script>
</body>

</html> 