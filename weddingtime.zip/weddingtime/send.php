<?php
$nama = $_POST['nama'];
$email = $_POST['email'];
$rsvp = $_POST['rsvp'];
$notes = $_POST['notes'];

require_once "vendor/autoload.php";

$mail = new PHPMailer;

//Enable SMTP debugging. 
$mail->SMTPDebug = 3;                               
//Set PHPMailer to use SMTP.
$mail->isSMTP();            
//Set SMTP host name                          
$mail->Host = "smtp.gmail.com";
//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;                          
//Provide username and password     
$mail->Username = "wemarycom@gmail.com";                 
$mail->Password = "shafir14";                           
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "ssl";                           
//Set TCP port to connect to 
$mail->Port = 465;                                   

$mail->From = $email;
$mail->FromName = $nama;

$mail->addAddress("almasbarliyan@gmail.com", "Almas");

$mail->isHTML(true);

$mail->Subject = "RSVP from ".$nama;
$mail->Body = "Atas nama <b>".$nama."</b> bahwa pada tanggal tersebut <b>&quot;".$rsvp."&quot;</b><br>Notes : <br>&quot;".$notes."&quot;";
$mail->AltBody = "This is the plain text version of the email content";

if(!$mail->send()) 
{
    echo "Mailer Error: " . $mail->ErrorInfo;
} 
else 
{
    header('location:index.html');
}
?>