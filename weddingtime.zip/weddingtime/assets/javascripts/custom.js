$(document).ready(function() {

/* 
=============================================== 
OwlCarousel Heading Hero Image
=============================================== 
*/
	"use strict";
	$("#hero-images-wrapper").owlCarousel({
		autoPlay: true,
		navigation: false,
		pagination: false,
		slideSpeed: 1000,
		paginationSpeed: 1000,
		singleItem: true,
		transitionStyle: "fade"
	});

/* 
=============================================== 
OwlCarousel Friends Says Testimony
=============================================== 
*/

	$("#testimony-carousel").owlCarousel({
		autoPlay: true,
		navigation: false,
		pagination: false,
		slideSpeed: 1000,
		paginationSpeed: 1000,
		singleItem: true,
		transitionStyle: "fade"
	});

/* 
=============================================== 
OwlCarousel Blog
=============================================== 
*/
	
	$("#blog-carousel").owlCarousel({
		autoPlay: true,
		navigation: false,
		pagination: false,
		slideSpeed: 1000,
		paginationSpeed: 1000,
		singleItem: true,
		transitionStyle: "fade"
	});

	$(".scroll-info a[href^='#']").on('click', function(e) {
		e.preventDefault();
		$('html, body').animate({
			scrollTop: $(this.hash).offset().top-80
		}, 1000);
	});

/* 
=============================================== 
Preloader
=============================================== 
*/

	$(".preloader").addClass('animated fadeOut');
	setTimeout(function(){
	$(".preloader").addClass('loaded');
	}, 1000);

	$("#open-letter").click(function(){
		$(".top-card-wedding").addClass("top-animation");
		$(".top-card-wedding").removeClass("topdown-animation");
		
		$(".bottom-card-wedding").addClass("bottomtop-animation");
		$(".bottom-card-wedding").removeClass("bottomdown-animation");

		$(".center-card-content").addClass("fadeOut");

		$(".content").addClass("open-card animated fadeIn");
		$(".content").removeClass("hide");
	});

/* 
=============================================== 
Countdown
=============================================== 
*/

	$('#wedding-timer').countdown('2016/5/9', function(event) {
		var $this = $(this).html(event.strftime(''
			+ '<div>%D  <span>Days</span>  </div>'
			+ '<div>%H  <span>Hours</span>  </div>'
			+ '<div>%M <span> Minutes</span>  </div>'
			+ '<div>%S  <span>Seconds</span> </div>'));
	});

/* 
=============================================== 
Fancy Box
=============================================== 
*/

	$('.fancybox').fancybox({
		helpers: {
			overlay: {
				locked: false
			}
		}
	});

});

/* 
=============================================== 
Google Map
=============================================== 
*/

// Google Map
function initWeddingMap() {

	var myLatLng = {
		lat: -6.917464,
		lng: 107.619123
	};

	var mapWedding = new google.maps.Map(document.getElementById('wedding-map'), {
		zoom: 11,
		center: myLatLng
	});

	var mapWeddingParty = new google.maps.Map(document.getElementById('wedding-party-map'), {
		zoom: 11,
		center: myLatLng
	});

	var marker = new google.maps.Marker({
		position: myLatLng,
		map: mapWedding,
		title: 'Wedding Location'
	});
	var marker = new google.maps.Marker({
		position: myLatLng,
		map: mapWeddingParty,
		title: 'Wedding Party'
	});
}
