@extends('products.table')
@section('content')
		<div class="">
          <div class="page-title">
            <div class="title_left">
              <h3>Return</h3>
            </div>
            <div class="title_right">
              <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                <div class="input-group">
                  <input type="text" class="form-control" placeholder="Search for...">
                  <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                </div>
              </div>
            </div>
          </div>
      <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Return Product </h2>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <form class="form-horizontal form-label-left input_mask" action="{{URL::to('/return-create')}}" method="post">
                  <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">                    
                    <tbody>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">No. Return</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                               <p id="dono"><input name="no_transaksi" type="text" style="width: 250px;" readonly="" class="form-control" /></p>
                                                          </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Warehouse </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                  <select name="source" class="select2_single form-control" id="sStorage">
                                    <option disabled selected value>-- Select Warehouse --</option>
                                    @foreach($warehouse as $storage)
                                      <option value="{{$storage->code}}">{{$storage->code_name}}</option>
                                    @endforeach
                                  </select>
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">Date Out</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <input name="date_out" type="date" style="width: 250px;" value="<?php echo date('Y-m-d')?>" class="form-control" />
                                                          </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Destination </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                  <select name="destination" class="select2_single form-control" id="sDestination">
                                    <option></option>
                                    @foreach($pabrik as $pb)
                                      <option value="{{$pb->code}}">{{$pb->code_name}}</option>
                                    @endforeach
                                  </select>
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">No. Surat Jalan</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <?php 
                                /*$no_in = DB::select(DB::raw("select max(substr(no_srtjln,-5,5)) as max from ss_outmaster where(select max(substr(no_srtjln,-5,5)) from ss_outmaster )"));*/
                                $no_in = DB::select(DB::raw("select max(substr(no_srtjln,-5,5)) as max from ss_outmaster where(select max(substr(no_srtjln,-5,5)) from ss_outmaster where substr(no_srtjln,1,8)= DATE_FORMAT(NOW(),'%Y%m%d') )"));
                                ?>
                                <!-- @foreach($no_in as $noin) -->
                                <!-- <input style="width: 250px;" type="text" readonly="" class="form-control" value="{{date('Ymd'). sprintf('%05d', $noin->max+1)}}" name="no_srtjln"> -->
                                <input style="width: 250px;" type="text" required="" class="form-control"  name="no_srtjln">
                                <!-- @endforeach   -->
                              </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Trucking </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                  <input type="text" class="form-control" required="" name="trucking">
                                </div>
                            </div>
                          </td>
                        </tr>
                         <tr>
                          <td>
                            <div class="item form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Remarks</label>
                          <div class="col-md-9 col-sm-9 col-xs-12">
                            <input type="text" style="width:250px"  class="form-control" name="remarks">
                          </div>
                        </div>
                          </td>
                          <td>
                            
                          </td>
                        </tr>
                        

                    </tbody>
                  </table>
                    <div>
                      <table id="sProducts" class='table table-striped responsive-utilities jambo_table bulk_action order-list' cellspacing="0" width="100%">
                      <!-- <table class='table table-striped responsive-utilities jambo_table bulk_action order-list ' id="sProducts"> -->
                          <thead>
                            <tr class='headings'>
                              <th class='column-title' colspan='2'>Material </th>
                              <th class='column-title'>Lot Number</th>
                              <th class='column-title' >Qty BAD</th>
                              <th class='column-title' style='text-align:center' colspan='4'>Qty Return</th>
                            </tr>
                          </thead>
                          <tbody>
                              <p ></p>
                          </tbody>
                      </table>
                    </div>                    
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
                        <button type="submit" class="btn btn-success">Save</button>
                      </div>
                    </div>

                  </form>
                </div>
                
              </div>
			     </div>
        </div>
		</div>
@stop
@section('script')
<script>
          $(document).ready(function () {
            var counter = 1;
            
            $("#addrow").on("click", function () {
              counter++;
              
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><input type="text" name="product' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="price' + counter + '"/></td>';
              cols += '<td><input type="text" name="qty' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="linetotal' + counter + '" readonly="readonly"/></td>';
              cols += '<td><a class="deleteRow"> x </a></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);
            });
            
            $("table.order-list").on("change", 'input[name^="price"], input[name^="qty"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
            
          function calculateRow(row) {
            var price = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty"]').val();
            var end_qty = +row.find('input[name^="end_qty"]').val();
            if (qty > end_qty ) {
              alert("Quantity Melebihi Stok BAD");
              row.find('input[name^="qty"]').val("");
              row.find('input[name^="uom"]').val("");
            }
            else{
              row.find('input[name^="uom"]').val((price * qty));  
            }
            
            
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#sStorage').on('change', function(){
        $.post('{{ URL::to('site/show') }}', {type: 'storage', id: $('#sStorage').val()}, function(e){
            $('#sProducts').html(e);

        });
        
        });
        $('#sMaterial').html('');
        $('#sDesa').html('');
        
    
    $('#sLotnumber').on('change', function(){
        $.post('{{ URL::to('site/return') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
            $('#sMaterial').html(e);
        });
        $('#sDesa').html('');
    });
    $('#sKecamatan').on('change', function(){
        $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
            $('#sDesa').html(e);
        });
    });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#sDestination').on('change', function(){
        $.post('{{ URL::to('site/show') }}', {type: 'destination', id: $('#sDestination').val()}, function(e){
            $('#dono').html(e);
        });
        
        $('#sMaterial').html('');
        $('#sDesa').html('');
        
    });
   
    });
</script>
@stop