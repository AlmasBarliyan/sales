<?php
/**
* 
*/
class ReturnMaster extends Eloquent
{
	protected $table = 'ss_outmaster';
	protected $fillable = array(
		'company',
		'plant',
		'no_transaksi',
		'date_out',
		'status',
		'source',
		'destination',
		'trucking',
		'no_srtjln',
		'remarks',
		'user_create',
		'user_update'
		);
	public function ReturnDetail(){
		return $this->belongsToMany('Products','ss_outdtl','material_code','no_transaksi')->withPivot('material_code','lot_number','qty_out','status');
	}
	public function InvDaily(){
		return $this->belongsToMany('Products','ss_invdaily','material_code','id')->withPivot('company','plant','material_code','lot_number','in_daily_qty','out_daily_qty','storage','date_ym','status','created_at','updated_at');
	}
}