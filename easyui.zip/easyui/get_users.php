<?php

include 'conn.php';
$rs = mysql_query('select *, (select name from cd_customers cs where cs.ship_to_party = pm.customer_code)customer_name,
	(select name from cd_customers cs where cs.ship_to_party = pm.ship_to_party)ship_to_party, cd.code_name
	from ss_pomaster pm
	left join cd_code cd on cd.code = pm.source');
$result = array();
while($row = mysql_fetch_object($rs)){
	array_push($result, $row);
}

echo json_encode($result);

?>