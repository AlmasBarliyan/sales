<?php
  session_start();
  if ($_SESSION['mo'] == null or $_SESSION['p']== null) {?>
  <script type="text/javascript">
    alert("Belum Memilih Number PO atau Warehouse!!");
    window.close();
  </script>
<?php
  }else{
  $con = mysql_connect('localhost', 'root', 'admin1234'); 
 if (!$con) 
   { 
   die('Could not connect to server: ' . mysql_error()); 
   } 
   $db=mysql_select_db("cj_local_sales_do", $con); 

    if (!$db) 
   { 
   die('Could not connect to DB: ' . mysql_error()); 
   } 

$sql = "select distinct im.*, mt.*,pd.* from ss_invmonthly im left join ss_podetail pd on  pd.material_code=im.material_code left join cd_material mt on mt.material_code=im.material_code where pd.po_no ='{$_SESSION['p']}' and im.`status`='G' and im.end_qty_um!=0 and storage='{$_SESSION['mo']}' and pd.qty_in_do_um < pd.qty_um";
//$sql="select * from cd_material ";
$result=mysql_query($sql);

 ?> 
<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Sales</title>
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" type="text/css" href="css/css/layout-styles.css">
  <link rel="stylesheet" type="text/css" href="css/css/themes/smoothness/jquery-ui-1.8.4.custom.css">

  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="fonts/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/animate.min.css">
  
  
  <link rel="stylesheet" type="text/css" href="css/icheck/flat/green.css">
  
  <link rel="stylesheet" type="text/css" href="js/datatables/jquery.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="js/datatables/buttons.bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="js/datatables/fixedHeader.bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="js/datatables/responsive.bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="js/datatables/scroller.bootstrap.min.css">
  
  <!-- select2 -->
  <link rel="stylesheet" type="text/css" href="css/select/select2.min.css">

  <link rel="stylesheet" type="text/css" href="">
  <link rel="stylesheet" type="text/css" href="js/jquery-ui.1.9.2.min.js">
  <script type="text/javascript" src="js/jquery.min.js"> </script>
  <script type="text/javascript" src="js/jquery-ui.1.9.2.min.js"> </script>
  
  <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
        <![endif]-->

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>


<body class="nav-md">

  <div class="container body">


    <div class="main_container">

      <!-- page content -->
      <div class="">
          <div class="page-title">
            <div class="title_left">
              <h3>

              </h3>
            </div>

            <div class="title_right">
              <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                <div class="input-group">
                  
                </div>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_content">
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                    <thead>
                      <tr>
                          <th></th> 
                          <th>Material Code</th>                       
                          <th>Material Name</th> 
                          <th>Lot Number</th> 
                          <th>Qty In Warehouse</th>  
                      </tr> 
                    </thead>
                    <tbody>
<?php 

   while($rows=mysql_fetch_array($result)){
?> 
  <tr> 
      <td><input type=button value="Select" onClick="sendValue('<?php echo $rows['material_code']; ?>','<?php echo $rows['material_name']; ?>','<?php echo $rows['lot_number']; ?>','<?php echo $rows['end_qty_um']; ?>','<?php echo $rows['um']; ?>','<?php echo $rows['end_qty_uom']; ?>','<?php echo $rows['uom']; ?>','<?php echo $rows['um']; ?>','<?php echo $rows['uom']; ?>','<?php echo $rows['material_size']; ?>','<?php echo $rows['qty_um']; ?>','<?php echo $rows['qty_uom']; ?>','<?php echo $rows['qty_in_do_um']; ?>')" /></td>
      <td><center><?php echo $rows['material_code']; ?></td> 
      <td><center><?php echo $rows['material_name']; ?></td> 
      <td><center><?php echo $rows['lot_number']; ?></td> 
      <td><center><?php echo $rows['end_qty_um']; ?> <?php echo $rows['um']; ?></td> 
  </tr>                                    

<?php 
    } 
  }
?> 
</tbody> 
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div id="custom_notifications" class="custom-notifications dsp_none">
          <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
          </ul>
          <div class="clearfix"></div>
          <div id="notif-group" class="tabbed_notifications"></div>
        </div>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        
        <!-- bootstrap progress js -->
        <script type="text/javascript" src="js/progressbar/bootstrap-progressbar.min.js"></script>
        <!-- icheck -->
        <script type="text/javascript" src="js/icheck/icheck.min.js"></script>
        
        <script type="text/javascript" src="js/custom.js"></script>
        <script type="text/javascript">
         // alert(localStorage.getItem("sisa"));
        </script>
<script type="text/javascript">
  function sendValue(value,value1,value2,value3,value4,value5,value6,value7,value8,value9,value10,value11,value12)
  {
      var parentId = <?php echo json_encode($_GET['id']); ?>;
      var parId = <?php echo json_encode($_GET['pir']); ?>;
      var lot = <?php echo json_encode($_GET['lot']); ?>;
      var qty_um = <?php echo json_encode($_GET['qty_um']); ?>;
      var um = <?php echo json_encode($_GET['um']); ?>;
      var qty_uom = <?php echo json_encode($_GET['qty_uom']); ?>;
      var uom = <?php echo json_encode($_GET['uom']); ?>;
      var out_um = <?php echo json_encode($_GET['out_um']); ?>;
      var out_uom = <?php echo json_encode($_GET['out_uom']); ?>;
      var qty_out_um = <?php echo json_encode($_GET['qty_out_um']); ?>;
      var qty_out_uom = <?php echo json_encode($_GET['qty_out_uom']); ?>;
      var size = <?php echo json_encode($_GET['size']); ?>;
      
      window.opener.updateValue(parentId, value);
      window.opener.updateValue1(parId, value1);
      window.opener.updateValue2(lot, value2);
      window.opener.updateValue3(qty_um, value3);
      window.opener.updateValue4(um, value4);
      window.opener.updateValue5(qty_uom, value5);
      window.opener.updateValue6(uom, value6);
      window.opener.updateValue7(out_um, value7);
      window.opener.updateValue8(out_uom, value8);
      window.opener.updateValue9(size, value9);
      //window.opener.updateValue10(qty_out_um, value10);
      if (localStorage.getItem("sisa") == 0) {
        if ((value10 - value12) <= value3 ) {
          window.opener.updateValue10(qty_out_um, value10 - value12 );
          window.opener.updateValue11(qty_out_uom, (value10 - value12)*value9);
        }/*else if(value10 > value3){
          window.opener.updateValue10(qty_out_um, value10);
          window.opener.updateValue11(qty_out_uom, value10*value9);
        }*/
        else{
          localStorage.setItem("sisa", value10 - value3);
          window.opener.updateValue10(qty_out_um, value3); 
          window.opener.updateValue11(qty_out_uom, value3*value9);
        }
      }else if(localStorage.getItem("sisa") != 0){
        //var ss = localStorage.setItem("sisa", localStorage.getItem('sisa'));
        /*if (localStorage.getItem("sisa") > value3 ) {
          localStorage.setItem("sisa", localStorage.getItem("sisa") - value3);
          window.opener.updateValue10(qty_out_um, localStorage.getItem("sisa"));
          window.opener.updateValue11(qty_out_uom, localStorage.getItem("sisa")*value9);
        }else*/ 
        if (localStorage.getItem("sisa") < value3) {
          window.opener.updateValue10(qty_out_um, localStorage.getItem("sisa"));
          window.opener.updateValue11(qty_out_uom, localStorage.getItem("sisa")*value9);
        }
        else{
          localStorage.setItem("sisa", localStorage.getItem("sisa") - value3);
          window.opener.updateValue10(qty_out_um, value3); 
          window.opener.updateValue11(qty_out_uom, value3*value9);
        }
      }
      
      window.close();
      
  }
</script>
<!-- Datatables-->
        <script type="text/javascript" src="js/datatables/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="js/datatables/dataTables.bootstrap.js"></script>
        <script type="text/javascript" src="js/datatables/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="js/datatables/buttons.bootstrap.min.js"></script>
        <script type="text/javascript" src="js/datatables/jszip.min.js"></script>
        <script type="text/javascript" src="js/datatables/pdfmake.min.js"></script>
        <script type="text/javascript" src="js/datatables/vfs_fonts.js"></script>
        <script type="text/javascript" src="js/datatables/buttons.html5.min.js"></script>
        <script type="text/javascript" src="js/datatables/buttons.print.min.js"></script>
        <script type="text/javascript" src="js/datatables/dataTables.fixedHeader.min.js"></script>
        <script type="text/javascript" src="js/datatables/dataTables.keyTable.min.js"></script>
        <script type="text/javascript" src="js/datatables/dataTables.responsive.min.js"></script>
        <script type="text/javascript" src="js/datatables/responsive.bootstrap.min.js"></script>
        <script type="text/javascript" src="js/datatables/dataTables.scroller.min.js"></script>
        <script type="text/javascript" src="js/pace/pace.min.js"></script>
        
        <script>
          var handleDataTableButtons = function() {
              "use strict";
              0 !== $("#datatable-buttons").length && $("#datatable-buttons").DataTable({
                dom: "Bfrtip",
                buttons: [{
                  extend: "copy",
                  className: "btn-sm"
                }, {
                  extend: "csv",
                  className: "btn-sm"
                }, {
                  extend: "excel",
                  className: "btn-sm"
                }, {
                  extend: "pdf",
                  className: "btn-sm"
                }, {
                  extend: "print",
                  className: "btn-sm"
                }],
                responsive: !0
              })
            },
            TableManageButtons = function() {
              "use strict";
              return {
                init: function() {
                  handleDataTableButtons()
                }
              }
            }();
        </script>
        <script type="text/javascript">
          $(document).ready(function() {
            $('#datatable').dataTable();
            $('#datatable-keytable').DataTable({
              keys: true
            });
            $('#datatable-responsive').DataTable();
            $('#datatable-scroller').DataTable({
              ajax: "js/datatables/json/scroller-demo.json",
              deferRender: true,
              scrollY: 380,
              scrollCollapse: true,
              scroller: true
            });
            var table = $('#datatable-fixed-header').DataTable({
              fixedHeader: true
            });
          });
          TableManageButtons.init();
        </script>
</body>

</html> 