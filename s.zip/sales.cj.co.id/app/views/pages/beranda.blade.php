@extends('products.table')
@section('content')
        <!-- top tiles -->
@if(Auth::check())

<div class="clearfix"></div>
<!-- /bar charts group -->
<div class="row">
    <div class="col-lg-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Inventory <small>Summary Inventory</small></h2>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">

            <div id="stats-container" style="height: 350px;"></div>
          </div>
        </div>
    </div>
</div>
<div class="col-md-6">
  <div class="x_panel">
    <div class="x_title">
      <h2>Coming Soon <small>Create Delivery Order</small></h2>
      <div class="clearfix"></div>
    </div>
    <div class="x_content">
    @foreach($create_do as $cdo)
      <?php 
      	$pomaster = DB::table('ss_pomaster')->leftJoin('ss_customers','ss_customers.customer_code','=','ss_pomaster.customer_code')->where('po_no','=',$cdo->po_no)->first();
      ?>
      <article class="media event">
        <a class="pull-left date" style="background:#d89619">
          <p class="month">{{date("M",strtotime($cdo->etd))}}</p>
          <p class="day">{{date("d",strtotime($cdo->etd))}}</p>
        </a>
        <div class="media-body">
          <a class="title" href="#">{{$cdo->po_no}} - {{$pomaster->customer_name}}</a>
          <p>{{$cdo->material_name}} - {{$cdo->qty_uom}} {{$cdo->uom}}</p>
        </div>
      </article>
     @endforeach
    </div>
  </div>
</div>
@endif
@endsection
@section('script')
<!-- moris js -->
<script src="js/moris/raphael-min.js"></script>
<script src="js/moris/morris.min.js"></script>
<script src="js/moris/spin.min.js"></script>
<script>
    $(function () {

        // Define the area for the spinner
        var spinTarget = document.getElementById('stats-container');

        // Create a function that will handle AJAX requests
        function requestData(days, chart) {
            // Activate the spinner
            var spinner = new Spinner().spin(spinTarget);

            $.ajax({
                type: "GET",
                dataType: 'json',
                url: "./api", // This is the URL to the API
                data: { days: days }
            })
                .done(function (data) {
                    // When the response to the AJAX request comes back render the chart with new data
                    chart.setData(data);
                })
                .fail(function () {
                    // If there is no communication between the server, show an error
                    alert("error occured");
                })
                .always(function () {
                    // No matter if request is successful or not, stop the spinner
                    spinner.stop();
                });
        }

        var chart = Morris.Bar({
            // ID of the element in which to draw the chart.
            element: 'stats-container',
            data: [0, 0], // Set initial data (ideally you would provide an array of default data)
            xkey: ['date'], // Set the key for X-axis
            ykeys: ['begin','inb','outb','end'], // Set the key for Y-axis
            labels: ['Begin','Inbound','Out','Ending'], // Set the label when bar is rolled over
            barRatio: 0.4,
            barColors: ['#26B99A', '#34495E', '#ACADAC', '#3498DB'],
            xLabelAngle: 60,
            hideHover: 'auto',
            resize: true
        });

        // Request initial data for the past 7 days:
        requestData(10, chart);

        $('ul.ranges a').click(function (e) {
            e.preventDefault();

            // Get the number of days from the data attribute
            var el = $(this);
            days = el.attr('data-range');

            // Request the data and render the chart using our handy function
            requestData(days, chart);

            // Make things pretty to show which button/tab the user clicked
            el.parent().addClass('active');
            el.parent().siblings().removeClass('active');
        })
    });
</script>
@stop