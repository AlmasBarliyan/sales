<?php

class IndexController extends \BaseController {

	 public function __construct()
    {
        $this->beforeFilter('auth');
    }
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		return View::make('pages.beranda')
			->with('create_do', DB::table('ss_podetail')->leftJoin('schedule_po','schedule_po.po_no','=','ss_podetail.po_no')->leftJoin('cd_material','cd_material.material_code','=','ss_podetail.material_code')->where('schedule_po.etd','>',date("Y-m-d"))->where('ss_podetail.qty_in_do_um','=','ss_podetail.qty_um')->orderBy('etd','ASC')->take(5)->get());
	}
	public function getAPI()
    {
        $days = Input::get('days');

        //$range = \Carbon\Carbon::now()->subDays($days);
        $mtktg = Auth::user()->emp_ktg;
        $ktgsub = substr(Auth::user()->emp_ktg, 0,3);
        if ($ktgsub == 'B2B') {
        	
        $stats = DB::select(DB::raw("select distinct im.material_code , im.`status`,mt.material_name date,(select sum(begin_qty_um) from ss_invmonthly where material_code = im.material_code)begin, (select sum(end_qty_um) from ss_invmonthly where material_code = im.material_code)end,(select sum(in_qty_um) from ss_invmonthly where material_code = im.material_code)inb,(select sum(out_qty_um) from ss_invmonthly where material_code = im.material_code)outb from ss_invmonthly im
left join cd_material mt on mt.material_code=im.material_code
where im.`status`= 'G' 
order by im.material_code"));/*DB::table('orders')

            ->where('created_at', '>=', $range)
            ->groupBy('date')
            ->orderBy('date', 'ASC')
            //->remember(1440) // Cache the data for 24 hours
            ->get([
                DB::raw('Date(created_at) as date'),
                DB::raw('COUNT(*) as value')
            ]);*/

        return $stats;
    	}
    }

}
