<?php
/**
* 
*/
class Customers extends Eloquent
{
	protected $table = 'ss_customers';
	protected $primaryKey = 'customer_code';
}