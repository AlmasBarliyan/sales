@extends('products.table')
@section('content')
		<div class="">
          <div class="page-title">
            <div class="title_left">
              <h3>Return</h3>
            </div>
            <div class="title_right">
              <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                <div class="input-group">
                  <input type="text" class="form-control" placeholder="Search for...">
                  <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Return Product </h2>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <form class="form-horizontal form-label-left input_mask" action="{{URL::to('/return-create')}}" method="post">
                    <div class="form-group">
                      <label class="control-label col-md-2 col-sm-2 col-xs-12">Warehouse</label>
                      <div class="col-md-10 col-sm-10 col-xs-12">
                        <select class="select2_single form-control" id="sStorage">
                          <option disabled selected value>-- Select Warehouse --</option>
                          @foreach($warehouse as $storage)
                            <option value="{{$storage->code}}">{{$storage->code_name}}</option>
                          @endforeach
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-md-2 col-sm-2 col-xs-12">Destination</label>
                      <div class="col-md-10 col-sm-10 col-xs-12">
                        <select class="select2_single form-control" id="sStorage">
                          <option></option>
                          @foreach($pabrik as $pb)
                            <option value="{{$pb->code}}">{{$pb->code_name}}</option>
                          @endforeach
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-md-2 col-sm-2 col-xs-12">Trucking</label>
                      <div class="col-md-10 col-sm-10 col-xs-12">
                        <input type="text" class="form-control" name="trucking">
                      </div>
                    </div>
                    <div>
                      <table class='table table-striped responsive-utilities jambo_table bulk_action' id="sProducts">
                          <thead>
                            <tr class='headings'>
                              <th class='column-title'>Material </th>
                              <th class='column-title'>Lot Number</th>
                              <th class='column-title'>Qty BAD</th>
                              <th class='column-title'>Qty Return</th>
                            </tr>
                          </thead>
                          <tbody>
                              <p ></p>
                          </tbody>
                      </table>
                    </div>                    
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                        <button type="submit" class="btn btn-success">Return</button>
                      </div>
                    </div>

                  </form>
                </div>
              </div>
			</div>
		</div>
@stop
@section('script')
<script>
function myFunction() {
    var x = document.getElementById("return_kg").value * document.getElementById("return_bag").value;
    document.getElementById("result_return").value = x;
    var y = document.getElementById("bad_kg").value * document.getElementById("bad_bag").value;
    document.getElementById("result_bad").value = y;
}
</script>
<script type="text/javascript">
            $(document).ready(function() {
                $('#sStorage').on('change', function(){
                $.post('{{ URL::to('site/show') }}', {type: 'storage', id: $('#sStorage').val()}, function(e){
                    $('#sProducts').html(e);
                });
                
                $('#sMaterial').html('');
                $('#sDesa').html('');
                
            });
            $('#sLotnumber').on('change', function(){
                $.post('{{ URL::to('site/return') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
                    $('#sMaterial').html(e);
                });
                $('#sDesa').html('');
            });
            $('#sKecamatan').on('change', function(){
                $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
                    $('#sDesa').html(e);
                });
            });
            });
        </script>
@stop