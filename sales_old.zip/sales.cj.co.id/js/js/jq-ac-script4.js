$(document).ready(function(){
    var p_ids = document.forms[0].elements["material_code[]"];
    if (p_ids.length > 1) {
    for (var i = 0, len = p_ids.length; i < len; i++) {
       
    $(p_ids[i]).autocomplete({
        source: '../data/item-data.php',
        minLength: 1,
        select: function(event, ui) {
            var $itemrow = $(this).closest('tr');
                    // Populate the input fields from the returned values
                    $itemrow.find('input[name^="material_code"]').val(ui.item.itemCode);
                    $itemrow.find('input[name^="material_name"]').val(ui.item.itemDesc);
                    $itemrow.find('#itemPrice').val(ui.item.itemPrice);
                    $itemrow.find('input[name^="size"]').val(ui.item.itemSize);
                    $itemrow.find('input[name^="um"]').val(ui.item.um);
                    $itemrow.find('input[name^="om"]').val(ui.item.uom);
                    // Give focus to the next input field to recieve input from user
                    $('#itemQty').focus();

            return false;
	    }
    // Format the list menu output of the autocomplete
    }).data( "autocomplete" )._renderItem = function( ul, item ) {
        return $( "<li></li>" )
            .data( "item.autocomplete", item )
            .append( "<a>" + item.itemCode + " - " + item.itemDesc + "</a>" )
            .appendTo( ul );
    };
    }
	}else{
		$('input[name^="material_code"]').autocomplete({
        source: '../data/item-data.php',
        minLength: 1,
        select: function(event, ui) {
            var $itemrow = $(this).closest('tr');
                    // Populate the input fields from the returned values
                    $itemrow.find('input[name^="material_code"]').val(ui.item.itemCode);
                    $itemrow.find('input[name^="material_name"]').val(ui.item.itemDesc);
                    $itemrow.find('#itemPrice').val(ui.item.itemPrice);
                    $itemrow.find('input[name^="size"]').val(ui.item.itemSize);
                    $itemrow.find('input[name^="um"]').val(ui.item.um);
                    $itemrow.find('input[name^="om"]').val(ui.item.uom);
                    // Give focus to the next input field to recieve input from user
                    $('#itemQty').focus();

            return false;
	    }
    // Format the list menu output of the autocomplete
    }).data( "autocomplete" )._renderItem = function( ul, item ) {
        return $( "<li></li>" )
            .data( "item.autocomplete", item )
            .append( "<a>" + item.itemCode + " - " + item.itemDesc + "</a>" )
            .appendTo( ul );
    };
	}
    // Get the table object to use for adding a row at the end of the table
    var $itemsTable = $('#itemsTable');

    // Create an Array to for the table row. ** Just to make things a bit easier to read.
    var rowTemp = [
        '<tr class="item-row">',
            '<td><a id="deleteRow"><i class="fa fa-trash"></i></a>',
            ' <input style="width:50px" name="matcod[]" value="" class="tInput" type="hidden"/><input style="width:50px" name="material_code[]"  class="tInput" id="itemCode" /></td>',
            '<td style="width:200px"><input style="width:140px" name="material_name[]" class="tInput" id="itemDesc"  readonly="readonly" /></td>',
            '<td colspan="4" style="width:150px">',
            ' <input style="width:60px;text-align:right" type="text" name="uom[]" id="a"/>',
            ' <input style="width:30px" id="uom" class="tInput" readonly="readonly" />',
            ' <input style="width:40px;text-align:right" name="qty[]"  class="tInput" id="itemQty"/>',
            ' <input  type="hidden" name="size[]"  id="itemSize" class="tInput" />',
            ' <input style="width:30px" class="tInput" id="um" readonly="readonly" />',
            '</td>',
            '<td><input style="width:80px;text-align:right" name="price_idr[]" class="tInput"/></td>',
            '<td><input type="date" style="width:118px" name="etd[]"></td>',
            '<td><input style="width:118px" type="date" name="eta_po[]"></td>',
            '<td><input style="width:118px" type="date" name="so_date[]"></td>',
        '</tr>'
    ].join('');

    // Add row to list and allow user to use autocomplete to find items.
    $("#addRow").bind('click',function(){

        var $row = $(rowTemp);

        // save reference to inputs within row
        var $itemCode 	        = $row.find('#itemCode');
        var $itemDesc 	        = $row.find('#itemDesc');
        var $itemPrice	        = $row.find('#itemPrice');
        var $itemQty	        = $row.find('#itemQty');
        var $a                  = $row.find('#a');
        var $itemSize           = $row.find('#itemSize');
        var $uom                = $row.find('#uom');
        var $um                 = $row.find('#um');
        var $nicklot            = $row.find('#nicklot');

        if ( $('#itemCode:last').val() !== '' ) {

            // apply autocomplete widget to newly created row
            $row.find('#itemCode').autocomplete({
                source: '../data/item-data.php',
                minLength: 1,
                select: function(event, ui) {
                    $itemCode.val(ui.item.itemCode);
                    $itemDesc.val(ui.item.itemDesc);
                    $itemPrice.val(ui.item.itemPrice);
                    $itemQty.val(ui.item.itemQty);
                    $itemSize.val(ui.item.itemSize);
                    $uom.val(ui.item.uom);
                    $um.val(ui.item.um);

                    // Give focus to the next input field to recieve input from user
                    $a.focus();

                    return false;
                }
            }).data( "autocomplete" )._renderItem = function( ul, item ) {
                return $( "<li></li>" )
                    .data( "item.autocomplete", item )
                    .append( "<a>" + item.itemCode + " - " + item.itemDesc + "</a>" )
                    .appendTo( ul );
            };
            // Add row after the first row in table
            $('.item-row:last', $itemsTable).after($row);
            $($itemCode).focus();

        } // End if last itemCode input is empty
        return false;
    });

    /*$('#itemCode').focus(function(){
        window.onbeforeunload = function(){ return "You haven't saved your data.  Are you sure you want to leave this page without saving first?"; };
    });*/

}); // End DOM

	// Remove row when clicked
	$("#deleteRow").live('click',function(){
		$(this).parents('.item-row').remove();
        // Hide delete Icon if we only have one row in the list.
        if ($(".item-row").length < 2) $("#deleteRow").hide();
	});
    