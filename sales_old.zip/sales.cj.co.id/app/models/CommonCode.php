<?php
/**
* 
*/
class CommonCode extends Eloquent
{
	protected $table = 'cd_code';
    protected $fillable = ['hcode','code','code_name'];
}