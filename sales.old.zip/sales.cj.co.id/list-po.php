<?php
  
  $con = mysql_connect('localhost', 'root', ''); 
 if (!$con) 
   { 
   die('Could not connect to server: ' . mysql_error()); 
   } 
   $db=mysql_select_db("cj_local_sales_do", $con); 

    if (!$db) 
   { 
   die('Could not connect to DB: ' . mysql_error()); 
   } 

$sql = "select pd.*, 
(select ship_to_party from cd_customers cm where cm.ship_to_party=pm.customer_code)ship_to_party,
(select name from cd_customers cm where cm.ship_to_party=pm.customer_code)sold_name,
(select name from cd_customers cm where cm.ship_to_party=pm.ship_to_party)ship_name 
from performance_detail pd
left join ss_pomaster pm on pm.po_no=pd.po_no";
//$sql="select * from cd_material ";
$result=mysql_query($sql);

 ?> 
<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Sales</title>
  <!-- Bootstrap core CSS -->
  
  <style type="text/css">
table.hovertable {
  font-family: verdana,arial,sans-serif;
  font-size:11px;
  color:#333333;
  border-width: 1px;
  border-color: #999999;
  border-collapse: collapse;
}
table.hovertable th {
  background-color:#c3dde0;
  border-width: 1px;
  padding: 8px;
  border-style: solid;
  border-color: #a9c6c9;
}
table.hovertable tr {
  background-color:#d4e3e5;
}
table.hovertable td {
  border-width: 1px;
  padding: 8px;
  border-style: solid;
  border-color: #a9c6c9;
}
</style>  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="js/datatables/jquery.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="js/datatables/responsive.bootstrap.min.css">
  <script type="text/javascript" src="js/jquery.min.js"> </script>
  
  <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
        <![endif]-->

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>


<body class="nav-md">

  <div class="container body">


    <div class="main_container">

      <!-- page content -->
      <div class="">
          <div class="page-title">
            <div class="title_left">
              <h3>

              </h3>
            </div>

            <div class="title_right">
              <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                <div class="input-group">
                  
                </div>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_content">
                  <table id="datatable-responsive" class="hovertable" cellspacing="0" width="100%">
                    <thead>
                      <tr>
                          <th>PO No</th>                       
                          <th>Material Code</th> 
                          <th>Qty (BAG/KG)</th>
                          <th>Customer</th> 
                          <th>Destination</th> 
                      </tr> 
                    </thead>
                    <tbody>
<?php 

   while($rows=mysql_fetch_array($result)){
?> 
  <tr onmouseover="this.style.backgroundColor='#ffff66';" onmouseout="this.style.backgroundColor='#d4e3e5';" onClick="sendValue('<?php echo $rows['ship_to_party']; ?>','<?php echo $rows['po_no']; ?>')">
      <td><center><a> <?php echo $rows['po_no']; ?></a></td> 
      <td><center><?php echo $rows['material_code']; ?></td> 
      <td><center><?php echo $rows['qty_um']; ?> / <?php echo $rows['qty_uom']; ?></td> 
      <td><center><?php echo $rows['sold_name']; ?></td> 
      <td><center><?php echo $rows['ship_name']; ?></td> 
  </tr>                                    

<?php 
    
  }
?> 
</tbody> 
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div id="custom_notifications" class="custom-notifications dsp_none">
          <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
          </ul>
          <div class="clearfix"></div>
          <div id="notif-group" class="tabbed_notifications"></div>
        </div>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        
        <!-- bootstrap progress js -->
        <script type="text/javascript" src="js/progressbar/bootstrap-progressbar.min.js"></script>
        <!-- icheck -->
        <script type="text/javascript" src="js/icheck/icheck.min.js"></script>
        
        <script type="text/javascript" src="js/custom.js"></script>
        <script type="text/javascript">
         // alert(localStorage.getItem("sisa"));
        </script>
<script type="text/javascript">
  function sendValue(value,value1)
  {

    var parentId = <?php echo json_encode($_GET['cus']); ?>;
    var pn = <?php echo json_encode($_GET['pn']); ?>;
    
    window.opener.updateNilai(parentId, value);
    window.opener.updateNilai1(pn, value1);
    window.close();      
  }
</script>
<!-- Datatables-->
        <script type="text/javascript" src="js/datatables/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="js/datatables/dataTables.bootstrap.js"></script>
        <script type="text/javascript" src="js/datatables/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="js/datatables/buttons.bootstrap.min.js"></script>
        <script type="text/javascript" src="js/datatables/jszip.min.js"></script>
        <script type="text/javascript" src="js/datatables/pdfmake.min.js"></script>
        <script type="text/javascript" src="js/datatables/vfs_fonts.js"></script>
        <script type="text/javascript" src="js/datatables/buttons.html5.min.js"></script>
        <script type="text/javascript" src="js/datatables/buttons.print.min.js"></script>
        <script type="text/javascript" src="js/datatables/dataTables.fixedHeader.min.js"></script>
        <script type="text/javascript" src="js/datatables/dataTables.keyTable.min.js"></script>
        <script type="text/javascript" src="js/datatables/dataTables.responsive.min.js"></script>
        <script type="text/javascript" src="js/datatables/responsive.bootstrap.min.js"></script>
        <script type="text/javascript" src="js/datatables/dataTables.scroller.min.js"></script>
        
        <script>
          var handleDataTableButtons = function() {
              "use strict";
              0 !== $("#datatable-buttons").length && $("#datatable-buttons").DataTable({
                dom: "Bfrtip",
                buttons: [{
                  extend: "copy",
                  className: "btn-sm"
                }, {
                  extend: "csv",
                  className: "btn-sm"
                }, {
                  extend: "excel",
                  className: "btn-sm"
                }, {
                  extend: "pdf",
                  className: "btn-sm"
                }, {
                  extend: "print",
                  className: "btn-sm"
                }],
                responsive: !0
              })
            },
            TableManageButtons = function() {
              "use strict";
              return {
                init: function() {
                  handleDataTableButtons()
                }
              }
            }();
        </script>
        <script type="text/javascript">
          $(document).ready(function() {
            $('#datatable').dataTable();
            $('#datatable-keytable').DataTable({
              keys: true
            });
            $('#datatable-responsive').DataTable();
            $('#datatable-scroller').DataTable({
              ajax: "js/datatables/json/scroller-demo.json",
              deferRender: true,
              scrollY: 380,
              scrollCollapse: true,
              scroller: true
            });
            var table = $('#datatable-fixed-header').DataTable({
              fixedHeader: true
            });
          });
          TableManageButtons.init();
        </script>
</body>

</html> 