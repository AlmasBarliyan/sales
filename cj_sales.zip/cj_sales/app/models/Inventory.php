<?php
/**
* 
*/
class Inventory extends Eloquent
{
	protected $table = 'ss_invdaily';
}