<?php
/**
* 
*/
class Products extends Eloquent
{
	protected $table = "cd_material";
	protected $primaryKey = 'material_code';
}