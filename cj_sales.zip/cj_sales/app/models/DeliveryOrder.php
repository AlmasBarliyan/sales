<?php
/**
* 
*/
class DeliveryOrder extends Eloquent
{
	protected $table = 'ss_outmaster';
	protected $fillable = array(
		'company',
		'plant',
		'no_transaksi',
		'po_no',
		'customer_code',
		'date_out',
		'status',
		'source',
		'destination',
		'trucking',
		'no_srtjln',
		'remarks',
		'user_create',
		'user_update'
		);
	public function DoDetail(){
		return $this->belongsToMany('Products','ss_outdtl','material_code','no_transaksi')->withPivot('material_code','lot_number','qty_out_um','qty_out_uom','status');
	}
	public function InvDaily(){
		return $this->belongsToMany('Products','ss_invdaily','material_code','id')->withPivot('company','plant','material_code','lot_number','qty_um','qty_uom','status2','status' ,'storage','date_ym','created_at','updated_at');
	}
}