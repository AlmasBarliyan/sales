<?php
/**
* 
*/
class TransaksiDetail extends Eloquent
{
	
	protected $table = 'tx_itemindetail';
	protected $fillable = array(
		'id_transaksi',  
		'material_code', 
		'lot_number',    
		'qty_um',        
		'qty_uom',       
		'status'
		);
}