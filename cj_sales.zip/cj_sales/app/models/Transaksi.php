<?php
/**
* 
*/
class Transaksi extends Eloquent
{
	
	protected $table = 'tx_itemin';
	protected $primaryKey = 'id_transaksi';
	protected $fillable = array(
		'company',
		'plant',
		'id_transaksi',
		'storage',
		'date_in',
		'status',
		'remarks',
		'user_create',
		'user_update'
		);
	public function InDetail(){
		return $this->belongsToMany('Products','tx_itemindetail','material_code','id_transaksi')->withPivot('material_code','lot_number','qty_um','qty_uom','status');
	}
	public function InvDaily(){
		return $this->belongsToMany('Products','ss_invdaily','material_code','id')->withPivot('company','plant','material_code','lot_number','qty_um','qty_uom','status2','status' ,'storage','date_ym','created_at','updated_at');
	}
}