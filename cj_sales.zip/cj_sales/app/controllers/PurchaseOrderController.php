<?php

class PurchaseOrderController extends \BaseController {
	public function __construct()
    {
        $this->beforeFilter('auth');

    }
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function getIndex()
	{
		$currency = DB::select(DB::raw("SELECT   e.currency_rate, e.exchange_date FROM exchange_rate_bi e where e.exchange_date = CURDATE()"));
		$purchase_order = DB::select(DB::raw("SELECT * FROM ss_pomaster p LEFT JOIN ss_customers c1 ON p.customer_code = c1.customer_code LEFT JOIN ss_customerdtl c2 ON p.ship_to_party = c2.ship_to_party LEFT JOIN cd_code c3 ON p.source = c3.code"));
		foreach ($currency as $cur) {
			
			Session::put('cur_cod',$cur->currency_rate);
			Session::put('cur_date',$cur->exchange_date);
		}
		
		return View::make('po.po')
			->with('customers',Customers::where('customer_ktg','LIKE','%'.substr(Auth::user()->emp_ktg,0,3).'%')->get())
			->with('source',CommonCode::where('code','!=','*')->where('hcode','LIKE','%'.'PB'.'%')->get())
			->with('currency', CommonCode::where('hcode','=','CUR')->where('code','!=','*')->get())
			->with('purchase_order',PurchaseOrder::orderBy('po_date','DESC')->get());
	}

	public function postCreate(){
		
		
		$insert = array();
		foreach (Input::get('material_code') as $key => $material_code) {
			$insert[$key]['material_code'] = $material_code;
		}
		foreach (Input::get('price_idr') as $key => $price_idr) {
			$insert[$key]['price_idr'] = $price_idr;
		}
		foreach (Input::get('price_usd') as $key => $price_usd) {
			$insert[$key]['price_usd'] = $price_usd;
		}
		foreach (Input::get('qty') as $key => $qty) {
			$insert[$key]['qty'] = $qty;
		}
		foreach (Input::get('uom') as $key => $uom) {
			$insert[$key]['uom'] = $uom;
		}
		foreach (Input::get('exclude_idr') as $key => $exclude_idr) {
			$insert[$key]['exclude_idr'] = $exclude_idr;
		}
		foreach (Input::get('exclude_usd') as $key => $exclude_usd) {
			$insert[$key]['exclude_usd'] = $exclude_usd;
		}
		foreach (Input::get('include') as $key => $include) {
			$insert[$key]['include'] = $include;
		}

		$company = Auth::user()->company;
		$plant = Auth::user()->plant;
		$customer_code = Input::get('customer');
		$po_no = Input::get('po_no');
		$po_date = date("Y-m-d",strtotime(Input::get('po_date'))) ;
		$eta_po = date("Y-m-d", strtotime(Input::get('eta_po'))) ;
		$etd = date("Y-m-d", strtotime(Input::get('etd'))) ;
		$ship_to_party = Input::get('ship_to_party');
		$source = Input::get('source');
		$currency_rate = Input::get('currency_rate');
		$currency_code = Input::get('currency_code');
		$user_create = Auth::user()->employee_code;
		$user_update = Auth::user()->employee_code;
		$po = PurchaseOrder::create([
        'company'       => $company,
        'plant'         => $plant,
        'po_no'			=> $po_no,
        'po_date'       => $po_date,
        'eta_po'        => $eta_po,
        'etd'			=> $etd,
        'customer_code' => $customer_code,
        'ship_to_party' => $ship_to_party,
        'source'		=> $source,
        'currency_code' => Input::get('currency_code'),
        'currency_rate' => Input::get('currency_rate'),
        'user_create'   => $user_create,
        'user_update'   => $user_update
        ]);
		foreach ($insert as $row ) {
			$po->PoDetail()->attach($po_no,[
				'po_no'			=> $po_no,
				'material_code' => $row['material_code'],
				'qty_um'			=> $row['qty'],
				'qty_uom'			=> $row['uom'],
				'u_price_idr'	=> $row['price_idr'],
				'u_price_usd'	=> $row['price_usd'],
				'exclude_idr'	=> $row['exclude_idr'],
				'exclude_usd'	=> $row['exclude_usd'],
				'include'		=> $row['include'],
				]);
		}

		return Redirect::to('/purchase-order');
	}
	public function postData() {
        switch(Input::get('type')):
            case 'dl':
            	$return = "<option></option>";
                foreach(DB::table('ss_customerdtl')->where('sold_to_party','=',Input::get('id'))->get() as $row)
                	$return .= "<option value='$row->ship_to_party'>$row->ship_to_party - $row->ship_name</option>";
                return $return;
                
            break;
        endswitch;    
    }
    public function postData1() {
        switch(Input::get('type')):
            case 'currency_rate':
            	//$return = "<option></option>";
                foreach(DB::table('exchange_rate_bi')->where('currency_code','=',Input::get('id'))->get() as $row)
                	Session::put('cur_cod',$row->currency_rate);
                	$return = "<input type='text' value='$row->currency_rate' id='currency_rate' name='currency_rate'>";
                return $return;
                
            break;
        endswitch;    
    }
    public function view()
    {
    	$po_no = Input::get('pono');

    	Session::put('pnooo',$po_no);
    	$currency = DB::select(DB::raw("SELECT  c.code, e.currency_rate, c.code_name, max(e.exchange_date) FROM exchange_rate_bi e  LEFT JOIN cd_code c ON c.code = e.currency_code"));
    	return View::make('po.view')
    		->with('customers',Customers::where('customer_ktg','=',Auth::user()->emp_ktg)->get())
    		->with('customersdtl',DB::table('ss_customerdtl')->get())
			->with('source',CommonCode::where('code','!=','*')->where('hcode','LIKE','%'.'PB'.'%')->get())
			//->with('currency',CommonCode::where('code','!=','*')->where('hcode','LIKE','%'.'CUR'.'%')->get());
			->with('currency', CommonCode::where('hcode','=','CUR')->where('code','!=','*')->get())
    		->with('view_po', PurchaseOrder::where('po_no','=',$po_no)->get());
    }
    public function edit(){
    	$insert = array();
		foreach (Input::get('material_code') as $key => $material_code) {
			$insert[$key]['material_code'] = $material_code;
		}
		foreach (Input::get('matcod') as $key => $matcod) {
			$insert[$key]['matcod'] = $matcod;
		}
		foreach (Input::get('price_idr') as $key => $price_idr) {
			$insert[$key]['price_idr'] = $price_idr;
		}
		foreach (Input::get('price_usd') as $key => $price_usd) {
			$insert[$key]['price_usd'] = $price_usd;
		}
		foreach (Input::get('qty') as $key => $qty) {
			$insert[$key]['qty'] = $qty;
		}
		foreach (Input::get('uom') as $key => $uom) {
			$insert[$key]['uom'] = $uom;
		}
		foreach (Input::get('exclude_idr') as $key => $exclude_idr) {
			$insert[$key]['exclude_idr'] = $exclude_idr;
		}
		foreach (Input::get('exclude_usd') as $key => $exclude_usd) {
			$insert[$key]['exclude_usd'] = $exclude_usd;
		}
		foreach (Input::get('include') as $key => $include) {
			$insert[$key]['include'] = $include;
		}
		

		$company = Auth::user()->company;
		$plant = Auth::user()->plant;
		$customer_code = Input::get('customer');
		$pono = Input::get('pono');
		$po_no = Input::get('po_no');
		$po_date = date("Y-m-d",strtotime(Input::get('po_date'))) ;
		$eta_po = date("Y-m-d", strtotime(Input::get('eta_po'))) ;
		$etd = date("Y-m-d", strtotime(Input::get('etd'))) ;
		$ship_to_party = Input::get('ship_to_party');
		$source = Input::get('source');
		$currency_rate = Input::get('currency_rate');
		$currency_code = Input::get('currency_code');
		$user_create = Auth::user()->employee_code;
		$user_update = Auth::user()->employee_code;
		$ckdb = DB::table('ss_podetail')->where('po_no','=',$pono)->get();
		$po = PurchaseOrder::find(Input::get('pono'));
        $po->company        = $company;
        $po->plant        	= $plant;
        $po->po_no        	= $po_no;
        $po->po_date       	= $po_date;
        $po->eta_po        	= $eta_po;
        $po->etd        	= $etd;
        $po->customer_code  = $customer_code;
        $po->ship_to_party  = $ship_to_party;
        $po->source        	= $source;
        $po->currency_rate	= $currency_rate;
        $po->currency_code	= $currency_code;
        $po->user_update    = $user_update;
        foreach ($ckdb as $ck) {
        	if ($ck->qty_in_do_um == 0) {
        		if ($po->save()) {
					foreach ($insert as $row ) {
						if ($row['matcod'] == '') {
		                    DB::table('ss_podetail')->insert([
		                    'po_no'			=> $po_no,
							'material_code' => $row['material_code'],
							'qty_um'		=> $row['qty'],
							'qty_uom'		=> $row['uom'],
							'u_price_idr'	=> $row['price_idr'],
							'u_price_usd'	=> $row['price_usd'],
							'exclude_idr'	=> $row['exclude_idr'],
							'exclude_usd'	=> $row['exclude_usd'],
							'include'		=> $row['include'],
		                    ]);
		                }
		                else
						DB::table('ss_podetail')->where('po_no','=',$pono)->where('material_code','=',$row['matcod'])->update([
							'po_no'			=> $po_no,
							'material_code' => $row['material_code'],
							'qty_um'		=> $row['qty'],
							'qty_uom'		=> $row['uom'],
							'u_price_idr'	=> $row['price_idr'],
							'u_price_usd'	=> round($row['price_idr'] / $currency_rate,3),
							'exclude_idr'	=> number_format($row['price_idr'] * $row['uom'] , 2),
							'exclude_usd'	=> number_format(round((($row['price_idr'] / $currency_rate) * $row['uom']) , 3),2),
							'include'		=> number_format(($row['price_idr'] * $row['uom']) * 1.1, 2),
							]);
					}
					return Redirect::to('/purchase-order');	
				}
			}else{
				if ($po->save()) {
					foreach ($insert as $row ) {
						if ($row['matcod'] == '') {
		                    DB::table('ss_podetail')->insert([
		                    'po_no'			=> $po_no,
							'material_code' => $row['material_code'],
							'qty_um'		=> $row['qty'],
							'qty_uom'		=> $row['uom'],
							'u_price_idr'	=> $row['price_idr'],
							'u_price_usd'	=> $row['price_usd'],
							'exclude_idr'	=> $row['exclude_idr'],
							'exclude_usd'	=> $row['exclude_usd'],
							'include'		=> $row['include'],
		                    ]);
		                }
		                else
						DB::table('ss_podetail')->where('po_no','=',$pono)->where('material_code','=',$row['matcod'])->update([
							'po_no'			=> $po_no,
							'material_code' => $row['material_code'],
							'qty_um'		=> $row['qty'],
							'qty_uom'		=> $row['uom'],
							'u_price_idr'	=> $row['price_idr'],
							'u_price_usd'	=> round($row['price_idr'] / $currency_rate,3),
							'exclude_idr'	=> number_format($row['price_idr'] * $row['uom'] , 2),
							'exclude_usd'	=> number_format(round(round($row['price_idr'] / $currency_rate, 3) * $row['uom'],2),2),
							'include'		=> number_format(($row['price_idr'] * $row['uom']) * 1.1, 2)
							
							]);
					}
				return Redirect::to('/purchase-order');	
			}
		}		
    }
	
}
    public function deleteItem($idtx,$mtcd){
       	DB::table('ss_podetail')->where('po_no','=',$idtx)->where('material_code','=',$mtcd)->delete();
        
        return Redirect::back();
    }
    public function destroy()
	{
		$po_no = Input::get('pono');
		$pomst = PurchaseOrder::find($po_no);
		DB::table('ss_podetail')->where('po_no','=',$po_no)->delete();
        $pomst->delete();
        
        return Redirect::back();
	}
	public function getReport()
	{
		$date_start = date("Y-m-d",strtotime(Input::get('date_start')));
		$date_finish = date("Y-m-d",strtotime(Input::get('date_finish')));
		$kategori = Input::get('kategori');
		if ($date_finish == '1970-01-01' and $date_start == '1970-01-01') {
		Session::put('date_start',date("Y-m-d"));
		Session::put('date_finish',date("Y-m-d"));
		return View::make('reports.po')
			->with('list_po',DB::table('ss_podetail as pd')->join('ss_pomaster as pm','pm.po_no','=','pd.po_no')->join('cd_material as mt','mt.material_code','=','pd.material_code')->join('cd_code as cd','cd.code','=','pm.source')->join('ss_customers as ct','ct.customer_code','=','pm.customer_code')->join('ss_customerdtl as csd','csd.ship_to_party','=','pm.ship_to_party')->select('cd.code_name','mt.material_name','pm.eta_po','pm.po_date','pd.po_no','ct.customer_name','csd.ship_name','pd.qty_uom','pd.u_price_idr','pd.exclude_idr','pd.include','pd.u_price_usd','pd.exclude_usd','pm.etd','pd.so_no','pd.so_date','pd.invoice','pd.bill_date')->whereBetween('po_date',array(date("Y-m-d"),date("Y-m-d")))->get())
			->with('date_start',date("d-m-Y"))
			->with('date_finish',date("d-m-Y"));
		}else{
			Session::put('date_start',$date_start);
			Session::put('date_finish',$date_finish);
			return View::make('reports.po')
				->with('list_po',DB::table('ss_podetail as pd')->join('ss_pomaster as pm','pm.po_no','=','pd.po_no')->join('cd_material as mt','mt.material_code','=','pd.material_code')->join('cd_code as cd','cd.code','=','pm.source')->join('ss_customers as ct','ct.customer_code','=','pm.customer_code')->join('ss_customerdtl as csd','csd.ship_to_party','=','pm.ship_to_party')->select('cd.code_name','mt.material_name','pm.eta_po','pm.po_date','pd.po_no','ct.customer_name','csd.ship_name','pd.qty_uom','pd.u_price_idr','pd.exclude_idr','pd.include','pd.u_price_usd','pd.exclude_usd','pm.etd','pd.so_no','pd.so_date','pd.invoice','pd.bill_date')->whereBetween('po_date',array($date_start,$date_finish))->get())
				->with('date_start',date("d-m-Y",strtotime($date_start)))
				->with('date_finish',date("d-m-Y",strtotime($date_finish)));
		}
	}
	public function exportexcel()
	{
		
		// Library phpExcel
		require_once (app_path()."/plugins/phpExcel/PHPExcel.php");
		require_once (app_path()."/plugins/phpExcel/PHPExcel/Writer/Excel2007.php");

		// Buat object baru
		$object = new PHPExcel();

		// Pilih sheet active
		$sheet = $object->getActiveSheet();
		$styleContent = array(
		    'borders' => array(
		        'allborders' => array(
		            'style' => PHPExcel_Style_Border::BORDER_THIN,
		            'color' => array('argb' => '#333'),
		        ),
		    ),
		);
		$styleTitle = array(
		    'borders' => array(
		        'allborders' => array(
		            'style' => PHPExcel_Style_Border::BORDER_THIN,
		            'color' => array('argb' => '#333'),
		        ),
		    ),
		    'font' => array(
		        'bold' => true,
		    )
		);
		// Pemformatan sederhana (lebih lengkap : cek dokumentasi phpExcel)
		$sheet->getDefaultRowDimension()->setRowHeight(15);
		$sheet->freezePane('A8');
		$sheet->setAutoFilter('A7:Q7');
		$objDrawing = new PHPExcel_Worksheet_Drawing();
		$objDrawing->setName('Logo');
		$objDrawing->setDescription('Logo');
		$objDrawing->setPath('./images/logo_CJ.png');
		$objDrawing->setCoordinates('A2');
		$objDrawing->setHeight(50);
		$objDrawing->setWidth(58);
		$sheet->getDefaultStyle()->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
		

		// Ubah ukuran lebar cell C agar menyesuaikan content
		$sheet->getColumnDimension('A')->setWidth(13);
		$sheet->getColumnDimension('B')->setWidth(25);
		$sheet->getColumnDimension('C')->setWidth(10);
		$sheet->getColumnDimension('D')->setWidth(10);
		$sheet->getColumnDimension('E')->setWidth(12);
		$sheet->getColumnDimension('F')->setWidth(12);
		$sheet->getColumnDimension('G')->setWidth(12);
		$sheet->getColumnDimension('H')->setWidth(12);
		$sheet->getColumnDimension('I')->setWidth(30);
		$sheet->getColumnDimension('J')->setWidth(30);
		$sheet->getColumnDimension('K')->setWidth(30);
		$sheet->getColumnDimension('L')->setWidth(12);
		$sheet->getColumnDimension('M')->setWidth(12);
		$sheet->getColumnDimension('N')->setWidth(12);
		$sheet->getColumnDimension('O')->setWidth(21);
		$sheet->getColumnDimension('P')->setWidth(21);
		$sheet->getColumnDimension('Q')->setWidth(21);

		// Tulis judul di B2
		$sheet->setCellValue('B3', 'SALES PERFORMANCE');
		$sheet->setCellValue('B4', 'PT. CHEIL JEDANG INDONESIA');
		$sheet->setCellValue('B5', Session::get('date_start'). " - ".  Session::get('date_finish'));

		// Tulis header tabel di B4 sampai H4
		$sheet->setCellValue('A7', 'Source')
			  ->setCellValue('B7', 'Product')
			  ->setCellValue('C7', 'Invoice')
			  ->setCellValue('D7', 'SO No.')
			  ->setCellValue('E7', 'SO Date')
			  ->setCellValue('F7', 'Bill Date')
			  ->setCellValue('G7', 'ETA')
			  ->setCellValue('H7', 'ETD')
			  ->setCellValue('I7', 'PO No.')
			  ->setCellValue('J7', 'Company')
			  ->setCellValue('K7', 'Destination')
			  ->setCellValue('L7', 'Qty')
			  ->setCellValue('M7', 'U/Price IDR')
			  ->setCellValue('N7', 'U/Price USD')
			  ->setCellValue('O7', 'Net Amount IDR')
			  ->setCellValue('P7', 'Net Amount USD')
			  ->setCellValue('Q7', 'Gross Amount')
			  ;
		$sheet->getStyle('A7:Q7')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('27eaea');
		$sheet->getStyle('A7:Q7')->applyFromArray($styleTitle);

		
		$data =DB::table('ss_podetail as pd')->join('ss_pomaster as pm','pm.po_no','=','pd.po_no')->join('cd_material as mt','mt.material_code','=','pd.material_code')->join('cd_code as cd','cd.code','=','pm.source')->join('ss_customers as ct','ct.customer_code','=','pm.customer_code')->join('ss_customerdtl as csd','csd.ship_to_party','=','pm.ship_to_party')->select('cd.code_name','mt.material_name','pm.eta_po','pm.po_date','pd.po_no','ct.customer_name','csd.ship_name','pd.qty_uom','pd.u_price_idr','pd.exclude_idr','pd.include','pd.u_price_usd','pd.exclude_usd','pm.etd','pd.so_no','pd.so_date','pd.invoice','pd.bill_date')->whereBetween('po_date',array(Session::get('date_start'),Session::get('date_finish')))->get();
		// Tulis data, mulai dari BARIS KE-5 (karena 1-4 diisi judul)
		$i = 8;
		$number = 1;
		foreach ($data as $row) {
			$sheet->setCellValue('A'.$i, $row->code_name);
			$sheet->setCellValue('B'.$i, $row->material_name);
			$sheet->setCellValue('C'.$i, $row->invoice);
			$sheet->setCellValue('D'.$i, $row->so_no);
			$sheet->setCellValue('E'.$i, $row->so_date);
			$sheet->setCellValue('F'.$i, $row->bill_date);
			$sheet->setCellValue('G'.$i, $row->eta_po);
			$sheet->setCellValue('H'.$i, $row->etd);
			$sheet->setCellValue('I'.$i, $row->po_no);
			$sheet->setCellValue('J'.$i, $row->customer_name);
			$sheet->setCellValue('K'.$i, $row->ship_name);
			$sheet->setCellValue('L'.$i, $row->qty_uom);
			$sheet->setCellValue('M'.$i, $row->u_price_idr);
			$sheet->setCellValue('N'.$i, $row->u_price_usd);
			$sheet->setCellValue('O'.$i, $row->exclude_idr);
			$sheet->setCellValue('P'.$i, $row->exclude_usd);
			$sheet->setCellValue('Q'.$i, $row->include);
			$sheet->getStyle('A'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('B'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('C'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('D'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('E'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('F'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('G'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('H'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('I'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('J'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('K'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('L'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('M'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('N'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('O'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('P'.$i)->applyFromArray($styleContent);
			$sheet->getStyle('Q'.$i)->applyFromArray($styleContent);
			// iterasi i agar ganti baris
			$i++;
		}

		// Beri nama sheet
		$sheet->setTitle(Session::get('date_start'));
		$styleArray = array(
		      'borders' => array(
		          'allborders' => array(
		              'style' => PHPExcel_Style_Border::BORDER_THIN
		          )
		      )
		  );
		$sheet->getDefaultStyle()->applyFromArray($styleArray);
		// Pilih sheet yang akan aktif
		$object->setActiveSheetIndex(0);
		
		// Output
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="PERFORMANCE.xlsx"'); // beri nama file
		header('Cache-Control: max-age=0');
		$objWriter = PHPExcel_IOFactory::createWriter($object, 'Excel2007');
		$objWriter->save('php://output');
	}
	public function exportpdf() {
		require_once(app_path().'/plugins/fpdf/fpdf.php');

		$pdf = new FPDF();
		$pdf->AddPage();

		$pdf->Ln(13);
		$pdf->SetFont('Arial','B',16);
		$pdf->Cell(0,10,'DAFTAR KATEGORI BARANG',0,0,'C');
		$pdf->Ln(13);

		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(50,7,"ID",1,0,"C"); 
		$pdf->Cell(140,7,"Kategori",1,0,"C");
		$pdf->Ln();

		$pdf->SetFont('Arial','',12);
		$data = DB::select( DB::raw("SELECT * FROM ss_pomaster"));
		foreach ($data as $row) {
			$pdf->Cell(50,7,$row->po_no,1,0,"C"); 
			$pdf->Cell(140,7,$row->etd,1,0,"L");
			$pdf->Ln();
		}

		$pdf->Output("Kategori.pdf", 'D');
	}
}
