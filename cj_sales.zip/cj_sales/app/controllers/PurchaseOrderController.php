<?php

class PurchaseOrderController extends \BaseController {
	public function __construct()
    {
        $this->beforeFilter('auth');

    }
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function getIndex()
	{
		$currency = DB::select(DB::raw("SELECT   e.currency_rate, e.exchange_date FROM exchange_rate_bi e where e.exchange_date = CURDATE()"));
		$purchase_order = DB::select(DB::raw("SELECT * FROM ss_pomaster p LEFT JOIN ss_customers c1 ON p.customer_code = c1.customer_code LEFT JOIN ss_customerdtl c2 ON p.ship_to_party = c2.ship_to_party LEFT JOIN cd_code c3 ON p.source = c3.code"));
		foreach ($currency as $cur) {
			
			Session::put('cur_cod',$cur->currency_rate);
			Session::put('cur_date',$cur->exchange_date);
		}
		
		return View::make('po.po')
			->with('customers',Customers::where('customer_ktg','=',Auth::user()->emp_ktg)->get())
			->with('source',CommonCode::where('code','!=','*')->where('hcode','LIKE','%'.'PB'.'%')->get())
			->with('currency', CommonCode::where('hcode','=','CUR')->where('code','!=','*')->get())
			->with('purchase_order',PurchaseOrder::orderBy('po_date','DESC')->get());
	}

	public function postCreate(){
		
		
		$insert = array();
		foreach (Input::get('material_code') as $key => $material_code) {
			$insert[$key]['material_code'] = $material_code;
		}
		foreach (Input::get('price_idr') as $key => $price_idr) {
			$insert[$key]['price_idr'] = $price_idr;
		}
		foreach (Input::get('price_usd') as $key => $price_usd) {
			$insert[$key]['price_usd'] = $price_usd;
		}
		foreach (Input::get('qty') as $key => $qty) {
			$insert[$key]['qty'] = $qty;
		}
		foreach (Input::get('uom') as $key => $uom) {
			$insert[$key]['uom'] = $uom;
		}
		foreach (Input::get('exclude_idr') as $key => $exclude_idr) {
			$insert[$key]['exclude_idr'] = $exclude_idr;
		}
		foreach (Input::get('exclude_usd') as $key => $exclude_usd) {
			$insert[$key]['exclude_usd'] = $exclude_usd;
		}
		foreach (Input::get('include') as $key => $include) {
			$insert[$key]['include'] = $include;
		}

		$company = Auth::user()->company;
		$plant = Auth::user()->plant;
		$customer_code = Input::get('customer');
		$po_no = Input::get('po_no');
		$po_date = date("Y-m-d",strtotime(Input::get('po_date'))) ;
		$eta_po = date("Y-m-d", strtotime(Input::get('eta_po'))) ;
		$etd = date("Y-m-d", strtotime(Input::get('etd'))) ;
		$ship_to_party = Input::get('ship_to_party');
		$source = Input::get('source');
		$currency_rate = Input::get('currency_rate');
		$currency_code = Input::get('currency_code');
		$user_create = Auth::user()->employee_code;
		$user_update = Auth::user()->employee_code;
		$po = PurchaseOrder::create([
        'company'       => $company,
        'plant'         => $plant,
        'po_no'			=> $po_no,
        'po_date'       => $po_date,
        'eta_po'        => $eta_po,
        'etd'			=> $etd,
        'customer_code' => $customer_code,
        'ship_to_party' => $ship_to_party,
        'source'		=> $source,
        'currency_code' => Input::get('currency_code'),
        'currency_rate' => Input::get('currency_rate'),
        'user_create'   => $user_create,
        'user_update'   => $user_update
        ]);
		foreach ($insert as $row ) {
			$po->PoDetail()->attach($po_no,[
				'po_no'			=> $po_no,
				'material_code' => $row['material_code'],
				'qty_um'			=> $row['qty'],
				'qty_uom'			=> $row['uom'],
				'u_price_idr'	=> $row['price_idr'],
				'u_price_usd'	=> $row['price_usd'],
				'exclude_idr'	=> $row['exclude_idr'],
				'exclude_usd'	=> $row['exclude_usd'],
				'include'		=> $row['include'],
				]);
		}

		return Redirect::to('/purchase-order');
	}
	public function postData() {
        switch(Input::get('type')):
            case 'dl':
            	$return = "<option></option>";
                foreach(DB::table('ss_customerdtl')->where('sold_to_party','=',Input::get('id'))->get() as $row)
                	$return .= "<option value='$row->ship_to_party'>$row->ship_to_party - $row->ship_name</option>";
                return $return;
                
            break;
        endswitch;    
    }
    public function postData1() {
        switch(Input::get('type')):
            case 'currency_rate':
            	//$return = "<option></option>";
                foreach(DB::table('exchange_rate_bi')->where('currency_code','=',Input::get('id'))->get() as $row)
                	Session::put('cur_cod',$row->currency_rate);
                	$return = "<input type='text' value='$row->currency_rate' id='currency_rate' name='currency_rate'>";
                return $return;
                
            break;
        endswitch;    
    }
    public function view()
    {
    	$po_no = Input::get('pono');

    	Session::put('pnooo',$po_no);
    	$currency = DB::select(DB::raw("SELECT  c.code, e.currency_rate, c.code_name, max(e.exchange_date) FROM exchange_rate_bi e  LEFT JOIN cd_code c ON c.code = e.currency_code"));
    	return View::make('po.view')
    		->with('customers',Customers::where('customer_ktg','=',Auth::user()->emp_ktg)->get())
    		->with('customersdtl',DB::table('ss_customerdtl')->get())
			->with('source',CommonCode::where('code','!=','*')->where('hcode','LIKE','%'.'PB'.'%')->get())
			//->with('currency',CommonCode::where('code','!=','*')->where('hcode','LIKE','%'.'CUR'.'%')->get());
			->with('currency', CommonCode::where('hcode','=','CUR')->where('code','!=','*')->get())
    		->with('view_po', PurchaseOrder::where('po_no','=',$po_no)->get());
    }
    public function edit(){
    	$insert = array();
		foreach (Input::get('material_code') as $key => $material_code) {
			$insert[$key]['material_code'] = $material_code;
		}
		foreach (Input::get('matcod') as $key => $matcod) {
			$insert[$key]['matcod'] = $matcod;
		}
		foreach (Input::get('price_idr') as $key => $price_idr) {
			$insert[$key]['price_idr'] = $price_idr;
		}
		foreach (Input::get('price_usd') as $key => $price_usd) {
			$insert[$key]['price_usd'] = $price_usd;
		}
		foreach (Input::get('qty') as $key => $qty) {
			$insert[$key]['qty'] = $qty;
		}
		foreach (Input::get('uom') as $key => $uom) {
			$insert[$key]['uom'] = $uom;
		}
		foreach (Input::get('exclude_idr') as $key => $exclude_idr) {
			$insert[$key]['exclude_idr'] = $exclude_idr;
		}
		foreach (Input::get('exclude_usd') as $key => $exclude_usd) {
			$insert[$key]['exclude_usd'] = $exclude_usd;
		}
		foreach (Input::get('include') as $key => $include) {
			$insert[$key]['include'] = $include;
		}
		foreach (Input::get('so_no') as $key => $so_no) {
			$insert[$key]['so_no'] = $so_no;
		}
		foreach (Input::get('so_date') as $key => $so_date) {
			$insert[$key]['so_date'] = $so_date;
		}
		foreach (Input::get('invoice') as $key => $invoice) {
			$insert[$key]['invoice'] = $invoice;
		}
		foreach (Input::get('bill_date') as $key => $bill_date) {
			$insert[$key]['bill_date'] = $bill_date;
		}

		$company = Auth::user()->company;
		$plant = Auth::user()->plant;
		$customer_code = Input::get('customer');
		$pono = Input::get('pono');
		$po_no = Input::get('po_no');
		$po_date = date("Y-m-d",strtotime(Input::get('po_date'))) ;
		$eta_po = date("Y-m-d", strtotime(Input::get('eta_po'))) ;
		$etd = date("Y-m-d", strtotime(Input::get('etd'))) ;
		$ship_to_party = Input::get('ship_to_party');
		$source = Input::get('source');
		$currency_rate = Input::get('currency_rate');
		$currency_code = Input::get('currency_code');
		$user_create = Auth::user()->employee_code;
		$user_update = Auth::user()->employee_code;
		$ckdb = DB::table('ss_podetail')->where('po_no','=',$po_no)->get();
		$po = PurchaseOrder::find(Input::get('pono'));
        $po->company        = $company;
        $po->plant        	= $plant;
        $po->po_no        	= $po_no;
        $po->po_date       	= $po_date;
        $po->eta_po        	= $eta_po;
        $po->etd        	= $etd;
        $po->customer_code  = $customer_code;
        $po->ship_to_party  = $ship_to_party;
        $po->source        	= $source;
        $po->currency_rate	= $currency_rate;
        $po->currency_code	= $currency_code;
        $po->user_update    = $user_update;
        foreach ($ckdb as $ck) {
        	if ($ck->qty_in_do_um == 0) {
        		if ($po->save()) {
					foreach ($insert as $row ) {
						if ($row['matcod'] == '') {
		                    DB::table('ss_podetail')->insert([
		                    'po_no'			=> $po_no,
							'material_code' => $row['material_code'],
							'qty_um'		=> $row['qty'],
							'qty_uom'		=> $row['uom'],
							'u_price_idr'	=> $row['price_idr'],
							'u_price_usd'	=> $row['price_usd'],
							'exclude_idr'	=> $row['exclude_idr'],
							'exclude_usd'	=> $row['exclude_usd'],
							'include'		=> $row['include'],
		                    ]);
		                }
		                else
						DB::table('ss_podetail')->where('po_no','=',$pono)->where('material_code','=',$row['matcod'])->update([
							'po_no'			=> $po_no,
							'material_code' => $row['material_code'],
							'qty_um'		=> $row['qty'],
							'qty_uom'		=> $row['uom'],
							'u_price_idr'	=> $row['price_idr'],
							'u_price_usd'	=> round($row['price_idr'] / $currency_rate,3),
							'exclude_idr'	=> number_format($row['price_idr'] * $row['uom'] , 2),
							'exclude_usd'	=> number_format(round((($row['price_idr'] / $currency_rate) * $row['uom']) , 3),2),
							'include'		=> number_format(($row['price_idr'] * $row['uom']) * 1.1, 2),
							]);
					}
					return Redirect::back();	
			}
			}else{
				if ($po->save()) {
					foreach ($insert as $row ) {
						if ($row['matcod'] == '') {
		                    DB::table('ss_podetail')->insert([
		                    'po_no'			=> $po_no,
							'material_code' => $row['material_code'],
							'qty_um'		=> $row['qty'],
							'qty_uom'		=> $row['uom'],
							'u_price_idr'	=> $row['price_idr'],
							'u_price_usd'	=> $row['price_usd'],
							'exclude_idr'	=> $row['exclude_idr'],
							'exclude_usd'	=> $row['exclude_usd'],
							'include'		=> $row['include'],
		                    ]);
		                }
		                else
						DB::table('ss_podetail')->where('po_no','=',$pono)->where('material_code','=',$row['matcod'])->update([
							'po_no'			=> $po_no,
							'material_code' => $row['material_code'],
							'qty_um'		=> $row['qty'],
							'qty_uom'		=> $row['uom'],
							'u_price_idr'	=> $row['price_idr'],
							'u_price_usd'	=> round($row['price_idr'] / $currency_rate,3),
							'exclude_idr'	=> number_format($row['price_idr'] * $row['uom'] , 2),
							'exclude_usd'	=> number_format(round(round($row['price_idr'] / $currency_rate, 3) * $row['uom'],2),2),
							'include'		=> number_format(($row['price_idr'] * $row['uom']) * 1.1, 2),
							'so_no'			=> $row['so_no'],
							'so_date'		=> $row['so_date'],
							'invoice'		=> $row['invoice'],
							'bill_date'		=> $row['bill_date']
							]);
					}
				return Redirect::back();	
			}
		}		
    }
	
}
    public function deleteItem($idtx,$mtcd){
       	DB::table('ss_podetail')->where('po_no','=',$idtx)->where('material_code','=',$mtcd)->delete();
        
        return Redirect::back();
    }
    public function destroy()
	{
		$po_no = Input::get('pono');
		$pomst = PurchaseOrder::find($po_no);
		DB::table('ss_podetail')->where('po_no','=',$po_no)->delete();
        $pomst->delete();
        
        return Redirect::back();
	}
	public function getReport()
	{
		$date_start = date("Y-m-d",strtotime(Input::get('date_start')));
		$date_finish = date("Y-m-d",strtotime(Input::get('date_finish')));
		
		if ($date_finish == '1970-01-01' and $date_start == '1970-01-01') {
			
		return View::make('reports.po')
			->with('list_po',DB::table('ss_podetail as pd')->join('ss_pomaster as pm','pm.po_no','=','pd.po_no')->join('cd_material as mt','mt.material_code','=','pd.material_code')->join('cd_code as cd','cd.code','=','pm.source')->join('ss_customers as ct','ct.customer_code','=','pm.customer_code')->join('ss_customerdtl as csd','csd.ship_to_party','=','pm.ship_to_party')->select('cd.code_name','mt.material_name','pm.eta_po','pm.po_date','pd.po_no','ct.customer_name','csd.ship_name','pd.qty_uom','pd.u_price_idr','pd.exclude_idr','pd.include','pd.u_price_usd','pd.exclude_usd','pm.etd','pd.so_no','pd.so_date','pd.invoice','pd.bill_date')->get())
			->with('date_start',date("d-m-Y"))
			->with('date_finish',date("d-m-Y"));
		}else{
			return View::make('reports.po')
				->with('list_po',DB::table('ss_podetail as pd')->join('ss_pomaster as pm','pm.po_no','=','pd.po_no')->join('cd_material as mt','mt.material_code','=','pd.material_code')->join('cd_code as cd','cd.code','=','pm.source')->join('ss_customers as ct','ct.customer_code','=','pm.customer_code')->join('ss_customerdtl as csd','csd.ship_to_party','=','pm.ship_to_party')->select('cd.code_name','mt.material_name','pm.eta_po','pm.po_date','pd.po_no','ct.customer_name','csd.ship_name','pd.qty_uom','pd.u_price_idr','pd.exclude_idr','pd.include','pd.u_price_usd','pd.exclude_usd','pm.etd','pd.so_no','pd.so_date','pd.invoice','pd.bill_date')->whereBetween('po_date',array($date_start,$date_finish))->get())
				->with('date_start',date("d-m-Y",strtotime($date_start)))
				->with('date_finish',date("d-m-Y",strtotime($date_finish)));
		}
	}
	public function exportexcel()
	{
		$date_start = date("Y-m-d",strtotime(Input::get('date_start')));
		$date_finish = date("Y-m-d",strtotime(Input::get('date_finish')));
		var_dump($date_finish);
		exit();
		// Library phpExcel
		require_once (app_path()."/plugins/phpExcel/PHPExcel.php");
		require_once (app_path()."/plugins/phpExcel/PHPExcel/Writer/Excel2007.php");

		// Buat object baru
		$object = new PHPExcel();

		// Pilih sheet active
		$sheet = $object->getActiveSheet();

		// Pemformatan sederhana (lebih lengkap : cek dokumentasi phpExcel)
		$sheet->getDefaultRowDimension()->setRowHeight(19);
		$sheet->getDefaultStyle()->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
		
		// Ubah ukuran lebar cell C agar menyesuaikan content
		$sheet->getColumnDimension('C')
		    ->setAutoSize(true);

		// Tulis judul di B2
		$sheet->setCellValue('B2', 'Data Peserta Instagram');

		// Tulis header tabel di B4 sampai H4
		$sheet->setCellValue('A4', 'Source')
			  ->setCellValue('B4', 'Product')
			  ->setCellValue('C4', 'Invoice')
			  ->setCellValue('D4', 'SO No.')
			  ->setCellValue('E4', 'SO Date')
			  ->setCellValue('F4', 'Bill Date')
			  ->setCellValue('G4', 'ETA')
			  ->setCellValue('H4', 'ETD')
			  ->setCellValue('I4', '')
			  ->setCellValue('J4', 'SO Date')
			  ;

		// Ambil data
		if ( isset($_GET['q']) ) {
			// filter data yang ditampilkan berdasarkan kata kunci q
			$data = Peins::where('username','like','%'.$_GET['q'].'%')->get();
		}
		else {
			// jika tidak, tampilkan semua
			$data = DB::select( DB::raw("SELECT * FROM ss_pomaster"));
		}

		// Tulis data, mulai dari BARIS KE-5 (karena 1-4 diisi judul)
		$i = 5;
		$number = 1;
		foreach ($data as $row) {
			$sheet->setCellValue('A'.$i, $number++);
			$sheet->setCellValue('B'.$i, $row->po_no);
			$sheet->setCellValue('C'.$i, $row->po_date);
			$sheet->setCellValue('D'.$i, $row->eta_po);
			$sheet->setCellValue('E'.$i, $row->etd);
			
			
			// iterasi i agar ganti baris
			$i++;
		}

		// Beri nama sheet
		$sheet->setTitle('Peserta Instagram');
		// Pilih sheet yang akan aktif
		$object->setActiveSheetIndex(0);
		
		// Output
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="Export-Peserta-Instagram.xlsx"'); // beri nama file
		header('Cache-Control: max-age=0');
		$objWriter = PHPExcel_IOFactory::createWriter($object, 'Excel2007');
		$objWriter->save('php://output');
	}
	public function exportpdf() {
		require_once(app_path().'/plugins/fpdf/fpdf.php');

		$pdf = new FPDF();
		$pdf->AddPage();

		$pdf->Ln(13);
		$pdf->SetFont('Arial','B',16);
		$pdf->Cell(0,10,'DAFTAR KATEGORI BARANG',0,0,'C');
		$pdf->Ln(13);

		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(50,7,"ID",1,0,"C"); 
		$pdf->Cell(140,7,"Kategori",1,0,"C");
		$pdf->Ln();

		$pdf->SetFont('Arial','',12);
		$data = DB::select( DB::raw("SELECT * FROM ss_pomaster"));
		foreach ($data as $row) {
			$pdf->Cell(50,7,$row->po_no,1,0,"C"); 
			$pdf->Cell(140,7,$row->etd,1,0,"L");
			$pdf->Ln();
		}

		$pdf->Output("Kategori.pdf", 'D');
	}
}
