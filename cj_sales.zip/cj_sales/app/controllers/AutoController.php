<?php
/**
* 
*/
class AutoController extends \BaseController
{
	public function postData(){
		
	}
}