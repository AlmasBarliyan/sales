<?php
/**
* 
*/
class CarryingForwardController extends \BaseController
{
	public function __construct()
    {
        $this->beforeFilter('auth');
    }
    public function index()
    {
    	$warehouse = Input::get('storage');
    	if ($warehouse == '') {
    	Session::put('stor',$warehouse);
    	return View::make('carrying_forward.carrying_forward')
    		->with('carrying_forward', DB::table('ss_invmonthly')->leftJoin('cd_material','cd_material.material_code','=','ss_invmonthly.material_code')->leftJoin('cd_code','cd_code.code','=','ss_invmonthly.storage')->get())
    		->with('storage', DB::table('cd_code')->where('hcode','LIKE','%GD%')->where('code','!=','*')->get());
    	}else{
    		Session::put('stor',$warehouse);
    		return View::make('carrying_forward.carrying_forward')
    		->with('carrying_forward', DB::table('ss_invmonthly')->leftJoin('cd_material','cd_material.material_code','=','ss_invmonthly.material_code')->leftJoin('cd_code','cd_code.code','=','ss_invmonthly.storage')->where('ss_invmonthly.storage','=',$warehouse)->get())
    		->with('storage', DB::table('cd_code')->where('hcode','LIKE','%GD%')->where('code','!=','*')->get());
    	}
    }
    public function postCarryingForward()
    {
    	$input = Input::all();
    	var_dump($input);
    }
    public function export()
    {
        $warehouse = Session::get('stor');
        // Library phpExcel
        require_once (app_path()."/plugins/phpExcel/PHPExcel.php");
        require_once (app_path()."/plugins/phpExcel/PHPExcel/Writer/Excel2007.php");

        // Buat object baru
        $object = new PHPExcel();

        // Pilih sheet active
        $sheet = $object->getActiveSheet();
        $styleContent = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => '#333'),
                ),
            ),
        );
        $styleTitle = array(
            'borders' => array(
                'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => '#333'),
                ),
            ),
            'font' => array(
                'bold' => true,
            )
        );
        // Pemformatan sederhana (lebih lengkap : cek dokumentasi phpExcel)
        $sheet->getDefaultRowDimension()->setRowHeight(15);
        $sheet->setAutoFilter('A2:M2');
        $sheet->freezePane('A4');
        $sheet->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        //$sheet->getStyle('A2:M3')->getAlignment()->setWrapText(true);
        $sheet->getStyle('C')->getAlignment()->setWrapText(true);
        

        // Ubah ukuran lebar cell C agar menyesuaikan content
        $sheet->getColumnDimension('A')->setWidth(9);
        $sheet->getColumnDimension('B')->setWidth(12);
        $sheet->getColumnDimension('C')->setWidth(24);
        $sheet->getColumnDimension('D')->setWidth(15);
        $sheet->getColumnDimension('E')->setWidth(12);
        $sheet->getColumnDimension('F')->setWidth(10);
        $sheet->getColumnDimension('G')->setWidth(12);
        $sheet->getColumnDimension('H')->setWidth(10);
        $sheet->getColumnDimension('I')->setWidth(10);
        $sheet->getColumnDimension('J')->setWidth(10);
        $sheet->getColumnDimension('K')->setWidth(10);
        $sheet->getColumnDimension('L')->setWidth(10);
        $sheet->getColumnDimension('M')->setWidth(10);

        // Tulis judul di B2
        //$sheet->setCellValue('A1', $kat->code_name.' '.date("d M Y"));
        
        // Tulis header tabel di B4 sampai H4
        //$sheet->mergeCells('A1:C1')->mergeCells('A2:A3')->mergeCells('B2:B3')->mergeCells('C2:C3')->mergeCells('D2:D3')->mergeCells('E2:F2')->mergeCells('A2:A3')->mergeCells('G2:G3')->mergeCells('H2:H3')->mergeCells('I2:I3')->mergeCells('J2:J3')->mergeCells('K2:K3')->mergeCells('L2:L3')->mergeCells('M2:M3');
        $sheet->setCellValue('A2', 'Month')
              ->setCellValue('B2', 'Product Code')
              ->setCellValue('C2', 'Product Name')
              ->setCellValue('D2', 'Lot Number')
              ->setCellValue('E2', 'Begin (KG)')
              ->setCellValue('F2', 'Begin (BAG)')
              ->setCellValue('G2', 'In (KG)')
              ->setCellValue('H2', 'In (BAG)')
              ->setCellValue('I2', 'Out (KG)')
              ->setCellValue('J2', 'Out (BAG)')
              ->setCellValue('K2', 'End (KG)')
              ->setCellValue('L2', 'End (BAG)')
              ->setCellValue('M2', 'Warehouse')
              ;
        /*$sheet->getStyle('A2:M3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('8ac52a');
        $sheet->getStyle('A1:C1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('8ac52a');
        $sheet->getStyle('A2:M3')->applyFromArray($styleTitle);*/

        if ($warehouse == '') {
            $data = DB::table('ss_invmonthly')->leftJoin('cd_material','cd_material.material_code','=','ss_invmonthly.material_code')->leftJoin('cd_code','cd_code.code','=','ss_invmonthly.storage')->get();
        }else{
            $data = DB::table('ss_invmonthly')->leftJoin('cd_material','cd_material.material_code','=','ss_invmonthly.material_code')->leftJoin('cd_code','cd_code.code','=','ss_invmonthly.storage')->where('ss_invmonthly.storage','=',$warehouse)->get();
        }
        // Tulis data, mulai dari BARIS KE-5 (karena 1-4 diisi judul)
        $i = 4;
        $number = 1;
        foreach ($data as $row) {
            $sheet->setCellValue('A'.$i, $row->yymm);
            $sheet->setCellValue('B'.$i, $row->material_code);
            $sheet->setCellValue('C'.$i, $row->material_name);
            $sheet->setCellValue('D'.$i, $row->lot_number);
            $sheet->setCellValue('E'.$i, $row->begin_qty_uom);
            $sheet->setCellValue('F'.$i, $row->begin_qty_um);
            $sheet->setCellValue('G'.$i, $row->in_qty_uom);
            $sheet->setCellValue('H'.$i, $row->in_qty_um);
            $sheet->setCellValue('I'.$i, $row->out_qty_uom);
            $sheet->setCellValue('J'.$i, $row->out_qty_um);
            $sheet->setCellValue('K'.$i, $row->end_qty_uom);
            $sheet->setCellValue('L'.$i, $row->end_qty_um);
            $sheet->setCellValue('M'.$i, $row->code_name);
            
            $sheet->getStyle('A'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('B'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('C'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('D'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('E'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('F'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('G'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('H'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('I'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('J'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('K'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('L'.$i)->applyFromArray($styleContent);
            $sheet->getStyle('M'.$i)->applyFromArray($styleContent);
            
            // iterasi i agar ganti baris
            $i++;
        }

        // Beri nama sheet
        $sheet->setTitle("Carrying Forward");
        
        // Pilih sheet yang akan aktif
        $object->setActiveSheetIndex(0);
        
        // Output
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Carrying Forward.xlsx"'); // beri nama file
        header('Cache-Control: max-age=0');
        $objWriter = PHPExcel_IOFactory::createWriter($object, 'Excel2007');
        $objWriter->save('php://output');
    }
}