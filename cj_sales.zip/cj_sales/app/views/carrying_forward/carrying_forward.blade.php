@extends('products.table')
@section('content')
<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3>
        Carrying Forward
      </h3>
    </div>

    <div class="title_right">
      <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
        
      </div>
    </div>
  </div>
  <div class="clearfix"></div>

  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_content">
        <form action="{{URL::to('/carrying-forward')}}" method="POST">
          <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">
            <tbody>
              <tr>
                <td>
                  <div class="form-group" >
                    <label class="control-label col-md-2 col-sm-2 col-xs-12" style="margin-top:10px;margin-left:10px">Warehouse</label>
                    <div class="col-md-3 col-sm-3 col-xs-12">
                      <select name="storage" class="form-control">
                        <option disabled selected value>Choose</option>
                        @foreach($storage as $stor)
                          <option value="{{$stor->code}}" <?php if ($stor->code == Session::get('stor')) echo "selected='selected'"; ?>>{{$stor->code_name}}</option>
                        @endforeach
                      </select>
                    </div>                  
                    <div class="col-md-3 col-sm-3 col-xs-12">
                      <button title="Search" type="submit" class="btn btn-primary btn-xs" style="margin-top:5px"><i class="fa fa-search"></i></button>
                    </div>        
                  </div>
                </td>
                <td>
                  <div class="col-md-1 col-sm-1 col-xs-12">
                    <a href="{{URL::to('export-carrying-forward')}}" title="Export To Excel" style="margin-top:5px" class="btn btn-success btn-xs"><i class="fa fa-file-excel-o"></i></a>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </form>
        <form action="{{URL::to('input-carrying-forward')}}" method="POST">
        	<table id="datatable" class="table table-striped responsive-utilities jambo_table bulk_action">
            <thead>
              <tr>
              	<th style="text-align:center">Month</th>
                <th style="text-align:center">Material code</th>
                <th style="text-align:center">Lot Number</th>
                <th style="text-align:center">Begin Qty (KG)</th>
                <th style="text-align:center">In Qty (KG)</th>
                <th style="text-align:center">Out Qty (KG)</th>
                <th style="text-align:center">End Qty (KG) / (BAG)</th>
                <th style="text-align:center">Warehouse</th>
              </tr>
            </thead>
            <tbody>
            @foreach($carrying_forward as $cf)
            @if($cf->status == 'B')
              <tr>
              	<td >{{$cf->yymm}}</td>
                <td ><input type="hidden" name="material_code[]" value="{{$cf->material_code}}"><h6 style="color:red">{{$cf->material_code}} - {{$cf->material_name}}</h6></td>
                <td ><input type="hidden" name="lot_number[]" value="{{$cf->lot_number}}">{{$cf->lot_number}}</td>
                <td >{{$cf->begin_qty_uom}}</td>
                <td >{{$cf->in_qty_uom}}</td>
                <td >{{$cf->out_qty_uom}}</td>
                <td ><input type="text" style="width:80px" name="end_qty_uom[]" value="{{number_format($cf->end_qty_uom)}}" style="text-align:right"> /  {{number_format($cf->end_qty_um)}}</td>
                <td ><input type="hidden" name="storage[]" value="{{$cf->code}}"><input type="hidden" name="status[]" value="{{$cf->status}}">{{$cf->code_name}}</td>
                
              </tr>
            @else
              <tr>
              	<td>{{$cf->yymm}}</td>
              	<td><input type="hidden" name="material_code[]" value="{{$cf->material_code}}">{{$cf->material_code}} - {{$cf->material_name}}</td>
                <td><input type="hidden" name="lot_number[]" value="{{$cf->lot_number}}">{{$cf->lot_number}}</td>
                <td>{{$cf->begin_qty_uom}}</td>
                <td>{{$cf->in_qty_uom}}</td>
                <td>{{$cf->out_qty_uom}}</td>
                <td><input type="text" style="width:80px" name="end_qty_uom[]" value="{{number_format($cf->end_qty_uom)}}" style="text-align:right"> / {{number_format($cf->end_qty_um)}}</td>
                <td><input type="hidden" name="storage[]" value="{{$cf->code}}"><input type="hidden" name="status[]" value="{{$cf->status}}">{{$cf->code_name}}</td>
                
              </tr>
            @endif
            @endforeach
            </tbody>
          </table>
          <div style="text-align:right">
          	<button type="submit" class="btn btn-success">Save</button>
          </div>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
@stop