
<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" type="image/png" href="{{{ asset('images/logo_CJ.png') }}}"/>
  <title>Send Email  </title>

  <!-- Bootstrap core CSS -->

  <link href="css/bootstrap.min.css" rel="stylesheet">

  <link href="fonts/css/font-awesome.min.css" rel="stylesheet">
  <link href="css/animate.min.css" rel="stylesheet">

  <!-- Custom styling plus plugins -->
  <link href="css/custom.css" rel="stylesheet">
  <link href="css/icheck/flat/green.css" rel="stylesheet">
  <!-- editor -->
  <link href="css/editor/external/google-code-prettify/prettify.css" rel="stylesheet">
  <link href="css/editor/index.css" rel="stylesheet">
  
  <!-- switchery -->
  <link rel="stylesheet" href="css/switchery/switchery.min.css" />

  <script src="js/jquery.min.js"></script>

  <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
        <![endif]-->

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>
<body class="nav-md" style="background:white">

  <div class="container body">
    <div class="main_container">
      <!-- page content -->
      <div class="">
        <div class="col-md-12 col-xs-12">
          <div class="x_content">
            <br />
            <form class="form-horizontal form-label-left" action="./send" method="post">
              <div class="control-group">
                <label class="control-label col-md-1 col-sm-1 col-xs-12">To : </label>
                <div class="col-md-11 col-sm-11 col-xs-12">
                  
                  <input id="tags_1" name="to" type="text" class="tags form-control" value="suyono@cj.net, r4chm4t.cjsub@hotmail.com, admin2@cj.net, rakhmat.darmawan@cj.net, priyoan@cj.net, priyo.adi@cj.net, jean.lalang@cj.net, beny.siswoyo@cj.net, mochamad.syarifudin@cj.net, devatama.dhika@cj.net, devatama.dhika@cj.net, dewi.permatasari@cj.net, santhy.nurhenti@cj.net, outboundadm@cj.net, outboundcik@cj.net, hasanuddin@cj.net, hasanuddin@cj.net, Vivi.delima1@cj.net, dadang.iskandar@cj.net, admcji.ckg@cj.net, ferry.grace@cj.net, Feri.arizal@cj.net, nursim.ilham@cj.net"/>
                  <div id="suggestions-container" style="position: relative; float: left; width: 250px; margin: 10px;"></div>
                </div>
              </div>
              <div class="control-group">
                <label class="control-label col-md-1 col-sm-1 col-xs-12">Cc : </label>
                <div class="col-md-11 col-sm-11 col-xs-12">
                  <input id="tags_2" name="cc" type="text" class="tags form-control" value="eduard.sahertian@cj.net, dodik@cj.co.id, dhanny@cj.co.id, hendras@cj.co.id, mubin.nuryanto@cj.co.id, rysda@cj.co.id, tri.hayyu@cj.co.id, rolan@cj.co.id, fierco@cj.co.id" />
                  <div id="suggestions-container" style="position: relative; float: left; width: 250px; margin: 10px;"></div>
                </div>
              </div>
              <div class="control-group">
                <label class="control-label col-md-1 col-sm-1 col-xs-12">Subject : </label>
                <div class="col-md-11 col-sm-11 col-xs-12">
                  <input type="text" name="subject" class="form-control" />
                  <div id="suggestions-container" style="position: relative; float: left; width: 250px; margin: 10px;"></div>
                </div>
              </div>
              <div class="control-group">
                <label class="control-label col-md-1 col-sm-1 col-xs-12">Message: </label>
                <div class="col-md-11 col-sm-11 col-xs-12">
                  <textarea name="message" class="form-control" style="width: 100%;height: 87px;">
                  </textarea>
                  <div style="overflow-x: scroll;width:100%">
                    <table id="example2" class="table table-bordered table-hover" style="width:1300px">
                        <thead>
                            <tr class='headings'>
                              <th style='text-align:center'>DO No</th>
                              <th style='text-align:center'>Customer</th>
                              <th style='text-align:center'>Destination</th>
                              <th style='text-align:center'>Trucking</th>
                              <th style='text-align:center'>Product </th>
                              <th style='text-align:center'>PO No.</th>
                              <th style='text-align:center'>PO Date</th>
                              <th style='text-align:center'>Qty (Kg) </th>
                              <th style='text-align:center'>Lot Number</th>
                              <th style='text-align:center'>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        	$no = 1;
                        	$jum = 1;
            							$detail = DB::table('ss_outmaster as om')
            								->select(DB::raw("*, (select count(material_code) from ss_outdtl where no_transaksi = od.no_transaksi) as jumlah"))
            								->leftJoin('ss_outdtl as od','om.no_transaksi','=','od.no_transaksi')
            								->leftJoin('cd_material as mt','mt.material_code','=','od.material_code')
            								->leftJoin('ss_customers as cm','cm.customer_code','=','om.customer_code')
            								->leftJoin('ss_customerdtl as cd','cd.ship_to_party','=','om.destination')
            								->leftJoin('ss_pomaster as pm','pm.po_no','=','om.po_no')
            								->whereIn('od.no_transaksi',$do_dtl)->get();
            						?> 
                        	@foreach($detail as $dtl)  
                        		<tr class='even pointer'>
                        		<?php 
                              
                              	if ($jum <= 1) {?>
                        			<td rowspan="{{$dtl->jumlah}}"><h6>{{$dtl->no_transaksi}}</h6></td>
                        			<td rowspan="{{$dtl->jumlah}}"><h6>{{$dtl->customer_name}}</h6></td>
                        			<td rowspan="{{$dtl->jumlah}}"><h6>{{$dtl->street2}}</h6></td>
                        			<td rowspan="{{$dtl->jumlah}}"><h6>{{$dtl->trucking}}</h6></td>
                        			<td rowspan="{{$dtl->jumlah}}"><h6>{{$dtl->material_code}} - {{$dtl->material_name}}</h6></td>
                        			<td rowspan="{{$dtl->jumlah}}"><h6>{{$dtl->po_no}}</h6></td>
                        			<td rowspan="{{$dtl->jumlah}}"><h6>{{date("d M", strtotime($dtl->po_date))}}</h6></td>
                        			<?php
	                                $jum = $dtl->jumlah;
	                                $no++;
	                              }else{
	                                $jum = $jum - 1;
	                              }
	                             ?>
                        			<td><h6>{{$dtl->qty_out_uom}}</h6></td>
                        			<td><h6>{{$dtl->lot_number}} ({{$dtl->qty_out_um}} {{$dtl->um}})</h6></td>
                        			<td><h6>{{$dtl->remarks}}</h6></td>
                        		</tr>
                        	@endforeach
                        </tbody>
                      </table>
                  </div>
                </div>
              </div>
              <div class="control-group" >
                <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-1" style="margin-top:15px">
                  <a href="{{URL::to('/delivery-order')}}"><button class="btn btn-info" type="button"><i class="fa fa-arrow-circle-left"></i> Back</button></a>
                  <button type="submit" class="btn btn-success">Submit</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
      
    </div>
    <script src="js/bootstrap.min.js"></script>

  <!-- bootstrap progress js -->
  <script src="js/progressbar/bootstrap-progressbar.min.js"></script>
  
  <!-- icheck -->
  <script src="js/icheck/icheck.min.js"></script>
  <!-- tags -->
  <script src="js/tags/jquery.tagsinput.min.js"></script>
  <!-- switchery -->
  <script src="js/switchery/switchery.min.js"></script>
  <!-- daterangepicker -->
  <script type="text/javascript" src="js/moment/moment.min.js"></script>
  <script type="text/javascript" src="js/datepicker/daterangepicker.js"></script>
  <!-- richtext editor -->
  <script src="js/editor/bootstrap-wysiwyg.js"></script>
  <script src="js/editor/external/jquery.hotkeys.js"></script>
  <script src="js/editor/external/google-code-prettify/prettify.js"></script>
  <!-- select2 -->
  <script src="js/select/select2.full.js"></script>
  <!-- form validation -->
  <script type="text/javascript" src="js/parsley/parsley.min.js"></script>
  <!-- textarea resize -->
  <script src="js/textarea/autosize.min.js"></script>
  <script>
    autosize($('.resizable_textarea'));
  </script>
  <!-- Autocomplete -->
  <script type="text/javascript" src="js/autocomplete/countries.js"></script>
  <script src="js/autocomplete/jquery.autocomplete.js"></script>
  <!-- pace -->
  <script src="js/pace/pace.min.js"></script>
  <script type="text/javascript">
    $(function() {
      'use strict';
      var countriesArray = $.map(countries, function(value, key) {
        return {
          value: value,
          data: key
        };
      });
      // Initialize autocomplete with custom appendTo:
      $('#autocomplete-custom-append').autocomplete({
        lookup: countriesArray,
        appendTo: '#autocomplete-container'
      });
    });
  </script>
  <script src="js/custom.js"></script>


  <!-- select2 -->
  <script>
    $(document).ready(function() {
      $(".select2_single").select2({
        placeholder: "Select a state",
        allowClear: true
      });
      $(".select2_group").select2({});
      $(".select2_multiple").select2({
        maximumSelectionLength: 4,
        placeholder: "With Max Selection limit 4",
        allowClear: true
      });
    });
  </script>
  <!-- /select2 -->
  <!-- input tags -->
  <script>
    function onAddTag(tag) {
      alert("Added a tag: " + tag);
    }

    function onRemoveTag(tag) {
      alert("Removed a tag: " + tag);
    }

    function onChangeTag(input, tag) {
      alert("Changed a tag: " + tag);
    }

    $(function() {
      $('#tags_1').tagsInput({
        width: 'auto'
      });
      $('#tags_2').tagsInput({
        width: 'auto'
      });
    });
  </script>
  <!-- /input tags -->
  <!-- form validation -->
  <script type="text/javascript">
    $(document).ready(function() {
      $.listen('parsley:field:validate', function() {
        validateFront();
      });
      $('#demo-form .btn').on('click', function() {
        $('#demo-form').parsley().validate();
        validateFront();
      });
      var validateFront = function() {
        if (true === $('#demo-form').parsley().isValid()) {
          $('.bs-callout-info').removeClass('hidden');
          $('.bs-callout-warning').addClass('hidden');
        } else {
          $('.bs-callout-info').addClass('hidden');
          $('.bs-callout-warning').removeClass('hidden');
        }
      };
    });

    $(document).ready(function() {
      $.listen('parsley:field:validate', function() {
        validateFront();
      });
      $('#demo-form2 .btn').on('click', function() {
        $('#demo-form2').parsley().validate();
        validateFront();
      });
      var validateFront = function() {
        if (true === $('#demo-form2').parsley().isValid()) {
          $('.bs-callout-info').removeClass('hidden');
          $('.bs-callout-warning').addClass('hidden');
        } else {
          $('.bs-callout-info').addClass('hidden');
          $('.bs-callout-warning').removeClass('hidden');
        }
      };
    });
    try {
      hljs.initHighlightingOnLoad();
    } catch (err) {}
  </script>
  <!-- /form validation -->
  <!-- editor -->
  <script>
    $(document).ready(function() {
      $('.xcxc').click(function() {
        $('#descr').val($('#editor').html());
      });
    });

    $(function() {
      function initToolbarBootstrapBindings() {
        var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
            'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
            'Times New Roman', 'Verdana'
          ],
          fontTarget = $('[title=Font]').siblings('.dropdown-menu');
        $.each(fonts, function(idx, fontName) {
          fontTarget.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
        });
        $('a[title]').tooltip({
          container: 'body'
        });
        $('.dropdown-menu input').click(function() {
            return false;
          })
          .change(function() {
            $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
          })
          .keydown('esc', function() {
            this.value = '';
            $(this).change();
          });

        $('[data-role=magic-overlay]').each(function() {
          var overlay = $(this),
            target = $(overlay.data('target'));
          overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
        });
        if ("onwebkitspeechchange" in document.createElement("input")) {
          var editorOffset = $('#editor').offset();
          $('#voiceBtn').css('position', 'absolute').offset({
            top: editorOffset.top,
            left: editorOffset.left + $('#editor').innerWidth() - 35
          });
        } else {
          $('#voiceBtn').hide();
        }
      };

      function showErrorAlert(reason, detail) {
        var msg = '';
        if (reason === 'unsupported-file-type') {
          msg = "Unsupported format " + detail;
        } else {
          console.log("error uploading file", reason, detail);
        }
        $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
          '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
      };
      initToolbarBootstrapBindings();
      $('#editor').wysiwyg({
        fileUploadError: showErrorAlert
      });
      window.prettyPrint && prettyPrint();
    });
  </script>
  <!-- /editor -->
</body>

</html>