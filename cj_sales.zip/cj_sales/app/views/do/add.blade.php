@extends('products.table')
@section('content')
        <div class="">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2><a href="{{URL::to('/delivery-order')}}"><button class="btn btn-round btn-info" type="button"><i class="fa fa-arrow-circle-left"></i> Back</button></a> Create Delivery Order </h2>
                  
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <form class="form-horizontal form-label-left input_mask" action="{{URL::to('/create-delivery-order')}}" method="post">
                  <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">                    
                    <tbody>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">DO No.</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <p id="dono"><input name="no_transaksi" type="text" style="width: 250px;" readonly="" class="form-control" /></p>
                              </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">PO NO. </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                  {{ Form::select('po_no', $po, null, array('id'=>'sPo','class'=>'select2_single form-control'))  }}
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">Date Out</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <input type="text" style="z-index: 100000;width: 250px;" value="<?php echo date('d-m-Y')?>" name="date_out" id="idTourDateDetails1" class="form-control has-feedback-left""> 
                                <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                <span id="inputSuccess2Status" class="sr-only">(success)</span>
                              </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Customer </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                  
                                  <p id="cu"><input style="width:400px" type="text" class="form-control" ></p>
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Trucking </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                  <p ><input required="" type="text" style="width: 250px;" class="form-control" name="trucking"></p>
                                </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Destination</label>
                              <div class="col-md-9 col-sm-9 col-xs-12">
                                <p id="sip"><input style="width:400px" type="text" class="form-control" ></p>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Remarks</label>
                          <div class="col-md-9 col-sm-9 col-xs-12">
                            <input type="text" style="width:250px"  class="form-control" name="remarks">
                          </div>
                        </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Warehouse </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                <select name="source" required="required" class="select2_single form-control" id="sWh">
                                  <option></option>
                                    @foreach($warehouse as $wh)
                                      <option value="{{$wh->code}}">{{$wh->code_name}}</option>
                                    @endforeach
                                </select>
                                </div>
                            </div>
                          </td>
                        </tr>
                         
                        

                    </tbody>
                  </table>
                    <div>
                      <table id="inv" class='table table-striped responsive-utilities jambo_table bulk_action order-list' cellspacing="0" width="100%">
                          <thead>
                            <tr class='headings'>
                              <th class='column-title' colspan='2' style='text-align:center'>Material </th>
                              <th class='column-title' style='text-align:center'>Lot Number</th>
                              <th class='column-title' style='text-align:center' colspan='2'>Qty</th>
                              <th class='column-title' style='text-align:center' colspan='2'>Qty DO</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr class='even pointer'>
                              <td>
                                <a class="deleteRow" title="Hapus Item"><i class="fa fa-trash"></i></a>
                                <input type="text" id="sku" name="material_code[]" style="width:80px">
                                <input type="button" name="choice" onClick="selectValue('sku','pir','lot','qty_um','um','qty_uom','uom','out_um','out_uom','size','qty_out_um','qty_out_uom')" value="..." title="Cari Item" style="width:20px">
                              </td>
                              <td>
                                <input type="text" name="material_name[]" id="pir" />
                              </td>
                              <td>
                                <input type="text" name="lot_number[]" id="lot" style="width:100px"/>
                              </td>
                              <td>
                                <input style="width:80px" type="text" id="qty_um" name="qty_um[]" readonly="readonly" />
                                <input type="hidden" name="size[]" id="size" class="tInput" />
                                <input style="width:40px" id="um" class="tInput" readonly="readonly"/>
                              </td>
                              <td>
                                <input style="width:80px" type="text" id="qty_uom" name="qty_uom[]" readonly="readonly" />
                                <input style="width:30px" id="uom" class="tInput" readonly="readonly"/>
                              </td>
                              <td>
                                <input style="width:80px" type="text" id="qty_out_um" name="qty_out_um[]" />
                                <input style="width:40px" id="out_um" class="tInput" readonly="readonly"/>
                              </td>
                              <td>
                                <input style="width:80px" type="text" id="qty_out_uom" name="qty_out_uom[]" />
                                <input style="width:30px" id="out_uom" class="tInput" readonly="readonly"/>
                              </td>
                            </tr>  
                          </tbody>
                      </table>
                    </div>                    
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12" style="text-align:left">
                        <a href="#" id="addrow" class="btn btn-primary"><span> + Add Row</span></a>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
                        <button type="button" data-toggle="modal" data-target=".bs-example-modal-lg" class="btn btn-warning">Add Email Recipients</button>
                        <button type="submit" class="btn btn-success">Save & Send Email</button>
                      </div>
                    </div>
                    <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
                      <div class="modal-dialog modal-lg" style="width:70%">
                        <div class="modal-content">

                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                            </button>
                            <h4 class="modal-title" id="myModalLabel">Add Purchase Order</h4>
                          </div>
                          <div class="modal-body" style="max-height: calc(100vh - 212px);overflow-y: auto;">
                            <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">
                              <tbody>
                                <tr>
                                  <td>
                                    <div class="item form-group" >
                                      <label class="col-md-1 col-sm-1 col-xs-10" for="name">To</label>
                                      <div class="col-md-11 col-sm-11 col-xs-10">
                                        <input type="text" name="to[]" required="required" />
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    <div class="item form-group" >
                                      <label class="col-md-1 col-sm-1 col-xs-10" for="name">Cc</label>
                                      <div class="col-md-11 col-sm-11 col-xs-10">
                                        <input type="text" name="cc[]" required="required" />
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    <div class="item form-group" >
                                      <label class="col-md-1 col-sm-1 col-xs-10" for="name">Subject</label>
                                      <div class="col-md-11 col-sm-11 col-xs-10">
                                        <input type="text" name="subject" required="required" />
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    <div class="item form-group" >
                                      <label class="col-md-1 col-sm-1 col-xs-10" for="name">Message</label>
                                      <div class="col-md-11 col-sm-11 col-xs-10">
                                        <div id="alerts"></div>
                                        <div class="btn-toolbar editor" data-role="editor-toolbar" data-target="#editor">
                                          <div class="btn-group">
                                            <a class="btn dropdown-toggle" data-toggle="dropdown" title="Font"><i class="fa fa-font"></i><b class="caret"></b></a>
                                            <ul class="dropdown-menu">
                                            </ul>
                                          </div>
                                          <div class="btn-group">
                                            <a class="btn dropdown-toggle" data-toggle="dropdown" title="Font Size"><i class="fa fa-text-height"></i>&nbsp;<b class="caret"></b></a>
                                            <ul class="dropdown-menu">
                                              <li>
                                                <a data-edit="fontSize 5">
                                                  <p style="font-size:17px">Huge</p>
                                                </a>
                                              </li>
                                              <li>
                                                <a data-edit="fontSize 3">
                                                  <p style="font-size:14px">Normal</p>
                                                </a>
                                              </li>
                                              <li>
                                                <a data-edit="fontSize 1">
                                                  <p style="font-size:11px">Small</p>
                                                </a>
                                              </li>
                                            </ul>
                                          </div>
                                          <div class="btn-group">
                                            <a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i class="fa fa-bold"></i></a>
                                            <a class="btn" data-edit="italic" title="Italic (Ctrl/Cmd+I)"><i class="fa fa-italic"></i></a>
                                            <a class="btn" data-edit="strikethrough" title="Strikethrough"><i class="fa fa-strikethrough"></i></a>
                                            <a class="btn" data-edit="underline" title="Underline (Ctrl/Cmd+U)"><i class="fa fa-underline"></i></a>
                                          </div>
                                          <div class="btn-group">
                                            <a class="btn" data-edit="insertunorderedlist" title="Bullet list"><i class="fa fa-list-ul"></i></a>
                                            <a class="btn" data-edit="insertorderedlist" title="Number list"><i class="fa fa-list-ol"></i></a>
                                            <a class="btn" data-edit="outdent" title="Reduce indent (Shift+Tab)"><i class="fa fa-dedent"></i></a>
                                            <a class="btn" data-edit="indent" title="Indent (Tab)"><i class="fa fa-indent"></i></a>
                                          </div>
                                          <div class="btn-group">
                                            <a class="btn" data-edit="justifyleft" title="Align Left (Ctrl/Cmd+L)"><i class="fa fa-align-left"></i></a>
                                            <a class="btn" data-edit="justifycenter" title="Center (Ctrl/Cmd+E)"><i class="fa fa-align-center"></i></a>
                                            <a class="btn" data-edit="justifyright" title="Align Right (Ctrl/Cmd+R)"><i class="fa fa-align-right"></i></a>
                                            <a class="btn" data-edit="justifyfull" title="Justify (Ctrl/Cmd+J)"><i class="fa fa-align-justify"></i></a>
                                          </div>
                                          <div class="btn-group">
                                            <a class="btn dropdown-toggle" data-toggle="dropdown" title="Hyperlink"><i class="fa fa-link"></i></a>
                                            <div class="dropdown-menu input-append">
                                              <input class="span2" placeholder="URL" type="text" data-edit="createLink" />
                                              <button class="btn" type="button">Add</button>
                                            </div>
                                            <a class="btn" data-edit="unlink" title="Remove Hyperlink"><i class="fa fa-cut"></i></a>

                                          </div>

                                          <div class="btn-group">
                                            <a class="btn" title="Insert picture (or just drag & drop)" id="pictureBtn"><i class="fa fa-picture-o"></i></a>
                                            <input type="file" data-role="magic-overlay" data-target="#pictureBtn" data-edit="insertImage" />
                                          </div>
                                          <div class="btn-group">
                                            <a class="btn" data-edit="undo" title="Undo (Ctrl/Cmd+Z)"><i class="fa fa-undo"></i></a>
                                            <a class="btn" data-edit="redo" title="Redo (Ctrl/Cmd+Y)"><i class="fa fa-repeat"></i></a>
                                          </div>
                                        </div>

                                        <div id="editor">

                                        </div>
                                        <textarea name="message" id="descr" style="display:none;"></textarea>
                                        <br />
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          </div>
                        </div>
                      </div>
                    </div>
                    </form>
                </div>
              </div>
            </div>
          </div>
        </div>
@stop
@section('style')
{{ HTML::style('css/css/layout-styles.css')}}
{{HTML::style('css/css/themes/smoothness/jquery-ui-1.8.4.custom.css')}}
<!-- editor -->
{{ HTML::style('css/editor/external/google-code-prettify/prettify.css')}}
{{ HTML::style('css/editor/index.css')}}
@stop
@section('script')
<!-- richtext editor -->
{{ HTML::script('js/editor/bootstrap-wysiwyg.js')}}
{{ HTML::script('js/editor/external/jquery.hotkeys.js')}}
{{ HTML::script('js/editor/external/google-code-prettify/prettify.js')}}
<!-- editor -->
  <script>
    $(document).ready(function() {
      $('.xcxc').click(function() {
        $('#descr').val($('#editor').html());
      });
    });

    $(function() {
      function initToolbarBootstrapBindings() {
        var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
            'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
            'Times New Roman', 'Verdana'
          ],
          fontTarget = $('[title=Font]').siblings('.dropdown-menu');
        $.each(fonts, function(idx, fontName) {
          fontTarget.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
        });
        $('a[title]').tooltip({
          container: 'body'
        });
        $('.dropdown-menu input').click(function() {
            return false;
          })
          .change(function() {
            $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
          })
          .keydown('esc', function() {
            this.value = '';
            $(this).change();
          });

        $('[data-role=magic-overlay]').each(function() {
          var overlay = $(this),
            target = $(overlay.data('target'));
          overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
        });
        if ("onwebkitspeechchange" in document.createElement("input")) {
          var editorOffset = $('#editor').offset();
          $('#voiceBtn').css('position', 'absolute').offset({
            top: editorOffset.top,
            left: editorOffset.left + $('#editor').innerWidth() - 35
          });
        } else {
          $('#voiceBtn').hide();
        }
      };

      function showErrorAlert(reason, detail) {
        var msg = '';
        if (reason === 'unsupported-file-type') {
          msg = "Unsupported format " + detail;
        } else {
          console.log("error uploading file", reason, detail);
        }
        $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
          '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
      };
      initToolbarBootstrapBindings();
      $('#editor').wysiwyg({
        fileUploadError: showErrorAlert
      });
      window.prettyPrint && prettyPrint();
    });
  </script>
  <!-- /editor -->
<script type="text/javascript">
  $('#idTourDateDetails1').datepicker({
       dateFormat: 'dd-mm-yy',
       changeMonth: true,
       changeYear: true,
       altField: "#idTourDateDetailsHidden",
       altFormat: "yy-mm-dd"
   });
  document.getElementById("idTourDateDetails1").focus();
</script>
{{ HTML::script('js/select/select2.full.js')}}
<script>
    $(document).ready(function() {
        $(".select2_single").select2({
            placeholder: "Select...",
            allowClear: true
        });
        $(".select2_group").select2({});
        $(".select2_multiple").select2({
            maximumSelectionLength: 4,
            placeholder: "With Max Selection limit 4",
            allowClear: true
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#sCustomer").on('change', function(){
        $.post('{{ URL::to('delivery/data1') }}', {type: 'dl', id: $("#sCustomer").val()}, function(e){
            $("#dl").html(e);
        });
        
        $('#sMaterial').html('');
        $('#sDesa').html('');
        
    });
    $('#sLotnumber').on('change', function(){
        $.post('{{ URL::to('delivery/data') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
            $('#sMaterial').html(e);
        });
        $('#sDesa').html('');
    });
    $('#sKecamatan').on('change', function(){
        $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
            $('#sDesa').html(e);
        });
    });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#sPo").on('change', function(){
        /*$.post('{{ URL::to('delivery/show') }}', {type: 'po', wh: $("#sWh").val(), pono: $("#pono").val()}, function(e){
            $("#inv").html(e);
        });*/
        $.post('{{ URL::to('delivery/show') }}', {type: 'cu', id: $("#sPo").val()}, function(e){
            $("#cu").html(e);
        });
        $.post('{{ URL::to('delivery/show') }}', {type: 'sip', id: $("#sPo").val()}, function(e){
            $("#sip").html(e);
        });
        /*$.post('{{ URL::to('delivery/show') }}', {type: 'stor', id: $("#sPo").val()}, function(e){
            $("#stor").html(e);
        });*/
        $('#sMaterial').html('');
        $('#sDesa').html('');
    });
    });
</script>
<script type="text/javascript">
  $(document).ready(function() {
        $("#sWh").on('change', function(){
          $.post('{{ URL::to('delivery/show') }}', {type: 'po', wh: $("#sWh").val(), pono: $("#pono").val()}, function(e){
              $("#inv").html(e);
          });
          $.post('{{ URL::to('delivery/show') }}', {type: 'dono', wh: $("#sWh").val(), dt: $("#idTourDateDetails1").val() }, function(e){
              $("#dono").html(e);
          });
        });
    });
</script>
<script type="text/javascript">
function updateValue(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue1(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue2(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue3(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue4(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue5(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue6(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue7(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue8(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue9(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue10(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    /*if (localStorage.getItem("sisa")!=null) {
      if (localStorage.getItem("sisa")==0) {
        alert("Kuantitas Terpenuhi");
        document.getElementById(id).value = value;  
      }else{
        alert("Kuantitas pada DO masih kurang "+localStorage.getItem("sisa"));
        document.getElementById(id).value = value;
      }
    }else{*/
      document.getElementById(id).value = value;
    //}
}
function updateValue11(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
</script>
<script>
          $(document).ready(function () {
            var counter = 1;
            var co = 1;
            $("#addrow").on("click", function () {
              counter++;
              co++;
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><a class="deleteRow"><i class="fa fa-trash"></i> </a><input type="text" id="sku'+ co +'" name="material_code[]" style="width:80px"> <input type="button" name="choice" onClick="selectValue(\''+'sku'+co+'\',\''+'pir'+co+'\',\''+'lot'+co+'\',\''+'qty_um'+co+'\',\''+'um'+co+'\',\''+'qty_uom'+co+'\',\''+'uom'+co+ '\',\''+'out_um'+co+'\',\''+'out_uom'+co+'\',\''+'size'+co+'\',\''+'qty_out_um'+co+'\',\''+'qty_out_uom'+co+'\')" value="..." style="width:20px"></td>';
              cols += '<td><input type="text" id="pir'+ co +'" name="material_name[]"/></td>';
              cols += '<td><input type="text" id="lot'+ co +'" name="lot_number[]" style="width:100px"/></td>';
              cols += '<td><input style="width:80px" type="text" id="qty_um'+ co +'" name="qty_um[]" readonly="readonly" /><input type="hidden" name="size[]" id="size'+ co +'" class="tInput" /> <input style="width:40px" id="um'+ co +'" class="tInput" readonly="readonly"/></td><td><input style="width:80px" type="text" id="qty_uom'+ co +'" name="qty_uom[]" readonly="readonly" /> <input style="width:30px" id="uom'+ co +'" class="tInput" readonly="readonly"/></td>';
              cols += '<td><input style="width:80px" type="text" id="qty_out_um'+ co +'" name="qty_out_um[]" /> <input style="width:40px" id="out_um'+ co +'" class="tInput" readonly="readonly"/></td><td><input style="width:80px" type="text" id="qty_out_uom'+ co +'" name="qty_out_uom[]" /> <input style="width:30px" id="out_uom'+ co +'" class="tInput" readonly="readonly"/></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);

            });
            
            $("table.order-list").on("change", 'input[name^="price"], input[name^="qty_out_um"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
          function selectValue(id,pir,lot,qty_um,um,qty_uom,uom,out_um,out_uom,size,qty_out_um,qty_out_uom)
          {
             var counter = 1;
             var co = 1;
              var myData = new Array('sku'+co, 'pir=pir'+co);
              var url = myData.join('&');
              // open popup window and pass field id
              
                window.open('../sku1.php?id=' + encodeURIComponent(id)+'&pir='+encodeURIComponent(pir)+'&lot='+encodeURIComponent(lot)+'&qty_um='+encodeURIComponent(qty_um)+'&um='+encodeURIComponent(um)+'&qty_uom='+encodeURIComponent(qty_uom)+'&uom='+encodeURIComponent(uom)+'&out_um='+encodeURIComponent(out_um)+'&out_uom='+encodeURIComponent(out_uom)+'&size='+encodeURIComponent(size)+'&qty_out_um='+encodeURIComponent(qty_out_um)+'&qty_out_uom='+encodeURIComponent(qty_out_uom),'popuppage',
                'width=1050,toolbar=1,resizable=1,scrollbars=yes,height=400,top=100,left=100');  
              
              
          }
          function selectValue1()
          {
             var counter = 1;
             var co = 1;
              var myData = new Array('sku'+co, 'pir=pir'+co);
              var url = myData.join('&');
              // open popup window and pass field id
              
                window.open('../send-delivery-order','popuppage',
                'width=1050,toolbar=1,resizable=1,scrollbars=yes,height=400,top=100,left=100');  
              
              
          }  
          function calculateRow(row) {
            var size = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty_out_um"]').val();
            var qty_um = +row.find('input[name^="qty_um"]').val();
            if (qty > qty_um ) {
              alert("Quantity Melebihi Stok");
              row.find('input[name^="qty_out_um"]').val("");
              row.find('input[name^="qty_out_uom"]').val("");
            }
            else{
              row.find('input[name^="qty_out_uom"]').val((size * qty));  
            }
            
            
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
        <script type="text/javascript">
          localStorage.clear();
          localStorage.setItem("sisa", 0);
        </script>
@stop