@extends('products.table')
@section('content')
        <div class="">
          <div class="page-title">
            <div class="title_left">
              <h3>
                Delivery Order
              </h3>
            </div>

            <div class="title_right">
              <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                <div class="input-group">
                  <input type="text" class="form-control" placeholder="Search for...">
                  <span class="input-group-btn">
                    <button class="btn btn-default" type="button">Go!</button>
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Create Delivery Order </h2>
                  
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <form class="form-horizontal form-label-left input_mask" action="{{URL::to('/create-delivery-order')}}" method="post">
                  <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">                    
                    <tbody>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">DO No.</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <p id="dono"><input name="no_transaksi" type="text" style="width: 250px;" readonly="" class="form-control" /></p>
                              </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">PO NO. </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                  {{ Form::select('po_no', $po, null, array('id'=>'sPo','class'=>'select2_single form-control'))  }}
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">Date Out</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <input name="date_out" type="date" style="width: 250px;" value="<?php echo date('Y-m-d')?>" class="form-control" />
                                                          </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Customer </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                  
                                  <p id="cu"><input  type="text" class="form-control" ></p>
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Trucking </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                  <p ><input required="" type="text" style="width: 250px;" class="form-control" name="trucking"></p>
                                </div>
                            </div>
                            <!-- <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">No. Surat Jalan</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <?php 
                                /*$no_in = DB::select(DB::raw("select max(substr(no_srtjln,-5,5)) as max from ss_outmaster where(select max(substr(no_srtjln,-5,5)) from ss_outmaster )"));*/
                                $no_in = DB::select(DB::raw("select max(substr(no_srtjln,-5,5)) as max from ss_outmaster where(select max(substr(no_srtjln,-5,5)) from ss_outmaster where substr(no_srtjln,1,8)= DATE_FORMAT(NOW(),'%Y%m%d') )"));
                                ?>
                                @foreach($no_in as $noin)
                                <input style="width: 250px;" type="text" readonly="" class="form-control" value="{{date('Ymd'). sprintf('%05d', $noin->max+1)}}" name="no_srtjln">
                                @endforeach  
                              </div>
                            </div> -->
                          </td>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Destination</label>
                              <div class="col-md-9 col-sm-9 col-xs-12">
                                <p id="sip"><input  type="text" class="form-control" ></p>
                                <!-- {{ Form::select('ship_to_party', array(), null, array('id' => 'dl', 'class'=>'select2_single form-control'))  }} -->
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Remarks</label>
                          <div class="col-md-9 col-sm-9 col-xs-12">
                            <input type="text" style="width:250px"  class="form-control" name="remarks">
                          </div>
                        </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Warehouse </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                <select name="source" required="required" class="select2_single form-control" id="sWh">
                                  <option></option>
                                    @foreach($warehouse as $wh)
                                      <option value="{{$wh->code}}">{{$wh->code_name}}</option>
                                    @endforeach
                                </select>
                                  <!-- <p id="stor"><input  type="text" class="form-control" ></p> -->
                                </div>
                            </div>
                          </td>
                        </tr>
                         
                        

                    </tbody>
                  </table>
                    <div>
                      <table id="inv" class='table table-striped responsive-utilities jambo_table bulk_action order-list' cellspacing="0" width="100%">
                      <!-- <table class='table table-striped responsive-utilities jambo_table bulk_action order-list ' id="sProducts"> -->
                          <thead>
                            <tr class='headings'>
                              <th class='column-title' colspan='2' style='text-align:center'>Material </th>
                              <th class='column-title' style='text-align:center'>Lot Number</th>
                              <th class='column-title' style='text-align:center'>Qty</th>
                              <th class='column-title' style='text-align:center' colspan='4'>Qty DO</th>
                            </tr>
                          </thead>
                          <tbody>
                              
                          </tbody>
                      </table>
                    </div>                    
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
                        <button type="submit" class="btn btn-success">Create DO</button>
                      </div>
                    </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
@stop
@section('script')
{{ HTML::script('js/select/select2.full.js')}}
<script>
    $(document).ready(function() {
        $(".select2_single").select2({
            placeholder: "Select...",
            allowClear: true
        });
        $(".select2_group").select2({});
        $(".select2_multiple").select2({
            maximumSelectionLength: 4,
            placeholder: "With Max Selection limit 4",
            allowClear: true
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#sCustomer").on('change', function(){
        $.post('{{ URL::to('delivery/data1') }}', {type: 'dl', id: $("#sCustomer").val()}, function(e){
            $("#dl").html(e);
        });
        
        $('#sMaterial').html('');
        $('#sDesa').html('');
        
    });
    $('#sLotnumber').on('change', function(){
        $.post('{{ URL::to('delivery/data') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
            $('#sMaterial').html(e);
        });
        $('#sDesa').html('');
    });
    $('#sKecamatan').on('change', function(){
        $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
            $('#sDesa').html(e);
        });
    });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#sPo").on('change', function(){
        /*$.post('{{ URL::to('delivery/show') }}', {type: 'po', wh: $("#sWh").val(), pono: $("#pono").val()}, function(e){
            $("#inv").html(e);
        });*/
        $.post('{{ URL::to('delivery/show') }}', {type: 'cu', id: $("#sPo").val()}, function(e){
            $("#cu").html(e);
        });
        $.post('{{ URL::to('delivery/show') }}', {type: 'sip', id: $("#sPo").val()}, function(e){
            $("#sip").html(e);
        });
        /*$.post('{{ URL::to('delivery/show') }}', {type: 'stor', id: $("#sPo").val()}, function(e){
            $("#stor").html(e);
        });*/
        $('#sMaterial').html('');
        $('#sDesa').html('');
    });
    });
</script>
<script type="text/javascript">
  $(document).ready(function() {
        $("#sWh").on('change', function(){
        $.post('{{ URL::to('delivery/show') }}', {type: 'po', wh: $("#sWh").val(), pono: $("#pono").val()}, function(e){
            $("#inv").html(e);
        });
        $.post('{{ URL::to('delivery/show') }}', {type: 'dono', wh: $("#sWh").val()}, function(e){
            $("#dono").html(e);
        });
        });
    });
</script>
<script>
          $(document).ready(function () {
            var counter = 1;
            
            $("#addrow").on("click", function () {
              counter++;
              
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><input type="text" name="product' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="price' + counter + '"/></td>';
              cols += '<td><input type="text" name="qty' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="linetotal' + counter + '" readonly="readonly"/></td>';
              cols += '<td><a class="deleteRow"> x </a></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);
            });
            
            $("table.order-list").on("change", 'input[name^="price"], input[name^="qty"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
            
          function calculateRow(row) {
            var price = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty"]').val();
            var end_qty = +row.find('input[name^="end_qty"]').val();
            if (qty > end_qty ) {
              alert("Quantity Melebihi Stok");
              row.find('input[name^="qty"]').val("");
              row.find('input[name^="uom"]').val("");
            }
            else{
              row.find('input[name^="uom"]').val((price * qty));  
            }
            
            
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
@stop