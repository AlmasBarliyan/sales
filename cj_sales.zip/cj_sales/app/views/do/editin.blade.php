<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Sales</title>
  
  <!-- Bootstrap core CSS -->
  
  <style type="text/css" title="currentStyle">
    @import "../../css/css/layout-styles.css";
    @import "../../css/css/themes/smoothness/jquery-ui-1.8.4.custom.css";
  </style>
  {{ HTML::style('css/bootstrap.min.css')}}
  {{ HTML::style('fonts/css/font-awesome.min.css')}}
  {{ HTML::style('css/animate.min.css')}}
  
  <!-- Custom styling plus plugins -->
  {{HTML::style('css/custom.css')}}
  {{HTML::style('css/icheck/flat/green.css')}}
  
  {{HTML::style('js/datatables/jquery.dataTables.min.css')}}
  {{HTML::style('js/datatables/buttons.bootstrap.min.css')}}
  {{HTML::style('js/datatables/fixedHeader.bootstrap.min.css')}}
  {{HTML::style('js/datatables/responsive.bootstrap.min.css')}}
  {{HTML::style('js/datatables/scroller.bootstrap.min.css')}}
  <!-- select2 -->
  {{ HTML::style('css/select/select2.min.css')}}
  
  <!-- jQuery libs -->
  <!-- {{HTML::script('js/jquery.min.js')}} -->
  {{ HTML::script('js/jquery.js')}}
  {{ HTML::script('js/js/jquery-ui.min.js')}}
  {{ HTML::script('js/js/jq-ac-script2.js')}}
    

  <!--
  <script src="https://ajax.aspnetcdn.com/ajax/jquery.ui/1.9.2/jquery-ui.min.js"></script> -->
  <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
        <![endif]-->

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>


<body class="nav-md">

  <div class="container body">


    <div class="main_container">

      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">

          @include('../layouts/sidebar')
        </div>
      </div>

      <!-- top navigation -->
      <div class="top_nav">

        @include('../layouts/nav')

      </div>
      <!-- /top navigation -->

      <!-- page content -->
      <div class="right_col" role="main">
        
          <div class="">
          <div class="x_panel">
            <div class="x_title">
            @foreach($do as $in)
              <h2><a href="{{URL::to('/delivery-order')}}"><button class="btn btn-round btn-info" type="button"><i class="fa fa-arrow-circle-left"></i> Back</button></a> Edit ID Transaction {{$in->no_transaksi}} </h2>
              <ul class="nav navbar-right panel_toolbox">
                
              </ul>
              <div class="clearfix"></div>
            </div>
          <div class="clearfix"></div>

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_content">			
                  <form class="form-horizontal form-label-left input_mask" action="{{URL::to('/create-delivery-order')}}" method="post">
                  <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">                    
                    <tbody>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">DO No.</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <p id="dono"><input name="no_transaksi" value="{{$in->no_transaksi}}" type="text" style="width: 250px;" readonly="" class="form-control" /></p>
                              </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">PO NO. </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                  
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">Date Out</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <input type="text" style="z-index: 100000;width: 250px;" value="{{date('d-m-Y', strtotime($in->date_out ))}}" name="date_out" id="idTourDateDetails1" class="form-control has-feedback-left""> 
                                <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                <span id="inputSuccess2Status" class="sr-only">(success)</span>
                              </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Customer </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                  
                                  <p id="cu"><input  type="text" class="form-control" ></p>
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Trucking </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                  <p ><input required="" type="text" style="width: 250px;" class="form-control" name="trucking"></p>
                                </div>
                            </div>
                            <!-- <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">No. Surat Jalan</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <?php 
                                /*$no_in = DB::select(DB::raw("select max(substr(no_srtjln,-5,5)) as max from ss_outmaster where(select max(substr(no_srtjln,-5,5)) from ss_outmaster )"));*/
                                $no_in = DB::select(DB::raw("select max(substr(no_srtjln,-5,5)) as max from ss_outmaster where(select max(substr(no_srtjln,-5,5)) from ss_outmaster where substr(no_srtjln,1,8)= DATE_FORMAT(NOW(),'%Y%m%d') )"));
                                ?>
                                @foreach($no_in as $noin)
                                <input style="width: 250px;" type="text" readonly="" class="form-control" value="{{date('Ymd'). sprintf('%05d', $noin->max+1)}}" name="no_srtjln">
                                @endforeach  
                              </div>
                            </div> -->
                          </td>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Destination</label>
                              <div class="col-md-9 col-sm-9 col-xs-12">
                                <p id="sip"><input  type="text" class="form-control" ></p>
                                <!-- {{ Form::select('ship_to_party', array(), null, array('id' => 'dl', 'class'=>'select2_single form-control'))  }} -->
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Remarks</label>
                          <div class="col-md-9 col-sm-9 col-xs-12">
                            <input type="text" style="width:250px"  class="form-control" name="remarks">
                          </div>
                        </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Warehouse </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                
                                  <!-- <p id="stor"><input  type="text" class="form-control" ></p> -->
                                </div>
                            </div>
                          </td>
                        </tr>
                         
                        

                    </tbody>
                  </table>
                    <div>
                      <table id="inv" class='table table-striped responsive-utilities jambo_table bulk_action order-list' cellspacing="0" width="100%">
                      <!-- <table class='table table-striped responsive-utilities jambo_table bulk_action order-list ' id="sProducts"> -->
                          <thead>
                            <tr class='headings'>
                              <th class='column-title' colspan='2' style='text-align:center'>Material </th>
                              <th class='column-title' style='text-align:center'>Lot Number</th>
                              <th class='column-title' style='text-align:center' colspan='2'>Qty</th>
                              <th class='column-title' style='text-align:center' colspan='2'>Qty DO</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr class='even pointer'>
                              <td>
                                <a class="deleteRow" title="Hapus Item"><i class="fa fa-trash"></i></a>
                                <input type="text" id="sku" name="material_code[]" style="width:80px">
                                <input type="button" name="choice" onClick="selectValue('sku','pir','lot','qty_um','um','qty_uom','uom','out_um','out_uom','size','qty_out_um','qty_out_uom')" value="..." title="Cari Item" style="width:20px">
                              </td>
                              <td>
                                <input type="text" name="material_name[]" id="pir" />
                              </td>
                              <td>
                                <input type="text" name="lot_number[]" id="lot" style="width:100px"/>
                              </td>
                              <td>
                                <input style="width:80px" type="text" id="qty_um" name="qty_um[]" readonly="readonly" />
                                <input type="hidden" name="size[]" id="size" class="tInput" />
                                <input style="width:40px" id="um" class="tInput" readonly="readonly"/>
                              </td>
                              <td>
                                <input style="width:80px" type="text" id="qty_uom" name="qty_uom[]" readonly="readonly" />
                                <input style="width:30px" id="uom" class="tInput" readonly="readonly"/>
                              </td>
                              <td>
                                <input style="width:80px" type="text" id="qty_out_um" name="qty_out_um[]" />
                                <input style="width:40px" id="out_um" class="tInput" readonly="readonly"/>
                              </td>
                              <td>
                                <input style="width:80px" type="text" id="qty_out_uom" name="qty_out_uom[]" />
                                <input style="width:30px" id="out_uom" class="tInput" readonly="readonly"/>
                              </td>
                            </tr>  
                          </tbody>
                      </table>
                    </div>                    
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12" style="text-align:left">
                        <a href="#" id="addrow" class="btn btn-primary"><span> + Add Row</span></a>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
                        <button type="submit" class="btn btn-success">Save</button>
                      </div>
                    </div>

                  </form>
			  	
              	@endforeach
             	</div>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
      </div>

        <div id="custom_notifications" class="custom-notifications dsp_none">
          <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
          </ul>
          <div class="clearfix"></div>
          <div id="notif-group" class="tabbed_notifications"></div>
        </div>
        {{HTML::script('js/bootstrap/bootstrap.2.3.1.min.js')}}
        
        <!-- bootstrap progress js -->
        {{ HTML::script('js/progressbar/bootstrap-progressbar.min.js')}}
        <!-- icheck -->
        {{ HTML::script('js/icheck/icheck.min.js')}}

        {{ HTML::script('js/custom.js')}}

        <script type="text/javascript">
          $('#idTourDateDetails1').datepicker({
               dateFormat: 'dd-mm-yy',
               changeMonth: true,
               changeYear: true,
               altField: "#idTourDateDetailsHidden",
               altFormat: "yy-mm-dd"
           });
        </script>
        <!-- form validation -->
        {{ HTML::script('js/validator/validator.js')}}
        
        <script>
          // initialize the validator function
          validator.message['date'] = 'not a real date';

          // validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
          $('form')
            .on('blur', 'input[required], input.optional, select.required', validator.checkField)
            .on('change', 'select.required', validator.checkField)
            .on('keypress', 'input[required][pattern]', validator.keypress);

          $('.multi.required')
            .on('keyup blur', 'input', function() {
              validator.checkField.apply($(this).siblings().last()[0]);
            });

          // bind the validation to the form submit event
          //$('#send').click('submit');//.prop('disabled', true);

          $('form').submit(function(e) {
            e.preventDefault();
            var submit = true;
            // evaluate the form using generic validaing
            if (!validator.checkAll($(this))) {
              submit = false;
            }

            if (submit)
              this.submit();
            return false;
          });

          /* FOR DEMO ONLY */
          $('#vfields').change(function() {
            $('form').toggleClass('mode2');
          }).prop('checked', false);

          $('#alerts').change(function() {
            validator.defaults.alerts = (this.checked) ? false : true;
            if (this.checked)
              $('form .alert').remove();
          }).prop('checked', false);
        </script>

        @yield('script')

        <!-- Datatables -->
        <!-- <script src="js/datatables/js/jquery.dataTables.js"></script>
  <script src="js/datatables/tools/js/dataTables.tableTools.js"></script> -->

        <!-- Datatables-->
        {{HTML::script('js/datatables/jquery.dataTables.min.js')}}
        {{HTML::script('js/datatables/dataTables.bootstrap.js')}}
        {{HTML::script('js/datatables/dataTables.buttons.min.js')}}
        {{HTML::script('js/datatables/buttons.bootstrap.min.js')}}
        {{HTML::script('js/datatables/jszip.min.js')}}
        {{HTML::script('js/datatables/pdfmake.min.js')}}
        {{HTML::script('js/datatables/vfs_fonts.js')}}
        {{HTML::script('js/datatables/buttons.html5.min.js')}}
        {{HTML::script('js/datatables/buttons.print.min.js')}}
        {{HTML::script('js/datatables/dataTables.fixedHeader.min.js')}}
        
        {{HTML::script('js/datatables/dataTables.responsive.min.js')}}
        {{HTML::script('js/datatables/responsive.bootstrap.min.js')}}
        {{HTML::script('js/datatables/dataTables.scroller.min.js')}}
        {{HTML::script('js/pace/pace.min.js')}}
        <script type="text/javascript">
            $(document).ready(function() {
                $("#currency_code").on('change', function(){
                $.post('{{ URL::to('purchase-o/data1') }}', {type: 'currency_rate', id: $("#currency_code").val()}, function(e){
                    $("#currency_rate").html(e);
                });
                
                $('#sMaterial').html('');
                $('#sDesa').html('');
              });
            });
        </script>
        <script>
          $(document).ready(function () {
            var counter = 1;
            
            $("#addrow").on("click", function () {
              counter++;
              
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><input type="text" name="product' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="price' + counter + '"/></td>';
              cols += '<td><input type="text" name="qty' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="linetotal' + counter + '" readonly="readonly"/></td>';
              cols += '<td><a class="deleteRow"> x </a></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);
            });
            
            $("table.order-list").on("change", 'input[name^="price"], input[name^="qty"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
            
          function calculateRow(row) {
            var price = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty"]').val();
            
            row.find('input[name^="uom"]').val((price * qty));            
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
        <!-- <script>
          $(document).ready(function () {
            var counter = 1;
            
            $("#addrow").on("click", function () {
              counter++;
              
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><input type="text" name="product' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="price' + counter + '"/></td>';
              cols += '<td><input type="text" name="qty' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="linetotal' + counter + '" readonly="readonly"/></td>';
              cols += '<td><a class="deleteRow"> x </a></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);
            });
            
            $("table.order-list").on("change", 'input[name^="qty"],input[name^="size"],input[name^="uom"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
            
          function calculateRow(row) {
            var size = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty"]').val();
            
            
            row.find('input[name^="uom_qty"]').val((size * qty));
            
            /*row.find('input[name^="include"]').val(parseInt(row.find('input[name^="exclude_idr"]').val() * 1.1));
            row.find('input[name^="price_usd"]').val((price / <?php echo Session::get('cur_cod'); ?> ).toFixed(3));
            row.find('input[name^="exclude_usd"]').val((qty * row.find('input[name^="price_usd"]').val()));*/
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script> -->
        <script>
          var handleDataTableButtons = function() {
              "use strict";
              0 !== $("#datatable-buttons").length && $("#datatable-buttons").DataTable({
                dom: "Bfrtip",
                buttons: [{
                  extend: "copy",
                  className: "btn-sm"
                }, {
                  extend: "csv",
                  className: "btn-sm"
                }, {
                  extend: "excel",
                  className: "btn-sm"
                }, {
                  extend: "pdf",
                  className: "btn-sm"
                }, {
                  extend: "print",
                  className: "btn-sm"
                }],
                responsive: !0
              })
            },
            TableManageButtons = function() {
              "use strict";
              return {
                init: function() {
                  handleDataTableButtons()
                }
              }
            }();
        </script>
        <script type="text/javascript">
          $(document).ready(function() {
            $('#datatable').dataTable();
            $('#datatable-keytable').DataTable({
              keys: true
            });
            $('#datatable-responsive').DataTable();
            $('#datatable-scroller').DataTable({
              ajax: "js/datatables/json/scroller-demo.json",
              deferRender: true,
              scrollY: 380,
              scrollCollapse: true,
              scroller: true
            });
            var table = $('#datatable-fixed-header').DataTable({
              fixedHeader: true
            });
          });
          TableManageButtons.init();
        </script>
</body>

</html>