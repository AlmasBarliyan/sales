@extends('products.table')
@section('content')
		<div class="">
          
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Return </h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a href="{{URL::to('/create/return')}}"><button type="button" class="btn btn-round btn-primary" >+ Return Product </button></a></li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <div class="col-xs-2">
                    <!-- required for floating -->
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs tabs-left">
                      <li ><a href="{{URL::to('return')}}">Products Bad</a>
                      </li>
                      <li class="active"><a href="{{URL::to('returned')}}">Products Returned</a></li>
                    </ul>
                  </div>
                  <div class="col-xs-10">
                    <!-- Tab panes -->
                    <div class="tab-content">
                      <div class="tab-pane" id="bad">
                        <p class="lead">Products Bad In Warehouse </p>
                        
                      </div>
                      <div class="tab-pane active" id="returned">
                        <p class="lead">Products Returned </p>
                        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                          <thead>
                            <tr>
                              <th>#</th>
                              <th>No. Transaksi</th>
                              <th>Date Out</th>
                              <th>Warehouse</th>
                              <th>Destination</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                          <?php 
                            $no = 1;
                          ?>
                          @foreach($returned as $rtn)
                          <?php
                            $gudang = DB::table('cd_code')->where('code','=',$rtn->source)->where('hcode','!=','*')->first();
                            $destination = DB::table('cd_code')->where('code','=',$rtn->destination)->where('hcode','!=','*')->first();
                          ?>
                            <tr>
                              <td>{{$no++}}</td>
                              <td>{{$rtn->no_transaksi}}</td>
                              <td>{{date("d-m-Y",strtotime($rtn->date_out))}}</td>
                              <td>{{$gudang->code_name}}</td>
                              <td>{{$destination->code_name}}</td>
                              <td>
                                <a href="{{URL::to('returned/edit/'.$rtn->no_transaksi)}}" class="btn btn-primary btn-xs" title="Edit"><i class="fa fa-edit"></i> </a>
                                <a href="{{URL::to('returned/delete/'.$rtn->no_transaksi)}}" class="btn btn-danger btn-xs" title="Delete"><i class="fa fa-trash-o"></i> </a>
                              </td>
                            </tr>
                          @endforeach
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
			</div>
		</div>
@stop
@section('script')
<script>
function myFunction() {
    var x = document.getElementById("return_kg").value * document.getElementById("return_bag").value;
    document.getElementById("result_return").value = x;
    var y = document.getElementById("bad_kg").value * document.getElementById("bad_bag").value;
    document.getElementById("result_bad").value = y;
}
</script>
<script type="text/javascript">
            $(document).ready(function() {
                $('#sMaterialName').on('change', function(){
                $.post('{{ URL::to('site/return') }}', {type: 'lotnumber', id: $('#sMaterialName').val()}, function(e){
                    $('#sLotnumber').html(e);
                });
                
                $('#sMaterial').html('');
                $('#sDesa').html('');
                
            });
            $('#sLotnumber').on('change', function(){
                $.post('{{ URL::to('site/return') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
                    $('#sMaterial').html(e);
                });
                $('#sDesa').html('');
            });
            $('#sKecamatan').on('change', function(){
                $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
                    $('#sDesa').html(e);
                });
            });
            });
        </script>
@stop