<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Sales</title>
  
  <!-- Bootstrap core CSS -->
  
  <style type="text/css" title="currentStyle">
    @import "../../css/css/layout-styles.css";
    @import "../../css/css/themes/smoothness/jquery-ui-1.8.4.custom.css";
  </style>
  {{ HTML::style('css/bootstrap.min.css')}}
  {{ HTML::style('fonts/css/font-awesome.min.css')}}
  {{ HTML::style('css/animate.min.css')}}
  
  <!-- Custom styling plus plugins -->
  {{HTML::style('css/custom.css')}}
  {{HTML::style('css/icheck/flat/green.css')}}
  
  {{HTML::style('js/datatables/jquery.dataTables.min.css')}}
  {{HTML::style('js/datatables/buttons.bootstrap.min.css')}}
  {{HTML::style('js/datatables/fixedHeader.bootstrap.min.css')}}
  {{HTML::style('js/datatables/responsive.bootstrap.min.css')}}
  {{HTML::style('js/datatables/scroller.bootstrap.min.css')}}
  <!-- select2 -->
  {{ HTML::style('css/select/select2.min.css')}}
  
  <!-- jQuery libs -->
  <!-- {{HTML::script('js/jquery.min.js')}} -->
  {{ HTML::script('js/jquery.js')}}
  {{ HTML::script('js/js/jquery-ui.min.js')}}
  {{ HTML::script('js/js/jq-ac-script2.js')}}
    

  <!--
  <script src="https://ajax.aspnetcdn.com/ajax/jquery.ui/1.9.2/jquery-ui.min.js"></script> -->
  <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
        <![endif]-->

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>


<body class="nav-md">

  <div class="container body">


    <div class="main_container">

      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">

          @include('../layouts/sidebar')
        </div>
      </div>

      <!-- top navigation -->
      <div class="top_nav">

        @include('../layouts/nav')

      </div>
      <!-- /top navigation -->

      <!-- page content -->
      <div class="right_col" role="main">
        
          <div class="">
          <div class="x_panel">
            <div class="x_title">
            @foreach($inbound as $in)
              <h2><a href="{{URL::to('inbound')}}"><button class="btn btn-round btn-info" type="button"><i class="fa fa-arrow-circle-left"></i> Back</button></a> Edit ID Transaction {{$in->id_transaksi}} </h2>
              <ul class="nav navbar-right panel_toolbox">
                
              </ul>
              <div class="clearfix"></div>
            </div>
          <div class="clearfix"></div>

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_content">			
                
			  	<form id="itemsForm" class="form-horizontal form-label-left" action="{{URL::to('inbound-edit')}}" method="post" novalidate>
                <div id="messageBox" style="margin-left:15px; padding-left:20px; padding-bottom:5px; border:1px #ccc solid; display:none;"></div>
                <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">                    
                  <tbody>
                    <tr>
                      <td>
                        <div class="item form-group" >
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">No. STO <span class="required">*</span></label>
                            <?php 
                              $cn = 1;
                                $no_in = DB::select(DB::raw("select max(substr(id_transaksi,-5,5)) as max from tx_itemin where(select max(substr(id_transaksi,-5,5)) from tx_itemin where substr(id_transaksi,1,3)='STO')"));
                                
                            ?>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="hidden" name="id" value="{{$in->id_transaksi}}">
                            <input name="id_transaksi" required="required" value="{{$in->id_transaksi}}" type="text" class="form-control col-md-7 col-xs-12" />
                            </div>
                        </div>
                      </td>
                      <td>
                        <div class="form-group" >
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Storage</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                            <select name="stor[]" class="tInput" style="display:none">
                              @foreach($storage as $st)
                                <option value="{{$st->code}}" <?php if ($st->code==$in->storage) echo 'selected="selected"'; ?>>{{$st->code_name}}</option>
                              @endforeach
                            </select>

                            <select name="storage" class="form-control col-md-7 co-xs-12">
                            @foreach($storage as $st)
                            	<option value="{{$st->code}}" <?php if ($st->code==$in->storage) echo 'selected="selected"'; ?>>{{$st->code_name}}</option>
                            @endforeach
                            </select>
                            </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <div class="form-group" >
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Date In</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input type="text" style="z-index: 100000;width: 240px;" value="{{date('d-m-Y', strtotime($in->date_in))}}" name="date_in" id="idTourDateDetails1" class="form-control has-feedback-left""> 
                              <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                              <span id="inputSuccess2Status" class="sr-only">(success)</span>
                            </div>
                        </div>
                      </td>
                      <td>
                        <div class="form-group" >
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Surat Jalan</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                            <input name="no_suratjln" type="text" value="{{$in->no_suratjln}}" class="form-control col-md-7 col-xs-12"  />    
                            </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Remarks</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                            <input name="remarks" type="text"  class="form-control col-md-7 col-xs-12" value="{{$in->remarks}}" />    
                            </div>
                        </div>
                      </td>
                      <td>
                        
                      </td>
                    </tr>
                  </tbody>
                </table>
                <table id="itemsTable" class="table table-bordered dt-responsive nowrap order-list ">
                  <thead>
                  <tr>
                      <th style="text-align:center">Item</th>
                      <th style="text-align:center">Product Description</th>
                      <th style="text-align:center">Lot Number</th>
                      <th style="text-align:center" colspan="2">Qty In</th>
                      <th style="text-align:center">Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  	<?php $indetail = DB::table('tx_itemindetail')->leftJoin('cd_material','tx_itemindetail.material_code','=','cd_material.material_code')->where('id_transaksi','=',$in->id_transaksi)->get(); ?>
                  	@foreach($indetail as $indtl)
                      <tr class="item-row">
                          <td>
                            <a href="{{URL::route('del',[$in->id_transaksi,$indtl->material_code,$indtl->lot_number,$indtl->status,$in->storage,$indtl->qty_um,$indtl->qty_uom])}}" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fa fa-trash"></i></a>
                          	<input type="hidden" name="matcod[]" value="{{$indtl->material_code}}">
                         		<input style="width:50px" name="material_code[]" value="{{$indtl->material_code}}" class="itemCode" id="itemCode" />
                          </td>
                          <td><input name="material_name[]" value="{{$indtl->material_name}}" class="tInput" id="itemDesc"  readonly="readonly" /></td>
                          <td style="width:190px">
                          	<input type="hidden" name="no_lot[]" value="{{$indtl->lot_number}}">
                            <input style="width:50px" name="nicklot[]" value="{{substr($indtl->lot_number,0,4)}}" class="tInput" id="nicklot" readonly="readonly" />
                            <input style="width:100px" type="text" value="{{substr($indtl->lot_number,-6,6)}}" placeholder="161230" class="tInput" name="nolot[]" id="nolot">
                          </td>
                          <td>
                            <input style="width:80px" name="qty[]" class="tInput" id="itemQty" required="required"  value="{{$indtl->qty_um}}" />
                            <input style="width:80px" name="kuantity_um[]" class="tInput" id="itemQty" type="hidden" required="required"  value="{{$indtl->qty_um}}" />
                            <input type="hidden" name="size[]" value="{{$indtl->material_size}}" id="itemSize" class="tInput" />
                            <input style="width:40px" class="tInput" name="um[]" id="um" readonly="readonly" value="{{$indtl->um}}" />
                          </td>
                          <td>
                            <input style="width:80px" type="text" name="uom[]" value="{{$indtl->qty_uom}}" readonly="readonly" />
                            <input style="width:80px" type="hidden" name="kuantity_uom[]" value="{{$indtl->qty_uom}}" readonly="readonly" />
                            <input style="width:30px" id="uom" class="tInput" readonly="readonly" value="{{$indtl->uom}}" />
                          </td>
                          <td>
                          	<select name="stat[]" class="tInput" style="display:none">
	                            @if($indtl->status == 'G')
	                                <option value="G" selected="selected">Good</option>
	                                <option value="B">Bad</option>
	                            @elseif($indtl->status == 'B')
	                            	<option value="G">Good</option>
	                                <option value="B" selected="selected">Bad</option>
	                            @endif
                            </select>

                            <select name="status[]" class="tInput">
                            @if($indtl->status == 'G')
                                <option value="G" selected="selected">Good</option>
                                <option value="B">Bad</option>
                            @elseif($indtl->status == 'B')
                            	<option value="G">Good</option>
                                <option value="B" selected="selected">Bad</option>
                            @endif
                              </select>
                          </td>
                          <!-- <td><input style="width:140px" type="text" name="exclude_usd[]" readonly="readonly"  /></td> -->
                          <!-- <td style="width:100px"><input style="width:100px" name="include[]" value="" class="tInput" readonly="readonly" id=""></td> -->
                      </tr>
                    @endforeach
                  </tbody>
              	</table>
                <div class="ln_solid"></div>
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 col-xs-12" style="text-align:left">
                    <a href="#" id="addRow" class="btn btn-primary"><span> + Add Row</span></a>
                    
                  </div>
                </div>
              	<div class="modal-footer">
                	<button type="submit" class="btn btn-primary">Save</button>
              	</div>
              	</form>
              	@endforeach
             	</div>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
      </div>

        <div id="custom_notifications" class="custom-notifications dsp_none">
          <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
          </ul>
          <div class="clearfix"></div>
          <div id="notif-group" class="tabbed_notifications"></div>
        </div>
        {{HTML::script('js/bootstrap/bootstrap.2.3.1.min.js')}}
        
        <!-- bootstrap progress js -->
        {{ HTML::script('js/progressbar/bootstrap-progressbar.min.js')}}
        <!-- icheck -->
        {{ HTML::script('js/icheck/icheck.min.js')}}

        {{ HTML::script('js/custom.js')}}
        <script>
        function goBack() {
            window.history.back();
        }
        </script>
        <script type="text/javascript">
          $('#idTourDateDetails1').datepicker({
               dateFormat: 'dd-mm-yy',
               changeMonth: true,
               changeYear: true,
               altField: "#idTourDateDetailsHidden",
               altFormat: "yy-mm-dd"
           });
        </script>
        <!-- form validation -->
        {{ HTML::script('js/validator/validator.js')}}
        
        <script>
          // initialize the validator function
          validator.message['date'] = 'not a real date';

          // validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
          $('form')
            .on('blur', 'input[required], input.optional, select.required', validator.checkField)
            .on('change', 'select.required', validator.checkField)
            .on('keypress', 'input[required][pattern]', validator.keypress);

          $('.multi.required')
            .on('keyup blur', 'input', function() {
              validator.checkField.apply($(this).siblings().last()[0]);
            });

          // bind the validation to the form submit event
          //$('#send').click('submit');//.prop('disabled', true);

          $('form').submit(function(e) {
            e.preventDefault();
            var submit = true;
            // evaluate the form using generic validaing
            if (!validator.checkAll($(this))) {
              submit = false;
            }

            if (submit)
              this.submit();
            return false;
          });

          /* FOR DEMO ONLY */
          $('#vfields').change(function() {
            $('form').toggleClass('mode2');
          }).prop('checked', false);

          $('#alerts').change(function() {
            validator.defaults.alerts = (this.checked) ? false : true;
            if (this.checked)
              $('form .alert').remove();
          }).prop('checked', false);
        </script>

        @yield('script')

        <!-- Datatables -->
        <!-- <script src="js/datatables/js/jquery.dataTables.js"></script>
  <script src="js/datatables/tools/js/dataTables.tableTools.js"></script> -->

        <!-- Datatables-->
        {{HTML::script('js/datatables/jquery.dataTables.min.js')}}
        {{HTML::script('js/datatables/dataTables.bootstrap.js')}}
        {{HTML::script('js/datatables/dataTables.buttons.min.js')}}
        {{HTML::script('js/datatables/buttons.bootstrap.min.js')}}
        {{HTML::script('js/datatables/jszip.min.js')}}
        {{HTML::script('js/datatables/pdfmake.min.js')}}
        {{HTML::script('js/datatables/vfs_fonts.js')}}
        {{HTML::script('js/datatables/buttons.html5.min.js')}}
        {{HTML::script('js/datatables/buttons.print.min.js')}}
        {{HTML::script('js/datatables/dataTables.fixedHeader.min.js')}}
        
        {{HTML::script('js/datatables/dataTables.responsive.min.js')}}
        {{HTML::script('js/datatables/responsive.bootstrap.min.js')}}
        {{HTML::script('js/datatables/dataTables.scroller.min.js')}}
        {{HTML::script('js/pace/pace.min.js')}}
        <script type="text/javascript">
            $(document).ready(function() {
                $("#currency_code").on('change', function(){
                $.post('{{ URL::to('purchase-o/data1') }}', {type: 'currency_rate', id: $("#currency_code").val()}, function(e){
                    $("#currency_rate").html(e);
                });
                
                $('#sMaterial').html('');
                $('#sDesa').html('');
              });
            });
        </script>
        <script>
          $(document).ready(function () {
            var counter = 1;
            
            $("#addrow").on("click", function () {
              counter++;
              
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><input type="text" name="product' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="price' + counter + '"/></td>';
              cols += '<td><input type="text" name="qty' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="linetotal' + counter + '" readonly="readonly"/></td>';
              cols += '<td><a class="deleteRow"> x </a></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);
            });
            
            $("table.order-list").on("change", 'input[name^="price"], input[name^="qty"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
            
          function calculateRow(row) {
            var price = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty"]').val();
            
            row.find('input[name^="uom"]').val((price * qty));            
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
        <!-- <script>
          $(document).ready(function () {
            var counter = 1;
            
            $("#addrow").on("click", function () {
              counter++;
              
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><input type="text" name="product' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="price' + counter + '"/></td>';
              cols += '<td><input type="text" name="qty' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="linetotal' + counter + '" readonly="readonly"/></td>';
              cols += '<td><a class="deleteRow"> x </a></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);
            });
            
            $("table.order-list").on("change", 'input[name^="qty"],input[name^="size"],input[name^="uom"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
            
          function calculateRow(row) {
            var size = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty"]').val();
            
            
            row.find('input[name^="uom_qty"]').val((size * qty));
            
            /*row.find('input[name^="include"]').val(parseInt(row.find('input[name^="exclude_idr"]').val() * 1.1));
            row.find('input[name^="price_usd"]').val((price / <?php echo Session::get('cur_cod'); ?> ).toFixed(3));
            row.find('input[name^="exclude_usd"]').val((qty * row.find('input[name^="price_usd"]').val()));*/
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script> -->
        <script>
          var handleDataTableButtons = function() {
              "use strict";
              0 !== $("#datatable-buttons").length && $("#datatable-buttons").DataTable({
                dom: "Bfrtip",
                buttons: [{
                  extend: "copy",
                  className: "btn-sm"
                }, {
                  extend: "csv",
                  className: "btn-sm"
                }, {
                  extend: "excel",
                  className: "btn-sm"
                }, {
                  extend: "pdf",
                  className: "btn-sm"
                }, {
                  extend: "print",
                  className: "btn-sm"
                }],
                responsive: !0
              })
            },
            TableManageButtons = function() {
              "use strict";
              return {
                init: function() {
                  handleDataTableButtons()
                }
              }
            }();
        </script>
        <script type="text/javascript">
          $(document).ready(function() {
            $('#datatable').dataTable();
            $('#datatable-keytable').DataTable({
              keys: true
            });
            $('#datatable-responsive').DataTable();
            $('#datatable-scroller').DataTable({
              ajax: "js/datatables/json/scroller-demo.json",
              deferRender: true,
              scrollY: 380,
              scrollCollapse: true,
              scroller: true
            });
            var table = $('#datatable-fixed-header').DataTable({
              fixedHeader: true
            });
          });
          TableManageButtons.init();
        </script>
</body>

</html>