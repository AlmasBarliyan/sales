<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Sales</title>
  
  <!-- Bootstrap core CSS -->
  
  <style type="text/css" title="currentStyle">
    @import "../css/css/layout-styles.css";
    @import "../css/css/themes/smoothness/jquery-ui-1.8.4.custom.css";
  </style>
  {{ HTML::style('css/bootstrap.min.css')}}
  {{ HTML::style('fonts/css/font-awesome.min.css')}}
  {{ HTML::style('css/animate.min.css')}}
  
  <!-- Custom styling plus plugins -->
  {{HTML::style('css/custom.css')}}
  {{HTML::style('css/icheck/flat/green.css')}}
  
  {{HTML::style('js/datatables/jquery.dataTables.min.css')}}
  {{HTML::style('js/datatables/buttons.bootstrap.min.css')}}
  {{HTML::style('js/datatables/fixedHeader.bootstrap.min.css')}}
  {{HTML::style('js/datatables/responsive.bootstrap.min.css')}}
  {{HTML::style('js/datatables/scroller.bootstrap.min.css')}}
  <!-- select2 -->
  {{ HTML::style('css/select/select2.min.css')}}
  
  <!-- jQuery libs -->
  <!-- {{HTML::script('js/jquery.min.js')}} -->
  {{ HTML::script('js/jquery.js')}}
  {{ HTML::script('js/js/jquery-ui.min.js')}}
  {{ HTML::script('js/js/jq-ac-script3.js')}}
    

  <!--
  <script src="https://ajax.aspnetcdn.com/ajax/jquery.ui/1.9.2/jquery-ui.min.js"></script> -->
  <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
        <![endif]-->

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>


<body class="nav-md">

  <div class="container body">


    <div class="main_container">

      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">

          @include('../layouts/sidebar')
        </div>
      </div>

      <!-- top navigation -->
      <div class="top_nav">

        @include('../layouts/nav')

      </div>
      <!-- /top navigation -->

      <!-- page content -->
      <div class="right_col" role="main">
        
          <div class="">
          <div class="x_panel">
            <div class="x_title">
              <h2>Return Product</h2>
              <ul class="nav navbar-right panel_toolbox">
                
              </ul>
              <div class="clearfix"></div>
            </div>
          <div class="clearfix"></div>

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_content">
                  <div class="">          
      <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Return Product </h2>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">

                  <form class="form-horizontal form-label-left input_mask" action="{{URL::to('/return-create')}}" method="post">
                  <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">                    
                    <tbody>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">No. Return</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                               <p id="dono"><input name="no_transaksi" type="text" style="width: 250px;" readonly="" class="form-control" /></p>
                                                          </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Warehouse </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                  <select name="source" class="select2_single form-control" id="sStorage">
                                    <option disabled selected value>-- Select Warehouse --</option>
                                    @foreach($warehouse as $storage)
                                      <option value="{{$storage->code}}">{{$storage->code_name}}</option>
                                    @endforeach
                                  </select>
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">Date Out</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <input name="date_out" type="date" style="width: 250px;" value="<?php echo date('Y-m-d')?>" class="form-control" />
                                                          </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Destination </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                  <select name="destination" class="select2_single form-control" id="sDestination">
                                    <option></option>
                                    @foreach($pabrik as $pb)
                                      <option value="{{$pb->code}}">{{$pb->code_name}}</option>
                                    @endforeach
                                  </select>
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">No. Surat Jalan</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <?php 
                                /*$no_in = DB::select(DB::raw("select max(substr(no_srtjln,-5,5)) as max from ss_outmaster where(select max(substr(no_srtjln,-5,5)) from ss_outmaster )"));*/
                                $no_in = DB::select(DB::raw("select max(substr(no_srtjln,-5,5)) as max from ss_outmaster where(select max(substr(no_srtjln,-5,5)) from ss_outmaster where substr(no_srtjln,1,8)= DATE_FORMAT(NOW(),'%Y%m%d') )"));
                                ?>
                                <!-- @foreach($no_in as $noin) -->
                                <!-- <input style="width: 250px;" type="text" readonly="" class="form-control" value="{{date('Ymd'). sprintf('%05d', $noin->max+1)}}" name="no_srtjln"> -->
                                <input style="width: 250px;" type="text" required="" class="form-control"  name="no_srtjln">
                                <!-- @endforeach   -->
                              </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Trucking </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                  <input type="text" class="form-control" required="" name="trucking">
                                </div>
                            </div>
                          </td>
                        </tr>
                         <tr>
                          <td>
                            <div class="item form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Remarks</label>
                          <div class="col-md-9 col-sm-9 col-xs-12">
                            <input type="text" style="width:250px"  class="form-control" name="remarks">
                          </div>
                        </div>
                          </td>
                          <td>
                            
                          </td>
                        </tr>
                        

                    </tbody>
                  </table>
                    <div>
                    <table id="itemsTable" class="table table-bordered dt-responsive nowrap order-list ">
                  <thead>
                  <tr>
                      <th style="text-align:center">Item</th>
                      <th style="text-align:center">Product Description</th>
                      <th style="text-align:center">Lot Number</th>
                      <th style="text-align:center" colspan="2">Qty In</th>
                      <th style="text-align:center">Status</th>
                  </tr>
                  </thead>
                  <tbody>
                      <tr class="item-row">
                          <td><a style="margin-right:12px"></a><input style="width:50px" name="material_code[]" value="" class="tInput" id="itemCode" />
                          <input size=10  type=number id=sku1 name='sku1[]' onchange="showUser(1, this.value)">
                                      <input type="button" name="choice" onClick="selectValue('sku1')" value="?">
                          </td>
                          <td><input name="material_name[]" value="" class="tInput" id="itemDesc"  readonly="readonly" /></td>
                          <td style="width:190px">
                            <input style="width:50px" name="nicklot[]" value="" class="tInput" id="nicklot" readonly="readonly" />
                            <input tabindex="1" style="width:100px" type="text" placeholder="161230" class="tInput" name="nolot[]" id="nolot">
                          </td>
                          <td>
                            <input style="width:80px" name="qty[]" class="tInput" id="itemQty" tabindex="2" required="required" />
                            <input type="hidden" name="size[]" id="itemSize" class="tInput" />
                            <input style="width:40px" class="tInput" id="um" readonly="readonly" />
                          </td>
                          <td>
                            <input style="width:80px" type="text" name="uom[]" readonly="readonly" />
                            <input style="width:30px" id="uom" class="tInput" readonly="readonly"/>
                          </td>
                          <td>
                            <select name="status[]" class="tInput" tabindex="3">
                                <option value="G">Good</option>
                                <option value="B">Bad</option>
                              </select>
                          </td>
                          <!-- <td><input style="width:140px" type="text" name="exclude_usd[]" readonly="readonly"  /></td> -->
                          <!-- <td style="width:100px"><input style="width:100px" name="include[]" value="" class="tInput" readonly="readonly" id=""></td> -->
                      </tr>
                  </tbody>
              </table>
                <div class="ln_solid"></div>
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 col-xs-12" style="text-align:left">
                    <a href="#" id="addRow" class="btn btn-primary"><span> + Add Row</span></a>
                    
                  </div>
                </div>
                      <table id="sProducts" class='table table-striped responsive-utilities jambo_table bulk_action order-list' cellspacing="0" width="100%">
                      <!-- <table class='table table-striped responsive-utilities jambo_table bulk_action order-list ' id="sProducts"> -->
                          <thead>
                            <tr class='headings'>
                              <th class='column-title' colspan='2'>Material </th>
                              <th class='column-title'>Lot Number</th>
                              <th class='column-title' >Qty BAD</th>
                              <th class='column-title' style='text-align:center' colspan='4'>Qty Return</th>
                            </tr>
                          </thead>
                          <tbody>
                              <tr class='even pointer'>
                                  <td class='col-md-5' colspan='3'>
                                      <input value=''  name='material_code[]' type='text' class='col-md-3' >
                                      <input style="width:50px" name="material_code[]" value="" class="itemCode" id="itemCode" >
                                      <input size=10  type=number id=sku1 name='sku1[]' onchange="showUser(1, this.value)">
                                      <input type="button" name="choice" onClick="selectValue('sku1')" value="?">
                                      <input value='' name='mater' type='text' class='col-md-6' >
                                  </td>
                                  <td class='col-md-1'><h1></h1></td>
                                  <td class='col-md-2' colspan='2'>
                                      <input name='end_qty[]' class='col-md-6' type='text' value=''>
                                      <input name='return_qty_bag' class='col-md-6' type='text' value=''>
                                  </td>
                                  <td class='col-md-5' colspan='4'>
                                      <input style='width:80px' name='qty[]' class='tInput' id='itemQty' tabindex='1' />
                                      <input type='hidden' name='size[]' value='' class='tInput' />
                                      <input style='width:40px' class='tInput' id='um' readonly='readonly' value='' />
                                      <input style='width:80px' type='text' name='uom[]' readonly='readonly' />
                                      <input style='width:30px' id='uom' class='tInput' readonly='readonly' value=''/>
                                  </td>
                              </tr>
                          </tbody>
                      </table>
                    </div>                    
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12" style="text-align:left">
                        <a href="#" id="addRow" class="btn btn-primary"><span> + Add Row</span></a>
                        
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
                        <button type="submit" class="btn btn-success">Save</button>
                      </div>
                    </div>

                  </form>

                </div>
                
              </div>
           </div>
        </div>
    </div>
    <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">

              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Modal title</h4>
              </div>
              <div class="modal-body">

              <form id="a">
                <table id="sLi" class='table table-striped responsive-utilities jambo_table bulk_action order-list' cellspacing="0" width="100%">
                <!-- <table class='table table-striped responsive-utilities jambo_table bulk_action order-list ' id="sProducts"> -->
                    <thead>
                      <tr class='headings'>
                        <th class='column-title' colspan='2'>Material </th>
                        <th class='column-title'>Lot Number</th>
                        <th class='column-title' >Qty BAD</th>
                      </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" id="btnSave" class="btn btn-primary">Save changes</button>
              </div>
            </div>
          </div>
        </div>
                </div>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
      </div>

        <div id="custom_notifications" class="custom-notifications dsp_none">
          <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
          </ul>
          <div class="clearfix"></div>
          <div id="notif-group" class="tabbed_notifications"></div>
        </div>
        {{HTML::script('js/bootstrap/bootstrap.2.3.1.min.js')}}
        
        <!-- bootstrap progress js -->
        {{ HTML::script('js/progressbar/bootstrap-progressbar.min.js')}}
        <!-- icheck -->
        {{ HTML::script('js/icheck/icheck.min.js')}}

        {{ HTML::script('js/custom.js')}}

        
        <!-- form validation -->
        {{ HTML::script('js/validator/validator.js')}}
        
        <script>
          // initialize the validator function
          validator.message['date'] = 'not a real date';

          // validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
          $('form')
            .on('blur', 'input[required], input.optional, select.required', validator.checkField)
            .on('change', 'select.required', validator.checkField)
            .on('keypress', 'input[required][pattern]', validator.keypress);

          $('.multi.required')
            .on('keyup blur', 'input', function() {
              validator.checkField.apply($(this).siblings().last()[0]);
            });

          // bind the validation to the form submit event
          //$('#send').click('submit');//.prop('disabled', true);

          $('form').submit(function(e) {
            e.preventDefault();
            var submit = true;
            // evaluate the form using generic validaing
            if (!validator.checkAll($(this))) {
              submit = false;
            }

            if (submit)
              this.submit();
            return false;
          });

          /* FOR DEMO ONLY */
          $('#vfields').change(function() {
            $('form').toggleClass('mode2');
          }).prop('checked', false);

          $('#alerts').change(function() {
            validator.defaults.alerts = (this.checked) ? false : true;
            if (this.checked)
              $('form .alert').remove();
          }).prop('checked', false);
        </script>

        @yield('script')

        <!-- Datatables -->
        <!-- <script src="js/datatables/js/jquery.dataTables.js"></script>
  <script src="js/datatables/tools/js/dataTables.tableTools.js"></script> -->

        <!-- Datatables-->
        {{HTML::script('js/datatables/jquery.dataTables.min.js')}}
        {{HTML::script('js/datatables/dataTables.bootstrap.js')}}
        {{HTML::script('js/datatables/dataTables.buttons.min.js')}}
        {{HTML::script('js/datatables/buttons.bootstrap.min.js')}}
        {{HTML::script('js/datatables/jszip.min.js')}}
        {{HTML::script('js/datatables/pdfmake.min.js')}}
        {{HTML::script('js/datatables/vfs_fonts.js')}}
        {{HTML::script('js/datatables/buttons.html5.min.js')}}
        {{HTML::script('js/datatables/buttons.print.min.js')}}
        {{HTML::script('js/datatables/dataTables.fixedHeader.min.js')}}
        
        {{HTML::script('js/datatables/dataTables.responsive.min.js')}}
        {{HTML::script('js/datatables/responsive.bootstrap.min.js')}}
        {{HTML::script('js/datatables/dataTables.scroller.min.js')}}
        {{HTML::script('js/pace/pace.min.js')}}
        <script type="text/javascript">
            $(document).ready(function() {
                $("#currency_code").on('change', function(){
                $.post('{{ URL::to('purchase-o/data1') }}', {type: 'currency_rate', id: $("#currency_code").val()}, function(e){
                    $("#currency_rate").html(e);
                });
                
                $('#sMaterial').html('');
                $('#sDesa').html('');
              });
            });
        </script>
        <script>
          $(document).ready(function () {
            var counter = 1;
            
            $("#addrow").on("click", function () {
              counter++;
              
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><input type="text" name="product' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="price' + counter + '"/></td>';
              cols += '<td><input type="text" name="qty' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="linetotal' + counter + '" readonly="readonly"/></td>';
              cols += '<td><a class="deleteRow"> x </a></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);
            });
            
            $("table.order-list").on("change", 'input[name^="price"], input[name^="qty"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
            
          function calculateRow(row) {
            var price = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty"]').val();
            
            row.find('input[name^="uom"]').val((price * qty));            
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
        
        <script>
          var handleDataTableButtons = function() {
              "use strict";
              0 !== $("#datatable-buttons").length && $("#datatable-buttons").DataTable({
                dom: "Bfrtip",
                buttons: [{
                  extend: "copy",
                  className: "btn-sm"
                }, {
                  extend: "csv",
                  className: "btn-sm"
                }, {
                  extend: "excel",
                  className: "btn-sm"
                }, {
                  extend: "pdf",
                  className: "btn-sm"
                }, {
                  extend: "print",
                  className: "btn-sm"
                }],
                responsive: !0
              })
            },
            TableManageButtons = function() {
              "use strict";
              return {
                init: function() {
                  handleDataTableButtons()
                }
              }
            }();
        </script>
        <script type="text/javascript">
          $(document).ready(function() {
            $('#datatable').dataTable();
            $('#datatable-keytable').DataTable({
              keys: true
            });
            $('#datatable-responsive').DataTable();
            $('#datatable-scroller').DataTable({
              ajax: "js/datatables/json/scroller-demo.json",
              deferRender: true,
              scrollY: 380,
              scrollCollapse: true,
              scroller: true
            });
            var table = $('#datatable-fixed-header').DataTable({
              fixedHeader: true
            });
          });
          TableManageButtons.init();
        </script>
<script type="text/javascript">  
  function showUser(userNumber, str)  
  {  
    if (str=="")  
    {  
      document.getElementById("txtHint" + userNumber).innerHTML="";  
      return;  
    }    
    if (window.XMLHttpRequest)  
    {// code for IE7+, Firefox, Chrome, Opera, Safari  
      xmlhttp=new XMLHttpRequest();  
    }  

    xmlhttp.onreadystatechange=function()  
    {  
      if (xmlhttp.readyState==4 && xmlhttp.status==200)  
      {  
        //document.getElementById("txtHint" + userNumber).innerHTML=xmlhttp.responseText; 
        var responseText = xmlhttp.responseText; 
        var description = responseText; 
        var warehouse = ""; 
        var sellingUnits = ""; 
        if (responseText.indexOf("NOT A VALID") == -1) 
        { 
          description = responseText.substring(12, responseText.indexOf(",Warehouse:"));  
          warehouse = responseText.substring(responseText.indexOf(",Warehouse:")+11, responseText.indexOf(",SellingUnits:"));  
          sellingUnits = responseText.substring(responseText.indexOf(",SellingUnits:")+15);  
        } 

        document.getElementById("whse" + userNumber).innerHTML = warehouse;  
        document.getElementById("txtHint" + userNumber).innerHTML = description;  
        document.getElementById("su" + userNumber).innerHTML = sellingUnits; 

      }  
    }  
    xmlhttp.open("GET","getdata1.php?q="+str,true);  
    xmlhttp.send(); 
  } 
</script> 
<script type="text/javascript">  
function selectValue(id)
{
    // open popup window and pass field id
    window.open('../sku.php?id=' + encodeURIComponent(id),'popuppage',
      'width=400,toolbar=1,resizable=1,scrollbars=yes,height=400,top=100,left=100');
}

function updateValue(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;
}

</script>
<script type="text/javascript">  
$(function() {
  $('#btnLaunch').click(function() {
    $('#myModal').modal('show');
  });
  var formChildX = document.getElementById("sLi");
  for(i = 0 ; i < formChildX.length; i++){
  $('#btnSave').click(function() {
    var value = formChildX.elements[i].value;
    //var value = $('.sli').val();
    $('h1').html(value);
    $('.bs-example-modal-lg').modal('hide');
  });
  }
});
</script>
<script>
          $(document).ready(function () {
            var counter = 1;
            
            $("#addrow").on("click", function () {
              counter++;
              
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><input type="text" name="product' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="price' + counter + '"/></td>';
              cols += '<td><input type="text" name="qty' + counter + '"/></td>';
              cols += '<td>$<input type="text" name="linetotal' + counter + '" readonly="readonly"/></td>';
              cols += '<td><a class="deleteRow"> x </a></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);
            });
            
            $("table.order-list").on("change", 'input[name^="price"], input[name^="qty"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
            
          function calculateRow(row) {
            var price = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty"]').val();
            var end_qty = +row.find('input[name^="end_qty"]').val();
            if (qty > end_qty ) {
              alert("Quantity Melebihi Stok BAD");
              row.find('input[name^="qty"]').val("");
              row.find('input[name^="uom"]').val("");
            }
            else{
              row.find('input[name^="uom"]').val((price * qty));  
            }
            
            
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#sStorage').on('change', function(){
        $.post('{{ URL::to('site/show') }}', {type: 'storage', id: $('#sStorage').val()}, function(e){
            $('#sProducts').html(e);

        });
        /*$.post('{{ URL::to('site/show') }}', {type: 'lis', id: $('#sStorage').val()}, function(e){
            $('#sLi').html(e);

        });*/
        });
        $('#sMaterial').html('');
        $('#sDesa').html('');
        
    
    $('#sLotnumber').on('change', function(){
        $.post('{{ URL::to('site/return') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
            $('#sMaterial').html(e);
        });
        $('#sDesa').html('');
    });
    $('#sKecamatan').on('change', function(){
        $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
            $('#sDesa').html(e);
        });
    });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#sDestination').on('change', function(){
        $.post('{{ URL::to('site/show') }}', {type: 'destination', id: $('#sDestination').val()}, function(e){
            $('#dono').html(e);
        });
        
        $('#sMaterial').html('');
        $('#sDesa').html('');
        
    });
   
    });
</script>
</body>

</html>