@foreach($searchInventory as $si)
    <p>{{$si->material_name}}</p>
@endforeach