<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Sales</title>
  
  <!-- Bootstrap core CSS -->
  {{ HTML::style('css/css/layout-styles.css')}}
  {{ HTML::style('css/css/themes/smoothness/jquery-ui-1.8.4.custom.css')}}
  
  {{ HTML::style('css/bootstrap.min.css')}}
  {{ HTML::style('fonts/css/font-awesome.min.css')}}
  {{ HTML::style('css/animate.min.css')}}
  
  <!-- Custom styling plus plugins -->
  {{HTML::style('css/custom.css')}}
  {{HTML::style('css/icheck/flat/green.css')}}
  
  {{HTML::style('js/datatables/jquery.dataTables.min.css')}}
  {{HTML::style('js/datatables/buttons.bootstrap.min.css')}}
  {{HTML::style('js/datatables/fixedHeader.bootstrap.min.css')}}
  {{HTML::style('js/datatables/responsive.bootstrap.min.css')}}
  {{HTML::style('js/datatables/scroller.bootstrap.min.css')}}
  <!-- select2 -->
  {{ HTML::style('css/select/select2.min.css')}}
  
  <!-- jQuery libs -->
  <!-- {{HTML::script('js/jquery.min.js')}} -->
  {{ HTML::script('js/jquery.js')}}
  {{ HTML::script('js/js/jquery-ui.min.js')}}

  <!--
  <script src="https://ajax.aspnetcdn.com/ajax/jquery.ui/1.9.2/jquery-ui.min.js"></script> -->
  <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
        <![endif]-->

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>


<body class="nav-md">

  <div class="container body">


    <div class="main_container">

      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">

          @include('../layouts/sidebar')
        </div>
      </div>

      <!-- top navigation -->
      <div class="top_nav">

        <div class="nav_menu">
          @include('../layouts/nav')
        </div>

      </div>
      <!-- /top navigation -->

      <!-- page content -->
      <div class="right_col" role="main">
        
          <div class="">
          <div class="x_panel">
            <div class="x_title">
              <h2>Report Inventory </h2>
              <ul class="nav navbar-right panel_toolbox">
                <li></li>
              </ul>
              <div class="clearfix"></div>
            </div>
          <div class="clearfix"></div>

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_content">
                <form action="{{URL::to('/report-inv')}}" method="POST">
                <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">
                  <tbody>
                    <tr>
                      <td>
                        <div class="form-group" >
                          <label class="control-label col-md-2 col-sm-2 col-xs-12" style="margin-top:10px">Date In</label>
                          <div class="col-md-5 col-sm-5 col-xs-12">
                            <input type="text" style="z-index: 100000;" value="{{date('d-m-Y',strtotime(Session::get('startTime')))}}" name="date_start" id="idTourDateDetails1" class="form-control has-feedback-left""> 
                            <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                            <span id="inputSuccess2Status" class="sr-only">(success)</span>
                          </div>
                          <div class="col-md-5 col-sm-5 col-xs-12">
                            <input type="text" style="z-index: 100000;" value="{{date('d-m-Y',strtotime(Session::get('endTime')))}}" name="date_finish" id="idTourDateDetails2" class="form-control has-feedback-left""> 
                            <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                            <span id="inputSuccess2Status" class="sr-only">(success)</span>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div class="form-group" >
                          <label class="control-label col-md-2 col-sm-2 col-xs-12" style="margin-top:10px">Kategori</label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <select name="kategori" class="form-control">
                              <option disabled selected value>Pilih</option>
                              @if(Session::get('ktg') == 'B2B02')
                              <option value="B2B02" selected="selected">B2B FOOD</option>
                              <option value="B2B01">B2B FEED</option>
                              <option value="B2C01">B2C Masita</option>
                              @elseif(Session::get('ktg') == 'B2B01')
                              <option value="B2B02">B2B FOOD</option>
                              <option value="B2B01" selected="selected">B2B FEED</option>
                              <option value="B2C01">B2C Masita</option>
                              @elseif(Session::get('ktg') == 'B2C01')
                              <option value="B2B02">B2B FOOD</option>
                              <option value="B2B01">B2B FEED</option>
                              <option value="B2C01" selected="selected">B2C Masita</option>
                              @else
                              <option value="B2B02">B2B FOOD</option>
                              <option value="B2B01">B2B FEED</option>
                              <option value="B2C01">B2C Masita</option>
                              @endif
                            </select>
                          </div>
                          <div class="col-md-1 col-sm-1 col-xs-12">
                            <button type="submit" title="Search" class="btn btn-primary btn-xs" style="margin-top:5px"><i class="fa fa-search"></i></button>
                          </div>
                          <div class="col-md-1 col-sm-1 col-xs-12">
                            <a href="{{URL::to('export-transaksi-ex')}}" title="Export To Excel" style="margin-top:5px" class="btn btn-success btn-xs"><i class="fa fa-file-excel-o"></i></a>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
                </form>
                <div class="" role="tabpanel" data-example-id="togglable-tabs">
                  <div id="myTabContent2" class="tab-content">
                    <div role="tabpanel" class="tab-pane fade active in" id="tab_content11" aria-labelledby="home-tab">
                      <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0">
                        <thead>
                          <tr>
                            <th style="text-align:center">No</th>
                            <th style="text-align:center">Code</th>
                            <th style="text-align:center">Material</th>
                            <th style="text-align:center">Lot Number</th>
                            <th style="text-align:center">Company</th>
                            <th style="text-align:center">Plant</th>
                            <th style="text-align:center">Qty</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php 
                          $no = 1;
                          $jum = 1;
                         ?>
                          @foreach($transaksi as $tx)
                            <tr>
                            @if($jum <= 1)
                              <td rowspan="{{$tx->jumlah}}">{{$no}}</td>
                              <td rowspan="{{$tx->jumlah}}">{{$tx->material_code}}</td>
                              <?php $jum = $tx->jumlah;
                              $no++;
                              ?>
                            @else
                              <?php $jum = $jum - 1; ?>
                            @endif
                              <td>{{$tx->material_name}}</td>
                              <td>{{$tx->lot_number}}</td>
                              <td>{{$tx->company}}</td>
                              <td>{{$tx->plant}}</td>
                              <td>{{$tx->qty_um}}</td>
                            </tr>
                          @endforeach  
                        </tbody>
                      </table>                       
                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
      <!-- /page content -->
          </div>

        </div>

        <div id="custom_notifications" class="custom-notifications dsp_none">
          <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
          </ul>
          <div class="clearfix"></div>
          <div id="notif-group" class="tabbed_notifications"></div>
        </div>
        {{HTML::script('js/bootstrap/bootstrap.2.3.1.min.js')}}
        
        <!-- bootstrap progress js -->
        {{ HTML::script('js/progressbar/bootstrap-progressbar.min.js')}}
        <!-- icheck -->
        {{ HTML::script('js/icheck/icheck.min.js')}}

        {{ HTML::script('js/custom.js')}}
        <script type="text/javascript">
          $('#idTourDateDetails1').datepicker({
               dateFormat: 'dd-mm-yy',
               changeMonth: true,
               changeYear: true,
               altField: "#idTourDateDetailsHidden",
               altFormat: "yy-mm-dd"
           });
          $('#idTourDateDetails2').datepicker({
               dateFormat: 'dd-mm-yy',
               changeMonth: true,
               changeYear: true,
               altField: "#idTourDateDetailsHidden",
               altFormat: "yy-mm-dd"
           });
        </script>
        <!-- form validation -->
        {{ HTML::script('js/validator/validator.js')}}
        
        <!-- Datatables -->
        <!-- <script src="js/datatables/js/jquery.dataTables.js"></script>
  <script src="js/datatables/tools/js/dataTables.tableTools.js"></script> -->

        <!-- Datatables-->
        {{HTML::script('js/datatables/jquery.dataTables.min.js')}}
        {{HTML::script('js/datatables/dataTables.bootstrap.js')}}
        {{HTML::script('js/datatables/dataTables.buttons.min.js')}}
        {{HTML::script('js/datatables/buttons.bootstrap.min.js')}}
        {{HTML::script('js/datatables/jszip.min.js')}}
        {{HTML::script('js/datatables/pdfmake.min.js')}}
        {{HTML::script('js/datatables/vfs_fonts.js')}}
        {{HTML::script('js/datatables/buttons.html5.min.js')}}
        {{HTML::script('js/datatables/buttons.print.min.js')}}
        {{HTML::script('js/datatables/dataTables.fixedHeader.min.js')}}
        {{HTML::script('js/datatables/dataTables.keyTable.min.js')}}
        {{HTML::script('js/datatables/dataTables.responsive.min.js')}}
        {{HTML::script('js/datatables/responsive.bootstrap.min.js')}}
        {{HTML::script('js/datatables/dataTables.scroller.min.js')}}
        {{HTML::script('js/pace/pace.min.js')}}
        <script>
          var handleDataTableButtons = function() {
              "use strict";
              0 !== $("#datatable-buttons").length && $("#datatable-buttons").DataTable({
                dom: "Bfrtip",
                buttons: [{
                  extend: "copy",
                  className: "btn-sm"
                }, {
                  extend: "csv",
                  className: "btn-sm"
                }, {
                  extend: "excel",
                  className: "btn-sm"
                }, {
                  extend: "pdf",
                  className: "btn-sm"
                }, {
                  extend: "print",
                  className: "btn-sm"
                }],
                responsive: !0
              })
            },
            TableManageButtons = function() {
              "use strict";
              return {
                init: function() {
                  handleDataTableButtons()
                }
              }
            }();
        </script>
        <script type="text/javascript">
          $(document).ready(function() {
            $('#datatable').dataTable();
            $('#datatable-keytable').DataTable({
              keys: true
            });
            $('#datatable-responsive').DataTable();
            $('#datatable-scroller').DataTable({
              ajax: "js/datatables/json/scroller-demo.json",
              deferRender: true,
              scrollY: 380,
              scrollCollapse: true,
              scroller: true
            });
            var table = $('#datatable-fixed-header').DataTable({
              fixedHeader: true
            });
          });
          TableManageButtons.init();
        </script>
</body>

</html>