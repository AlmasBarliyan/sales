Dear all, <br>
<br>
{{ $msg}}
<br>
<br>
<br>
<table border="1">
  <thead>
    <tr class='headings' style="background: #daaf15;">
      <th class='column-title' style='text-align:center'>DO No.</th>
      <th class='column-title' style='text-align:center'>Customer</th>
      <th class='column-title' style='text-align:center'>Destination</th>
      <th class='column-title' style='text-align:center'>Trucking</th>
      <th class='column-title' style='text-align:center'>Qty (Kg)</th>
      <th class='column-title' style='text-align:center'>Product</th>
      <th class='column-title' style='text-align:center'>Lot Number</th>
      <th class='column-title' style='text-align:center'>PO. No</th>
      <th class='column-title' style='text-align:center'>PO. Date</th>
      <th class='column-title' style='text-align:center'>Remarks</th>
    </tr>
  </thead>
  <tbody style="background:#d4c59c">
  <?php
    /*$customers = DB::table('ss_customers')->where('customer_code','=',$customer_code)->first();
    $customer_detail = DB::table('ss_customerdtl')->where('ship_to_party','=',$destination)->first();
    $cd_material = DB::table('cd_material')->where('material_code','=',$material_code)->first();
    $po = DB::table('ss_pomaster')->where('po_no','=',$po_no)->first();*/
    $dodetail = DB::select(DB::raw("select * from ss_outdtl od where no_transaksi='{$do_no}'"));
    $sum = 0;
    foreach($dodetail as $dtl)
    {
       $sum+= $dtl->qty_out_uom;
    }
  ?>
    <tr class='even pointer'>
      <td style='text-align:center'>
        {{ $do_no}}
      </td>
      <td style='text-align:center;width:200px'>
        {{ $customer_name}}
      </td>
      <td style='text-align:center;width:200px'>
        {{ $destination}}
      </td>
      <td style='text-align:center'>
        {{ $trucking}}
      </td>
      <td style='text-align:center'>
         {{$sum}}
      </td>
      <td style='text-align:center;width:150px'>
      	{{ $material_name}} ({{ $material_code}})
      </td>
      <td style='text-align:center;width:200px'>
      	@foreach($dodetail as $dtl)
            {{$dtl->lot_number}} ({{$dtl->qty_out_um}} BAG)  <br>
        @endforeach
      </td>
      <td style='text-align:center'>
      	{{ $po_no}}
      </td>
      <td style='text-align:center;width:80px'>
      	{{ date("d-M",strtotime($po_date))}}
      </td>
      <td style='text-align:center'>
      	{{ $remarks}}
      </td>
    </tr>  
  </tbody>
</table>