Dear all, <br>
<br>
{{ $msg}}
<br>
<br>
<br>
<table border="1">
  <thead>
    <tr class='headings' style="background: #daaf15;">
      <th style='text-align:center;width:200px'><h6 style="font-family: 'Arial Unicode MS'">DO No</h6></th>
      <th style='text-align:center;width:200px'><h6 style="font-family: 'Arial Unicode MS'">Customer</h6></th>
      <th style='text-align:center;width:200px'><h6 style="font-family: 'Arial Unicode MS'">Destination</h6></th>
      <th style='text-align:center;width:200px'><h6 style="font-family: 'Arial Unicode MS'">Trucking</h6></th>
      <th style='text-align:center;width:200px'><h6 style="font-family: 'Arial Unicode MS'">Product </h6></th>
      <th style='text-align:center;width:200px'><h6 style="font-family: 'Arial Unicode MS'">PO No.</h6></th>
      <th style='text-align:center;width:200px'><h6 style="font-family: 'Arial Unicode MS'">PO Date</h6></th>
      <th style='text-align:center;width:200px'><h6 style="font-family: 'Arial Unicode MS'">Qty (Kg) </h6></th>
      <th style='text-align:center;width:200px'><h6 style="font-family: 'Arial Unicode MS'">Lot Number</h6></th>
      <th style='text-align:center;width:200px'><h6 style="font-family: 'Arial Unicode MS'">Remarks</h6></th>
    </tr>
  </thead>
  <tbody>
                        <?php
                          $no = 1;
                          $jum = 1;
              $detail = DB::table('ss_outmaster as om')
                ->select(DB::raw("*, (select count(material_code) from ss_outdtl where no_transaksi = od.no_transaksi) as jumlah"))
                ->leftJoin('ss_outdtl as od','om.no_transaksi','=','od.no_transaksi')
                ->leftJoin('cd_material as mt','mt.material_code','=','od.material_code')
                ->leftJoin('ss_customers as cm','cm.customer_code','=','om.customer_code')
                ->leftJoin('ss_customerdtl as cd','cd.ship_to_party','=','om.destination')
                ->leftJoin('ss_pomaster as pm','pm.po_no','=','om.po_no')
                ->whereIn('od.no_transaksi',$do_no)->get();
            ?> 
                          @foreach($detail as $dtl)  
                            <tr class='even pointer'>
                            <?php 
                              
                                if ($jum <= 1) {?>
                              <td rowspan="{{$dtl->jumlah}}" style="width:200px"><h6 style="font-family: 'Arial Unicode MS'">{{$dtl->no_transaksi}}</h6></td>
                              <td rowspan="{{$dtl->jumlah}}" style="width:200px"><h6 style="font-family: 'Arial Unicode MS'">{{$dtl->customer_name}}</h6></td>
                              <td rowspan="{{$dtl->jumlah}}" style="width:200px"><h6 style="font-family: 'Arial Unicode MS'">{{$dtl->street2}}</h6></td>
                              <td rowspan="{{$dtl->jumlah}}" style="width:200px"><h6 style="font-family: 'Arial Unicode MS'">{{$dtl->trucking}}</h6></td>
                              <td rowspan="{{$dtl->jumlah}}" style="width:200px"><h6 style="font-family: 'Arial Unicode MS'">{{$dtl->material_code}} - {{$dtl->material_name}}</h6></td>
                              <td rowspan="{{$dtl->jumlah}}" style="width:200px"><h6 style="font-family: 'Arial Unicode MS'">{{$dtl->po_no}}</h6></td>
                              <td rowspan="{{$dtl->jumlah}}" style="width:200px"><h6 style="font-family: 'Arial Unicode MS'">{{date("d M", strtotime($dtl->po_date))}}</h6></td>
                              <?php
                                  $jum = $dtl->jumlah;
                                  $no++;
                                }else{
                                  $jum = $jum - 1;
                                }
                               ?>
                              <td><h6 style="font-family: 'Arial Unicode MS';width:200px">{{number_format($dtl->qty_out_uom)}}</h6></td>
                              <td><h6 style="font-family: 'Arial Unicode MS';width:200px">{{$dtl->lot_number}} ({{$dtl->qty_out_um}} {{$dtl->um}})</h6></td>
                              <td><h6 style="font-family: 'Arial Unicode MS';width:200px">{{$dtl->remarks}}</h6></td>
                            </tr>
                          @endforeach
                        </tbody>
</table>