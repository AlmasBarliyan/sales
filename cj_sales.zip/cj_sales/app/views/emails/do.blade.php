Dear all, <br>
<br>
<table border="1">
  <thead>
    <tr class='headings'>
      <th class='column-title' style='text-align:center;width:1%'>DO No.</th>
      <th class='column-title' style='text-align:center;width:1%'>Customer</th>
      <th class='column-title' style='text-align:center;width:1%'>Destination</th>
      <th class='column-title' style='text-align:center;width:1%'>Trucking</th>
      <th class='column-title' style='text-align:center;width:1%'>Qty (Kg)</th>
      <th class='column-title' style='text-align:center;width:1%'>Product</th>
      <th class='column-title' style='text-align:center;width:1%'>Lot Number</th>
      <th class='column-title' style='text-align:center;width:1%'>PO. No</th>
      <th class='column-title' style='text-align:center;width:1%'>PO. Date</th>
      <th class='column-title' style='text-align:center;width:1%'>Remarks</th>
    </tr>
  </thead>
  <tbody>
  <?php
    $customers = DB::table('ss_customers')->where('customer_code','=',$customer_code)->first();
    $customer_detail = DB::table('ss_customerdtl')->where('ship_to_party','=',$destination)->first();
    $cd_material = DB::table('cd_material')->where('material_code','=',$material_code)->first();
    $po = DB::table('ss_pomaster')->where('po_no','=',$po_no)->first();
  ?>
    <tr class='even pointer'>
      <td>
        {{ $do_no}}
      </td>
      <td>
        {{ $customers->customer_name}}
      </td>
      <td>
        {{ $customer_detail->ship_name}}
      </td>
      <td>
        {{ $trucking}}
      </td>
      <td>
        {{ $qty_uom}}
      </td>
      <td>
      	{{ $cd_material->material_name}} ({{ $material_code}})
      </td>
      <td>
      	{{ $lot_number}} ({{ $qty_um}} bag)
      </td>
      <td>
      	{{ $po_no}}
      </td>
      <td>
      	{{ $po->po_date}}
      </td>
      <td>
      	{{ $remarks}}
      </td>
    </tr>  
  </tbody>
</table>