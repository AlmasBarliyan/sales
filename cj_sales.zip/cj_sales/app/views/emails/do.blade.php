Dear all, <br>
<br>
<table border="1">
  <thead>
    <tr class='headings'>
      <th class='column-title' style='text-align:center'>DO No.</th>
      <th class='column-title' style='text-align:center'>Customer</th>
      <th class='column-title' style='text-align:center'>Destination</th>
      <th class='column-title' style='text-align:center'>Trucking</th>
      <th class='column-title' style='text-align:center'>Qty</th>
      <th class='column-title' style='text-align:center'>Product</th>
      <th class='column-title' style='text-align:center'>Lot Number</th>
      <th class='column-title' style='text-align:center'>PO. No</th>
      <th class='column-title' style='text-align:center'>PO. Date</th>
      <th class='column-title' style='text-align:center'>Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr class='even pointer'>
      <td>
        {{ $do_no}}
      </td>
      <td>
        
      </td>
      <td>
        {{ $trucking}}
      </td>
      <td>
        {{ $qty}}
      </td>
      <td>
      	{{ $material_code}}
      </td>
      <td>
      	{{ $lot_number}}
      </td>
      <td>
      	{{ $po_no}}
      </td>
      <td>
      	
      </td>
      <td>
      	{{ $remarks}}
      </td>
    </tr>  
  </tbody>
</table>