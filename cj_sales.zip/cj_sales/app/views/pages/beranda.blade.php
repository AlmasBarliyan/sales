@extends('products.table')
@section('content')
        <!-- top tiles -->
@if(Auth::check())
<!-- bar charts group -->
<div class="col-md-12 col-sm-12 col-xs-12">
  <div class="x_panel">
    <div class="x_title">
      <h2>Bar Chart Group <small>Sessions</small></h2>
      <ul class="nav navbar-right panel_toolbox">
        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="#">Settings 1</a>
            </li>
            <li><a href="#">Settings 2</a>
            </li>
          </ul>
        </li>
        <li><a class="close-link"><i class="fa fa-close"></i></a>
        </li>
      </ul>
      <div class="clearfix"></div>
    </div>
    <div class="x_content1">
      <div id="graph_bar_group" style="width:100%; height:280px;"></div>
    </div>
  </div>
</div>
<div class="clearfix"></div>
<!-- /bar charts group -->
<div class="col-md-6">
  <div class="x_panel">
    <div class="x_title">
      <h2>Coming Soon <small>Create Delivery Order</small></h2>
      <div class="clearfix"></div>
    </div>
    <div class="x_content">
    @foreach($create_do as $cdo)
      <?php 
      	$pomaster = DB::table('ss_pomaster')->leftJoin('ss_customers','ss_customers.customer_code','=','ss_pomaster.customer_code')->where('po_no','=',$cdo->po_no)->first();
      ?>
      <article class="media event">
        <a class="pull-left date" style="background:#d89619">
          <p class="month">{{date("M",strtotime($cdo->etd))}}</p>
          <p class="day">{{date("d",strtotime($cdo->etd))}}</p>
        </a>
        <div class="media-body">
          <a class="title" href="#">{{$cdo->po_no}} - {{$pomaster->customer_name}}</a>
          <p>{{$cdo->material_name}} - {{$cdo->qty_uom}} {{$cdo->uom}}</p>
        </div>
      </article>
     @endforeach
    </div>
  </div>
</div>
@endif
@endsection
@section('script')
<!-- moris js -->
<script src="js/moris/raphael-min.js"></script>
<script src="js/moris/morris.min.js"></script>
<script src="js/moris/example.js"></script>
@stop