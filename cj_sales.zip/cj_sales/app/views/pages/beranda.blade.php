@extends('layouts.main')
@section('content')
        <!-- top tiles -->
@if(Auth::check())

@endif
@endsection