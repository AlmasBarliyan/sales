<?php
  session_start();
  if ($_SESSION['m'] == null) {?>
  <script type="text/javascript">
    alert("Belum Memilih Warehouse!!");
    window.close();
  </script>
<?php
  }else{
  $con = mysql_connect('localhost', 'root', ''); 
 if (!$con) 
   { 
   die('Could not connect to server: ' . mysql_error()); 
   } 
   $db=mysql_select_db("sales", $con); 

    if (!$db) 
   { 
   die('Could not connect to DB: ' . mysql_error()); 
   } 

$sql = "select ss_invmonthly.*, cd_material.* from ss_invmonthly join cd_material on cd_material.material_code=ss_invmonthly.material_code where status = 'B' and end_qty_um != 0 and storage='{$_SESSION['m']}'";
//$sql="select * from cd_material ";
$result=mysql_query($sql);

 ?> 
<script type="text/javascript">
function sendValue(value,value1,value2,value3,value4,value5,value6,value7,value8,value9)
{
    var parentId = <?php echo json_encode($_GET['id']); ?>;
    var parId = <?php echo json_encode($_GET['pir']); ?>;
    var lot = <?php echo json_encode($_GET['lot']); ?>;
    var qty_um = <?php echo json_encode($_GET['qty_um']); ?>;
    var um = <?php echo json_encode($_GET['um']); ?>;
    var qty_uom = <?php echo json_encode($_GET['qty_uom']); ?>;
    var uom = <?php echo json_encode($_GET['uom']); ?>;
    var out_um = <?php echo json_encode($_GET['out_um']); ?>;
    var out_uom = <?php echo json_encode($_GET['out_uom']); ?>;
    var size = <?php echo json_encode($_GET['size']); ?>;
    window.opener.updateValue(parentId, value);
    window.opener.updateValue1(parId, value1);
    window.opener.updateValue2(lot, value2);
    window.opener.updateValue3(qty_um, value3);
    window.opener.updateValue4(um, value4);
    window.opener.updateValue5(qty_uom, value5);
    window.opener.updateValue6(uom, value6);
    window.opener.updateValue7(out_um, value7);
    window.opener.updateValue8(out_uom, value8);
    window.opener.updateValue9(size, value9);
    window.close();
}
</script>

 <form name="selectform"> 

                <table border=1 width=1000 id="hor-minimalist-a"> 
                    <tr>
                        <th></th> 
                        <th>Material Code</th>                       
                        <th>Material Name</th> 
                        <th>Lot Number</th> 
                        <th>Qty Bad</th>  
                    </tr> 
<?php 
   while($rows=mysql_fetch_array($result)){
?> 
  <tr> 
      <td><input type=button value="Select" onClick="sendValue('<?php echo $rows['material_code']; ?>','<?php echo $rows['material_name']; ?>','<?php echo $rows['lot_number']; ?>','<?php echo $rows['end_qty_um']; ?>','<?php echo $rows['um']; ?>','<?php echo $rows['end_qty_uom']; ?>','<?php echo $rows['uom']; ?>','<?php echo $rows['um']; ?>','<?php echo $rows['uom']; ?>','<?php echo $rows['material_size']; ?>')" /></td>
      <td><center><?php echo $rows['material_code']; ?></td> 
      <td><center><?php echo $rows['material_name']; ?></td> 
      <td><center><?php echo $rows['lot_number']; ?></td> 
      <td><center><?php echo $rows['end_qty_um']; ?> <?php echo $rows['um']; ?></td> 
  </tr>                                    

<?php 
    } 
  }
?> 
                    </table> 