<?php
  session_start();
  if ($_SESSION['mo'] == null and $_SESSION['p']== null) {?>
  <script type="text/javascript">
    alert("Belum Memilih Number PO dan Warehouse!!");
    window.close();
  </script>
<?php
  }else{
  $con = mysql_connect('localhost', 'root', ''); 
 if (!$con) 
   { 
   die('Could not connect to server: ' . mysql_error()); 
   } 
   $db=mysql_select_db("sales", $con); 

    if (!$db) 
   { 
   die('Could not connect to DB: ' . mysql_error()); 
   } 

$sql = "select distinct im.*, mt.*,pd.* from ss_invmonthly im left join ss_podetail pd on  pd.material_code=im.material_code left join cd_material mt on mt.material_code=im.material_code where pd.po_no ='{$_SESSION['p']}' and im.`status`='G' and im.end_qty_um!=0 and storage='{$_SESSION['mo']}'";
//$sql="select * from cd_material ";
$result=mysql_query($sql);

 ?> 


 <form name="selectform"> 

                <table border=1 width=1000 id="hor-minimalist-a"> 
                    <tr>
                        <th></th> 
                        <th>Material Code</th>                       
                        <th>Material Name</th> 
                        <th>Lot Number</th> 
                        <th>Qty</th>  
                    </tr> 
<?php 
   while($rows=mysql_fetch_array($result)){
?> 
  <tr> 
      <td><input type=button value="Select" onClick="sendValue('<?php echo $rows['material_code']; ?>','<?php echo $rows['material_name']; ?>','<?php echo $rows['lot_number']; ?>','<?php echo $rows['end_qty_um']; ?>','<?php echo $rows['um']; ?>','<?php echo $rows['end_qty_uom']; ?>','<?php echo $rows['uom']; ?>','<?php echo $rows['um']; ?>','<?php echo $rows['uom']; ?>','<?php echo $rows['material_size']; ?>','<?php echo $rows['qty_um']; ?>','<?php echo $rows['qty_uom']; ?>')" /></td>
      <td><center><?php echo $rows['material_code']; ?></td> 
      <td><center><?php echo $rows['material_name']; ?></td> 
      <td><center><?php echo $rows['lot_number']; ?></td> 
      <td><center><?php echo $rows['end_qty_um']; ?> <?php echo $rows['um']; ?></td> 
  </tr>                                    

<?php 
    } 
  }
?> 
</table> 
<script type="text/javascript">
  function sendValue(value,value1,value2,value3,value4,value5,value6,value7,value8,value9,value10,value11)
  {
      var parentId = <?php echo json_encode($_GET['id']); ?>;
      var parId = <?php echo json_encode($_GET['pir']); ?>;
      var lot = <?php echo json_encode($_GET['lot']); ?>;
      var qty_um = <?php echo json_encode($_GET['qty_um']); ?>;
      var um = <?php echo json_encode($_GET['um']); ?>;
      var qty_uom = <?php echo json_encode($_GET['qty_uom']); ?>;
      var uom = <?php echo json_encode($_GET['uom']); ?>;
      var out_um = <?php echo json_encode($_GET['out_um']); ?>;
      var out_uom = <?php echo json_encode($_GET['out_uom']); ?>;
      var qty_out_um = <?php echo json_encode($_GET['qty_out_um']); ?>;
      var qty_out_uom = <?php echo json_encode($_GET['qty_out_uom']); ?>;
      var size = <?php echo json_encode($_GET['size']); ?>;
      window.opener.updateValue(parentId, value);
      window.opener.updateValue1(parId, value1);
      window.opener.updateValue2(lot, value2);
      window.opener.updateValue3(qty_um, value3);
      window.opener.updateValue4(um, value4);
      window.opener.updateValue5(qty_uom, value5);
      window.opener.updateValue6(uom, value6);
      window.opener.updateValue7(out_um, value7);
      window.opener.updateValue8(out_uom, value8);
      window.opener.updateValue9(size, value9);
      window.opener.updateValue10(qty_out_um, value10);
      window.opener.updateValue11(qty_out_uom, value11);
      window.close();
  }
</script>