<?php
    /* Database setup information */
    $dbhost = 'localhost';  // Database Host
    $dbuser = 'root';       // Database Username
    $dbpass = '';           // Database Password
    $dbname = 'cj_local_sales_do';      // Database Name

    /* Connect to the database and select database */
    $conn = mysql_connect($dbhost, $dbuser, $dbpass) or die(mysql_error());
    mysql_select_db($dbname);


    $return_arr = array();
    $param = $_GET["term"];

    $fetch = mysql_query("SELECT * FROM cd_material WHERE material_code REGEXP '^$param' or material_name LIKE '%$param%' LIMIT 10");

    /* Retrieve and store in array the results of the query.*/
    while ($row = mysql_fetch_array($fetch, MYSQL_ASSOC)) {

        $row_array['material_code']          = $row['material_code'];
        $row_array['material_name']          = $row['material_name'];
        $row_array['nicklot']         = $row['nicklot'];
        $row_array['size']         = $row['material_size'];
        $row_array['uom']         = $row['uom'];
        $row_array['um']         = $row['um'];

        array_push( $return_arr, $row_array );
    }

    /* Free connection resources. */
    mysql_close($conn);

    /* Toss back results as json encoded array. */
    echo json_encode($return_arr);

