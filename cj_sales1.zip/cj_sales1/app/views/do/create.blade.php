@extends('products.table')
@section('content')
        <div class="">
          <div class="page-title">
            <div class="title_left">
              <h3>
                Delivery Order
              </h3>
            </div>

            <div class="title_right">
              <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                <div class="input-group">
                  <input type="text" class="form-control" placeholder="Search for...">
                  <span class="input-group-btn">
                    <button class="btn btn-default" type="button">Go!</button>
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>List Delivery Order </h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a href="{{URL::to('/delivery-order/create')}}"><button type="button" class="btn btn-round btn-primary">+ Create DO </button></a></li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <div class="table-responsive">
                    <table frame="box" id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="1100px">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>DO No.</th>
                          <th>Customer</th>
                          <th>Destination</th>
                          <th>Trucking</th>
                          <th>PO No.</th>
                          <th>Product</th>
                          <th>Lot Number</th>
                          <th>Qty</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php $no = 1 ?>
                        @foreach($delivery_order as $list_do)
                        <?php
                          $outdetail = DB::table('ss_outdtl')->join('cd_material','cd_material.material_code','=','ss_outdtl.material_code')->where('no_transaksi','=',$list_do->no_transaksi)->get();
                          $customers = DB::table('ss_customers')->join('ss_customerdtl','ss_customers.customer_code','=','ss_customerdtl.sold_to_party')->where('ss_customers.customer_code','=',$list_do->customer_code)->where('ss_customerdtl.ship_to_party','=',$list_do->destination)->first();
                        ?>
                        <tr>
                          <td>{{ $no++ }} </td>
                          <td>{{$list_do->no_transaksi}} </td>
                          <td>{{$customers->customer_name}} </td>
                          <td>{{$customers->ship_name}} </td>
                          <td>{{$list_do->trucking}} </td>
                          <td>{{$list_do->po_no}} </td>
                          <td>
                            <ul style="list-style-type:none">
                            @foreach($outdetail as $outdtl)
                              <li>{{$outdtl->material_name}} </li>
                            @endforeach
                            </ul>
                          </td>
                          <td>
                            <ul style="list-style-type:none">
                            @foreach($outdetail as $outdtl)
                              <li>{{$outdtl->lot_number}} </li>
                            @endforeach
                            </ul>
                          </td>
                          <td>
                            <ul style="list-style-type:none">
                            @foreach($outdetail as $outdtl)
                              <li>{{$outdtl->qty_out_um}} </li>
                            @endforeach
                            </ul>
                          </td>
                        </tr>
                        @endforeach
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
@stop
@section('script')
<script>
function myFunction() {
    var table = document.getElementById("myTable");
    var row = table.insertRow(2);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    
    cell1.innerHTML = '{{ Form::select("lotnumber[]", array(), null, array("id" => "sLotnumber", "class"=>"select2_single form-control"))  }}';
    cell2.innerHTML = "<input class='form-control' type='text' name='qty_bag[]'>";
    
}
</script>
<script type="text/javascript">
            $(document).ready(function() {
                $("select[name='material_code']").on('change', function(){
                $.post('{{ URL::to('delivery/data') }}', {type: 'lotnumber', id: $("select[name='material_code']").val()}, function(e){
                    $("select[name='lotnumber[]']").html(e);
                });
                
                $('#sMaterial').html('');
                $('#sDesa').html('');
                
            });
            $('#sLotnumber').on('change', function(){
                $.post('{{ URL::to('delivery/data') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
                    $('#sMaterial').html(e);
                });
                $('#sDesa').html('');
            });
            $('#sKecamatan').on('change', function(){
                $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
                    $('#sDesa').html(e);
                });
            });
            });
        </script>
@stop