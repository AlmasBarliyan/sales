@extends('products.table')
@section('content')
        <div class="">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Create Delivery Order </h2>
                  
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <form class="form-horizontal form-label-left input_mask" action="{{URL::to('/create-delivery-order')}}" method="post">
                  <table class="table table-striped responsive-utilities jambo_table" style="padding-bottom:30px">                    
                    <tbody>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">DO No.</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <p id="dono"><input name="no_transaksi" type="text" style="width: 250px;" readonly="" class="form-control" /></p>
                              </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">PO NO. </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                  {{ Form::select('po_no', $po, null, array('id'=>'sPo','class'=>'select2_single form-control'))  }}
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">Date Out</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <input type="text" style="z-index: 100000;width: 250px;" value="<?php echo date('d-m-Y')?>" name="date_out" id="idTourDateDetails1" class="form-control has-feedback-left""> 
                                <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                <span id="inputSuccess2Status" class="sr-only">(success)</span>
                              </div>
                            </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Customer </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                  
                                  <p id="cu"><input  type="text" class="form-control" ></p>
                                </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Trucking </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                  <p ><input required="" type="text" style="width: 250px;" class="form-control" name="trucking"></p>
                                </div>
                            </div>
                            <!-- <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-10" for="name">No. Surat Jalan</label>
                              &emsp;&emsp;&emsp;&emsp;
                              <div class="col-md-4 col-sm-2 col-xs-10">
                                <?php 
                                /*$no_in = DB::select(DB::raw("select max(substr(no_srtjln,-5,5)) as max from ss_outmaster where(select max(substr(no_srtjln,-5,5)) from ss_outmaster )"));*/
                                $no_in = DB::select(DB::raw("select max(substr(no_srtjln,-5,5)) as max from ss_outmaster where(select max(substr(no_srtjln,-5,5)) from ss_outmaster where substr(no_srtjln,1,8)= DATE_FORMAT(NOW(),'%Y%m%d') )"));
                                ?>
                                @foreach($no_in as $noin)
                                <input style="width: 250px;" type="text" readonly="" class="form-control" value="{{date('Ymd'). sprintf('%05d', $noin->max+1)}}" name="no_srtjln">
                                @endforeach  
                              </div>
                            </div> -->
                          </td>
                          <td>
                            <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Destination</label>
                              <div class="col-md-9 col-sm-9 col-xs-12">
                                <p id="sip"><input  type="text" class="form-control" ></p>
                                <!-- {{ Form::select('ship_to_party', array(), null, array('id' => 'dl', 'class'=>'select2_single form-control'))  }} -->
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div class="item form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-10" for="name">Remarks</label>
                          <div class="col-md-9 col-sm-9 col-xs-12">
                            <input type="text" style="width:250px"  class="form-control" name="remarks">
                          </div>
                        </div>
                          </td>
                          <td>
                            <div class="item form-group" >
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Warehouse </label>
                                <div class="col-md-9 col-sm-9 col-xs-12">
                                <select name="source" required="required" class="select2_single form-control" id="sWh">
                                  <option></option>
                                    @foreach($warehouse as $wh)
                                      <option value="{{$wh->code}}">{{$wh->code_name}}</option>
                                    @endforeach
                                </select>
                                  <!-- <p id="stor"><input  type="text" class="form-control" ></p> -->
                                </div>
                            </div>
                          </td>
                        </tr>
                         
                        

                    </tbody>
                  </table>
                    <div>
                      <table id="inv" class='table table-striped responsive-utilities jambo_table bulk_action order-list' cellspacing="0" width="100%">
                      <!-- <table class='table table-striped responsive-utilities jambo_table bulk_action order-list ' id="sProducts"> -->
                          <thead>
                            <tr class='headings'>
                              <th class='column-title' colspan='3' style='text-align:center'>Material </th>
                              <th class='column-title' style='text-align:center'>Lot Number</th>
                              <th class='column-title' style='text-align:center' colspan='2'>Qty</th>
                              <th class='column-title' style='text-align:center' colspan='2'>Qty DO</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr class='even pointer'>
                              <td>
                                <a class="deleteRow" title="Hapus Item"><i class="fa fa-trash"></i></a>
                                <input type="text" id="sku" name="material_code[]" style="width:80px">
                                <input type="button" name="choice" onClick="selectValue('sku','pir','lot','qty_um','um','qty_uom','uom','out_um','out_uom','size')" value="..." title="Cari Item" style="width:20px">
                              </td>
                              <td>
                                <input type="text" name="material_name[]" id="pir" />
                              </td>
                              <td>
                                <input type="text" name="lot_number[]" id="lot" style="width:100px"/>
                              </td>
                              <td>
                                <input style="width:80px" type="text" id="qty_um" name="qty_um[]" readonly="readonly" />
                                <input type="hidden" name="size[]" id="size" class="tInput" />
                                <input style="width:40px" id="um" class="tInput" readonly="readonly"/>
                              </td>
                              <td>
                                <input style="width:80px" type="text" id="qty_uom" name="qty_uom[]" readonly="readonly" />
                                <input style="width:30px" id="uom" class="tInput" readonly="readonly"/>
                              </td>
                              <td>
                                <input style="width:80px" type="text" id="qty_out_um" name="qty_out_um[]" />
                                <input style="width:40px" id="out_um" class="tInput" readonly="readonly"/>
                              </td>
                              <td>
                                <input style="width:80px" type="text" id="qty_out_uom" name="qty_out_uom[]" />
                                <input style="width:30px" id="out_uom" class="tInput" readonly="readonly"/>
                              </td>
                            </tr>  
                          </tbody>
                      </table>
                    </div>                    
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12" style="text-align:left">
                        <a href="#" id="addrow" class="btn btn-primary"><span> + Add Row</span></a>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
                        <button type="submit" class="btn btn-success">Save</button>
                      </div>
                    </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
@stop
@section('style')

{{ HTML::style('css/css/layout-styles.css')}}
{{HTML::style('css/css/themes/smoothness/jquery-ui-1.8.4.custom.css')}}
@stop
@section('script')
<script type="text/javascript">
  $('#idTourDateDetails1').datepicker({
       dateFormat: 'dd-mm-yy',
       changeMonth: true,
       changeYear: true,
       altField: "#idTourDateDetailsHidden",
       altFormat: "yy-mm-dd"
   });
  document.getElementById("idTourDateDetails1").focus();
</script>
{{ HTML::script('js/select/select2.full.js')}}
<script>
    $(document).ready(function() {
        $(".select2_single").select2({
            placeholder: "Select...",
            allowClear: true
        });
        $(".select2_group").select2({});
        $(".select2_multiple").select2({
            maximumSelectionLength: 4,
            placeholder: "With Max Selection limit 4",
            allowClear: true
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#sCustomer").on('change', function(){
        $.post('{{ URL::to('delivery/data1') }}', {type: 'dl', id: $("#sCustomer").val()}, function(e){
            $("#dl").html(e);
        });
        
        $('#sMaterial').html('');
        $('#sDesa').html('');
        
    });
    $('#sLotnumber').on('change', function(){
        $.post('{{ URL::to('delivery/data') }}', {type: 'material', id: $('#sLotnumber').val()}, function(e){
            $('#sMaterial').html(e);
        });
        $('#sDesa').html('');
    });
    $('#sKecamatan').on('change', function(){
        $.post('{{ URL::to('site/data') }}', {type: 'desa', id: $('#sKecamatan').val()}, function(e){
            $('#sDesa').html(e);
        });
    });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#sPo").on('change', function(){
        /*$.post('{{ URL::to('delivery/show') }}', {type: 'po', wh: $("#sWh").val(), pono: $("#pono").val()}, function(e){
            $("#inv").html(e);
        });*/
        $.post('{{ URL::to('delivery/show') }}', {type: 'cu', id: $("#sPo").val()}, function(e){
            $("#cu").html(e);
        });
        $.post('{{ URL::to('delivery/show') }}', {type: 'sip', id: $("#sPo").val()}, function(e){
            $("#sip").html(e);
        });
        /*$.post('{{ URL::to('delivery/show') }}', {type: 'stor', id: $("#sPo").val()}, function(e){
            $("#stor").html(e);
        });*/
        $('#sMaterial').html('');
        $('#sDesa').html('');
    });
    });
</script>
<script type="text/javascript">
  $(document).ready(function() {
        $("#sWh").on('change', function(){
          $.post('{{ URL::to('delivery/show') }}', {type: 'po', wh: $("#sWh").val(), pono: $("#pono").val()}, function(e){
              $("#inv").html(e);
          });
          $.post('{{ URL::to('delivery/show') }}', {type: 'dono', wh: $("#sWh").val(), dt: $("#idTourDateDetails1").val() }, function(e){
              $("#dono").html(e);
          });
        });
    });
</script>
<script type="text/javascript">
function updateValue(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue1(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue2(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue3(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue4(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue5(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue6(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue7(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue8(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
function updateValue9(id, value)
{
    // this gets called from the popup window and updates the field with a new value
    document.getElementById(id).value = value;

}
</script>
<script>
          $(document).ready(function () {
            var counter = 1;
            var co = 1;
            $("#addrow").on("click", function () {
              counter++;
              co++;
              var newRow = $("<tr>");
              var cols = "";
              cols += '<td><a class="deleteRow"><i class="fa fa-trash"></i> </a><input type="text" id="sku'+ co +'" name="material_code[]" style="width:80px"> <input type="button" name="choice" onClick="selectValue(\''+'sku'+co+'\',\''+'pir'+co+'\',\''+'lot'+co+'\',\''+'qty_um'+co+'\',\''+'um'+co+'\',\''+'qty_uom'+co+'\',\''+'uom'+co+ '\',\''+'out_um'+co+'\',\''+'out_uom'+co+'\',\''+'size'+co+'\')" value="..." style="width:20px"></td>';
              cols += '<td><input type="text" id="pir'+ co +'" name="material_name[]"/></td>';
              cols += '<td><input type="text" id="lot'+ co +'" name="lot_number[]" style="width:100px"/></td>';
              cols += '<td><input style="width:60px" type="text" id="qty_um'+ co +'" name="qty_um[]" readonly="readonly" /><input type="hidden" name="size[]" id="size'+ co +'" class="tInput" /> <input style="width:40px" id="um'+ co +'" class="tInput" readonly="readonly"/></td><td><input style="width:60px" type="text" id="qty_uom'+ co +'" name="qty_uom[]" readonly="readonly" /> <input style="width:30px" id="uom'+ co +'" class="tInput" readonly="readonly"/></td>';
              cols += '<td><input style="width:60px" type="text" id="qty_out_um" name="qty_out_um[]" /> <input style="width:40px" id="out_um'+ co +'" class="tInput" readonly="readonly"/></td><td><input style="width:60px" type="text" id="qty_out_uom" name="qty_out_uom[]" /> <input style="width:30px" id="out_uom'+ co +'" class="tInput" readonly="readonly"/></td>';
              newRow.append(cols);
              
              $("table.order-list").append(newRow);

            });
            
            $("table.order-list").on("change", 'input[name^="price"], input[name^="qty_out_um"]', function (event) {
              calculateRow($(this).closest("tr"));
              calculateGrandTotal();
            });
            
            $("table.order-list").on("click", "a.deleteRow", function (event) {
              $(this).closest("tr").remove();
              calculateGrandTotal();
            });
          });
          function selectValue(id,pir,lot,qty_um,um,qty_uom,uom,out_um,out_uom,size)
              {
                 var counter = 1;
                 var co = 1;
                  var myData = new Array('sku'+co, 'pir=pir'+co);
                  var url = myData.join('&');
                  // open popup window and pass field id
                  
                    window.open('../sku1.php?id=' + encodeURIComponent(id)+'&pir='+encodeURIComponent(pir)+'&lot='+encodeURIComponent(lot)+'&qty_um='+encodeURIComponent(qty_um)+'&um='+encodeURIComponent(um)+'&qty_uom='+encodeURIComponent(qty_uom)+'&uom='+encodeURIComponent(uom)+'&out_um='+encodeURIComponent(out_um)+'&out_uom='+encodeURIComponent(out_uom)+'&size='+encodeURIComponent(size),'popuppage',
                    'width=1050,toolbar=1,resizable=1,scrollbars=yes,height=400,top=100,left=100');  
                  
                  
              }  
          function calculateRow(row) {
            var size = +row.find('input[name^="size"]').val();
            var qty = +row.find('input[name^="qty_out_um"]').val();
            var qty_um = +row.find('input[name^="qty_um"]').val();
            if (qty > qty_um ) {
              alert("Quantity Melebihi Stok BAD");
              row.find('input[name^="qty_out_um"]').val("");
              row.find('input[name^="qty_out_uom"]').val("");
            }
            else{
              row.find('input[name^="qty_out_uom"]').val((size * qty));  
            }
            
            
          }
          
            
          function calculateGrandTotal() {
            var grandTotal = 0;
            $("table.order-list").find('input[name^="linetotal"]').each(function () {
              grandTotal += +$(this).val();
            });
            $("#grandtotal").text(grandTotal.toFixed(2));
          }
        </script>
@stop