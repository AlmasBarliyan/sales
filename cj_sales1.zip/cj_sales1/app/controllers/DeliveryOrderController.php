<?php

class DeliveryOrderController extends \BaseController {
    public function __construct()
    {
        $this->beforeFilter('auth');
    }
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		//$po = DB::table('ss_po')->distinct()->select('po_no')->get();
		//$po = array(''=>'');
		/*foreach (DB::table('ss_invdaily')->join('ss_po', 'ss_invdaily.material_name', '=', 'ss_po.material_name')->select('ss_po.po_no','ss_po.material_name')->get() as $row) {
		 	$po[$row->material_name] = $row->material_name;
		 }*/ 
		
		$do = DB::table('ss_outmaster')->join('ss_outdtl', 'ss_outdtl.no_transaksi', '=', 'ss_outmaster.no_transaksi')->join('ss_customers','ss_customers.customer_code','=','ss_outmaster.customer_code')->get();

		return View::make('do.create')
			->with('delivery_order',DB::table('ss_outmaster')->where('status','=','D')->get());
	}
	public function getCreate()
	{
        session_start();
        session_destroy();
		$po = array('' => '');
        foreach(DB::table('ss_pomaster')->get() as $row)
            $po[$row->po_no] = $row->po_no;
        
		return View::make('do.add')
			->with('customers',Customers::where('customer_ktg','=',Auth::user()->emp_ktg)->get())
			->with('warehouse',CommonCode::where('hcode','LIKE','%'.'GD'.'%')->where('code','!=','*')->get())
			->with('po', $po);
	}
	public function create(){
		
		$insert = array();
        foreach (Input::get('material_code') as $key => $material_code) {
            $insert[$key]['material_code'] = $material_code;
        }
        foreach (Input::get('qty_out_um') as $key => $qty_out_um) {
            $insert[$key]['qty_out_um'] = $qty_out_um;
        }
        foreach (Input::get('qty_out_uom') as $key => $qty_out_uom) {
            $insert[$key]['qty_out_uom'] = $qty_out_uom;
        }
        foreach (Input::get('lot_number') as $key => $lot_number) {
            $insert[$key]['lot_number'] = $lot_number;
        }
        
        $company = Auth::user()->company;
        $plant = Auth::user()->plant;
        
        
        $source = Input::get('source');
        $destination = Input::get('destination');
        if ($source == '8001' or $source == '8002') {
            $src = 'A';
        }elseif ($source == '8003') {
            $src = 'B';
        }
        $trucking   = Input::get('trucking');
        //$no_srtjln  = Input::get('no_srtjln');
        $customer_code = Input::get('customer_code');
        $po_no = Input::get('po_no');
        $remarks    = Input::get('remarks');
        $date_out   = Input::get('date_out');
        $user_create = Auth::user()->employee_code;
        $user_update = Auth::user()->employee_code;
        $no_rtn = DB::select(DB::raw("select max(substr(no_transaksi,-3,3)) as max from ss_outmaster where(select max(substr(no_transaksi,-3,3)) from ss_outmaster where substr(no_transaksi,3,8)= DATE_FORMAT(NOW(),'%Y%m%d')) and substr(no_transaksi,-4,1)='{$src}'"));
        foreach ($no_rtn as $nortn) {
            /*if ($destination == '7001') {
                $no_transaksi = 'DO'.date('Ymd').'B' .sprintf('%03d', $nortn->max+1);
            }
            elseif($destination == '7002'){
                $no_transaksi = 'DO'.date('Ymd').'A'.sprintf('%03d', $nortn->max+1);
            }*/
            $no_transaksi = 'DO'.date('Ymd').$src.sprintf('%03d', $nortn->max+1);
        }
        $do_no = Input::get('no_transaksi');
        $return = DeliveryOrder::create([
                'company'       => $company,
                'plant'         => $plant,
                'no_transaksi'  => $do_no,
                'po_no'			=> $po_no,
                'customer_code'	=> $customer_code,
                'date_out'      => $date_out,
                'status'        => 'D',
                'destination'   => $destination,
                'source'        => $source,
                'trucking'      => $trucking,
              //  'no_srtjln'     => $no_srtjln,
                'remarks'       => $remarks,
                'user_create'   => $user_create,
                'user_update'   => $user_update
            ]);
        foreach ($insert as $row ) {
            //$lot_number = array(''=>'');
            
            if ($row['qty_out_um'] != 0) {
                
            $return->DoDetail()->attach($do_no,[
                'no_transaksi'     => $do_no,
                'material_code' => $row['material_code'],
                'lot_number'    => $row['lot_number'],
                'qty_out_um'    => $row['qty_out_um'],
                'qty_out_uom'   => $row['qty_out_uom'],
                'status'        => 'G'
                ]);
            $return->InvDaily()->attach($do_no,[
                'id'            => $do_no,
                'company'       => $company,
                'plant'         => $plant,
                'material_code' => $row['material_code'],
                'lot_number'    => $row['lot_number'],
                'qty_um'        => $row['qty_out_um'],
                'qty_uom'       => $row['qty_out_uom'],
                'storage'       => $source,
                'status'        => 'G',
                'status2'       => 'O',
                'date_ym'       => $date_out,
                'created_at'    => date("Y-m-d H:i:s"),
                'updated_at'    => date("Y-m-d H:i:s")
                ]);
            }
        }
		return Redirect::to('delivery-order');
	}

	public function postData() {
        switch(Input::get('type')):
            case 'lotnumber':
                $return = '<option value=""></option>';
                foreach(Inventory::where('material_code','=',Input::get('id'))->get() as $row)
                    $return .= "<option value='$row->lot_number'>$row->material_name $row->lot_number $row->good_qty_bag BAG</option>";
                return $return;
                
            break;
        endswitch;    
    }
    public function postData1() {
        switch(Input::get('type')):
            case 'dl':
            	$return = "<option></option>";
                foreach(DB::table('ss_customerdtl')->where('sold_to_party','=',Input::get('id'))->get() as $row)
                	$return .= "<option value='$row->ship_to_party'>$row->ship_to_party - $row->ship_name</option>";
                return $return;
                
            break;
        endswitch;    
    }

    public function postShow() {
        switch(Input::get('type')):
            case 'po':
                $m = Input::get('wh');
                if (Input::get('pono')=='') {
                    $return = "<script>alert('PO Number is empty!!');window.location.reload();</script>";
                    return $return;
                }
                else{    
                $list = DB::table('ss_invmonthly')->leftJoin('ss_podetail','ss_invmonthly.material_code','=','ss_podetail.material_code')->leftJoin('cd_material','ss_invmonthly.material_code','=','cd_material.material_code')->select('ss_invmonthly.*','cd_material.*')->distinct()->where('po_no','=',Input::get('pono'))->where('storage','=',Input::get('wh'))->where('ss_invmonthly.status','=','G')->where('ss_invmonthly.end_qty_um','!=',0)->get();
                if (count($list)==0) {
                    $return = "<script>alert('Not Found a Product In Warehouse!!');window.location.reload();</script>";
                }else{
            	/*$return = "<table class='table table-striped responsive-utilities jambo_table bulk_action'>
                          <thead>
                            <tr class='headings'>
                              <th class='column-title' colspan='2' style='text-align:center'>Material </th>
                              <th class='column-title' style='text-align:center'>Lot Number</th>
                              <th class='column-title' style='text-align:center'>Qty in Stok</th>
                              <th class='column-title' style='text-align:center' colspan='4'>Qty DO</th>
                            </tr>
                          </thead>
                          <tbody>";*/
                foreach (DB::table('ss_invmonthly')->leftJoin('ss_podetail','ss_invmonthly.material_code','=','ss_podetail.material_code')->leftJoin('cd_material','ss_invmonthly.material_code','=','cd_material.material_code')->select('ss_invmonthly.*','cd_material.*')->distinct()->where('po_no','=',Input::get('pono'))->where('storage','=',Input::get('wh'))->where('ss_invmonthly.status','=','G')->where('ss_invmonthly.end_qty_um','!=',0)->get() as $row)
                    session_start();
                    $_SESSION['pn'] = Input::get('pono');
                    $_SESSION['m'] = $m;
                	$return .= "
                              <!--<tr class='even pointer'>
                                <td class='col-md-3' colspan='2'>
                                    <input value='$row->material_code' name='material_code[]' type='text' class='col-md-3' >
                                    <input  name='material_name' value='$row->material_name' type='text' class='col-md-9' >
                                </td>
                               	<td class='col-md-2'><input name='lot_number[]' type='text' id='result_bad' value='$row->lot_number' readonly='readonly' class='col-md-12'></td>
                               	<td class='col-md-2' colspan='2'>
                                    <input name='end_qty[]' value='$row->end_qty_um' class='col-md-6' type='text' >
                                    <input name='return_qty_bag' value='$row->um' class='col-md-6' type='text' >
                                </td>
                                <td class='col-md-5' colspan='4'>
                                    <input style='width:80px' name='qty[]' class='tInput' id='itemQty' tabindex='1' />
                                    <input type='hidden' name='size[]' value='$row->material_size'  class='tInput' />
                                    <input style='width:40px' class='tInput' value='$row->um' id='um' readonly='readonly' />
                                    <input style='width:80px' type='text' name='uom[]' readonly='readonly' />
                                    <input style='width:30px' id='uom' class='tInput' value='$row->uom' readonly='readonly' />
                                </td>
                                </tr>-->
                      ";
                }
                return $return;
                }
            break;
            case 'dono':
            	$source = Input::get('wh');
		        $dt = date("Ymd",strtotime(Input::get('dt')));
		        if ($source == '8001' or $source == '8002') {
		            $src = 'A';
		        }elseif ($source == '8003') {
		            $src = 'B';
		        }
            	foreach(DB::select(DB::raw("select max(substr(no_transaksi,-3,3)) as max from ss_outmaster where(select max(substr(no_transaksi,-3,3)) from ss_outmaster where substr(no_transaksi,3,8)= '{$dt}') and substr(no_transaksi,-4,1)='{$src}'")) as $row)
            		$no_transaksi = 'DO'.date('Ymd',strtotime($dt)).$src.sprintf('%03d', $row->max+1);
            		$return = "<input  type='text' style='width: 250px;'' class='form-control' readonly='readonly' name='no_transaksi' value='$no_transaksi'>";
            	return $return;
            break;
            case 'cu':
                $id = Input::get('id');
            	foreach(DB::select(DB::raw("select cs.*,pm.po_no from ss_pomaster pm join ss_customers cs on cs.customer_code=pm.customer_code where pm.po_no='{$id}'")) as $row)
                    
            	$return = "<input type='hidden' name='customer_code' value='$row->customer_code' ><input type='hidden' value='$row->po_no' id='pono'><input  type='text' class='form-control' readonly='readonly' name='' value='$row->customer_name'>";
            	return $return;
            break;
            case 'sip':
                $id = Input::get('id');
            	foreach(DB::select(DB::raw("select cd.* from ss_pomaster pm join ss_customers cs on cs.customer_code=pm.customer_code join ss_customerdtl cd on cd.ship_to_party=pm.ship_to_party where pm.po_no='{$id}'")) as $row)
            	$return = "<input type='hidden' value='$row->ship_to_party' name='destination'><input  type='text' class='form-control' readonly='readonly' name='' value='$row->ship_name'>";
            	return $return;
            break;
            /*case 'stor':
            	foreach(DB::table('ss_pomaster')->join('ss_podetail', 'ss_pomaster.po_no', '=', 'ss_podetail.po_no')->join('ss_invmonthly', 'ss_invmonthly.material_code', '=', 'ss_podetail.material_code')->join('cd_material', 'cd_material.material_code', '=', 'ss_invmonthly.material_code')->join('ss_customers','ss_customers.customer_code','=','ss_pomaster.customer_code')->join('ss_customerdtl','ss_pomaster.ship_to_party','=','ss_customerdtl.ship_to_party')->join('cd_code','cd_code.code','=','ss_invmonthly.storage')->where('ss_podetail.po_no','=',Input::get('id'))->where('ss_invmonthly.status','=','G')->where('ss_invmonthly.end_qty','!=',0)->get() as $row)
            	$return = "<input type='hidden' value='$row->code' name='source'><input  type='text' class='form-control' readonly='readonly' name='' value='$row->code_name'>";
            	return $return;
            break;*/
        endswitch;    
    }
}
