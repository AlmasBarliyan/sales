<?php

class InventoryController extends \BaseController {
    public function __construct()
    {
        $this->beforeFilter('auth');
    }
    public function getIndex() {

        /*$products = array('' => '');
        foreach( as $row)
            $products[$row->material_code] = $row->material_code." - ". $row->material_name ;*/
        return View::make('inventory.create', array(
            'products'  => Products::all(),
            'storage'   => CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get(),
            'inbound'   => DB::table('tx_itemin')->orderBy('date_in','DESC')->get()
        ));
    }
    
    public function postData() {
        switch(Input::get('type')):
            case 'nicklot' and 'size':
                //$return = '<option value=""></option>';
                foreach(Products::where('material_code', Input::get('id'))->get() as $row)
                    $return = "<input type='text' readonly='readonly' value='$row->nicklot' class='form-control' name='nicklot'>
                                <input type='hidden' value='$row->material_name' name='material_name'>
                                <input type='hidden' id='good_kg' onkeyup='myFunction()' value='$row->material_size' name='good_qty_bag'>
                                <input type='hidden' id='bad_kg' onkeyup='myFunction()' value='$row->material_size' name='bad_qty_kgs'>
                                <input type='hidden' id='result_kg' onkeyup='myFunction()' value='$row->material_size' name='result_kgs'> ";
                return $return;
            break;
        endswitch;    
    }
    public function add(){
        return View::make('inventory.add')
            ->with('storage',CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get());
    }
    public function postCreate(){
        date_default_timezone_set("Asia/Jakarta");
           
        $insert = array();
        foreach (Input::get('material_code') as $key => $material_code) {
            $insert[$key]['material_code'] = $material_code;
        }
        foreach (Input::get('qty') as $key => $qty) {
            $insert[$key]['qty'] = $qty;
        }
        foreach (Input::get('status') as $key => $status) {
            $insert[$key]['status'] = $status;
        }
        foreach (Input::get('nolot') as $key => $nolot) {
            $insert[$key]['nolot'] = $nolot;
        }
        foreach (Input::get('uom') as $key => $uom) {
            $insert[$key]['uom'] = $uom;
        }
        $company = Auth::user()->company;
        $plant = Auth::user()->plant;
        $storage = Input::get('storage');
        $date_in = Input::get('date_in');
        //$material_code = Input::get('material_code');
        /*$lot_number = array(''=>'');
        foreach ($insert as $in) {
            $nicklot = Products::where('material_code','=',$in['material_code'])->get();
            foreach ($nicklot as $lot) {
                $lot_number[$lot->nicklot] = $lot->nicklot;
            }
        }*/
        $id_transaksi = Input::get('id_transaksi');
        $in = Transaksi::create([
        'company'       => $company,
        'plant'         => $plant,
        'id_transaksi'  => $id_transaksi,
        'date_in'       => $date_in,
        'storage'       => $storage,
        'no_suratjln'     => Input::get('no_srtjln'),
        'status'        => 'I',
        'remarks'       => Input::get('remarks'),
        'user_create'   => Auth::user()->employee_code,
        'user_update'   => Auth::user()->employee_code
        ]);
        foreach ($insert as $row ) {
            //$lot_number = array(''=>'');
            $nicklot = Products::where('material_code','=',$row['material_code'])->get();
            foreach ($nicklot as $lot) {
            $in->InDetail()->attach($id_transaksi,[
                'id_transaksi'  => $id_transaksi,
                'material_code' => $row['material_code'],
                'lot_number'    => $lot->nicklot.$row['nolot'],
                'qty_um'           => $row['qty'],
                'qty_uom'           => $row['uom'],
                'status'        => $row['status']
                ]);
            $in->InvDaily()->attach($id_transaksi,[
                'id'            => $id_transaksi,
                'company'       => $company,
                'plant'         => $plant,
                'material_code' => $row['material_code'],
                'lot_number'    => $lot->nicklot.$row['nolot'],
                'qty_um'        => $row['qty'],
                'qty_uom'       => $row['uom'],
                'storage'       => $storage,
                'status'        => $row['status'],
                'status2'       => 'I',
                'date_ym'       => $date_in,
                'created_at'    => date("Y-m-d H:i:s"),
                'updated_at'    => date("Y-m-d H:i:s")
                ]);
            }
        }
        return Redirect::to('/inbound');
    }
    public function getEdit($id_tx)
    {
        
        $inbound = DB::table('tx_itemin')->where('id_transaksi','=',$id_tx)->get();
        return View::make('inventory.editin')
                ->with('inbound',$inbound)
                ->with('storage',CommonCode::where('hcode','=','GD01')->where('code','!=','*')->get());
    }
    public function postInEdit(){
        date_default_timezone_set("Asia/Jakarta");
           
        $insert = array();
        foreach (Input::get('material_code') as $key => $material_code) {
            $insert[$key]['material_code'] = $material_code;
        }
        foreach (Input::get('matcod') as $key => $matcod) {
            $insert[$key]['matcod'] = $matcod;
        }
        foreach (Input::get('qty') as $key => $qty) {
            $insert[$key]['qty'] = $qty;
        }
        foreach (Input::get('kuantity_um') as $key => $kuantity_um) {
            $insert[$key]['kuantity_um'] = $kuantity_um;
        }
        foreach (Input::get('kuantity_uom') as $key => $kuantity_uom) {
            $insert[$key]['kuantity_uom'] = $kuantity_uom;
        }
        foreach (Input::get('status') as $key => $status) {
            $insert[$key]['status'] = $status;
        }
        foreach (Input::get('stat') as $key => $stat) {
            $insert[$key]['stat'] = $stat;
        }
        foreach (Input::get('nolot') as $key => $nolot) {
            $insert[$key]['nolot'] = $nolot;
        }
        foreach (Input::get('no_lot') as $key => $no_lot) {
            $insert[$key]['no_lot'] = $no_lot;
        }
        foreach (Input::get('uom') as $key => $uom) {
            $insert[$key]['uom'] = $uom;
        }
        $mtcd = array();
        $qty = array();
        $qtyuom = array();
        $stat = array();
        $no_lot = array();
        while(list($k,$v)= @each($insert)) {
            $mtcd[] = $v['material_code'];
            $qty[] = $v['qty'];
            $stat[] = $v['stat'];
            $no_lot[] = $v['no_lot'];
            $qtyuom[] = $v['uom'];
        }
        
        $company = Auth::user()->company;
        $plant = Auth::user()->plant;
        $storage = Input::get('storage');
        $stor = Input::get('stor');
        $date_in = Input::get('date_in');
        //$material_code = Input::get('material_code');
        /*$lot_number = array(''=>'');
        foreach ($insert as $in) {
            $nicklot = Products::where('material_code','=',$in['material_code'])->get();
            foreach ($nicklot as $lot) {
                $lot_number[$lot->nicklot] = $lot->nicklot;
            }
        }*/
        //$id_transaksi = Input::get('id_transaksi');
        $in = Transaksi::find(Input::get('id'));
        $in->company        = $company;
        $in->plant          = $plant;
        $in->id_transaksi   = Input::get('id_transaksi');
        $in->date_in        = Input::get('date_in');
        $in->storage        = Input::get('storage');
        $in->no_suratjln    = Input::get('no_suratjln');
        $in->status         = 'I';
        $in->remarks        = Input::get('remarks');
        $in->user_update    = Auth::user()->employee_code;
        
        if ($in->save()) {
            foreach ($insert as $row ) {

            //$lot_number = array(''=>'');
                $nicklot = Products::where('material_code','=',$row['material_code'])->get();
                foreach ($nicklot as $lot) {
                    /*$cekdtl = TransaksiDetail::where('id_transaksi','=',Input::get('id'))->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['no_lot'])->where('status','=',$row['stat'])->where('qty_um','=',$row['kuantity_um'])->where('qty_uom','=',$row['kuantity_uom'])->orWhere('material_code','=',$row['material_code'])->orWhere('lot_number','=',$lot->nicklot.$row['nolot'])->orWhere('status','=',$row['status'])->orWhere('qty_um','=',$row['qty'])->orWhere('qty_uom','=',$row['uom'])->get();*/
                    
                    /*$cekdtl1 = TransaksiDetail::where('id_transaksi','=',Input::get('id'))->get();*/
                    
                        /*if ($row['matcod']=='' && $row['no_lot']=='' && $row['kuantity_um']=='' && $row['kuantity_uom']=='' && $row['stat']=='')*/ 
                        if ($row['matcod'] == '' && $row['no_lot'] == '') {
                            DB::table('tx_itemindetail')->insert([
                            'id_transaksi'  => Input::get('id_transaksi'),
                            'material_code' => $row['material_code'],
                            'lot_number'    => $lot->nicklot.$row['nolot'],
                            'qty_um'        => $row['qty'],
                            'qty_uom'       => $row['uom'],
                            'status'        => $row['status']
                            ]);
                            $in->InvDaily()->attach(Input::get('id'),[
                                'id'            => Input::get('id_transaksi'),
                                'company'       => $company,
                                'plant'         => $plant,
                                'material_code' => $row['material_code'],
                                'lot_number'    => $lot->nicklot.$row['nolot'],
                                'qty_um'        => $row['qty'],
                                'qty_uom'       => $row['uom'],
                                'storage'       => $storage,
                                'status'        => $row['status'],
                                'status2'       => 'I',
                                'date_ym'       => $date_in,
                                'created_at'    => date("Y-m-d H:i:s"),
                                'updated_at'    => date("Y-m-d H:i:s")
                                ]);
                        }
                        /*elseif ($cekdtl == null) {
                            DB::table('tx_itemindetail')->insert([
                            'id_transaksi'  => Input::get('id_transaksi'),
                            'material_code' => $row['material_code'],
                            'lot_number'    => $lot->nicklot.$row['nolot'],
                            'qty_um'        => $row['qty'],
                            'qty_uom'       => $row['uom'],
                            'status'        => $row['status']
                            ]);

                        }*/
                        /*if ($cekdtl == null and $cekdtl1 == null) {
                        DB::table('tx_itemindetail')->insert([
                            'id_transaksi'  => Input::get('id_transaksi'),
                            'material_code' => $row['material_code'],
                            'lot_number'    => $lot->nicklot.$row['nolot'],
                            'qty_um'        => $row['qty'],
                            'qty_uom'       => $row['uom'],
                            'status'        => $row['status']
                            ]);
                    }*/
                    else 
                        DB::table('tx_itemindetail')->where('id_transaksi','=',Input::get('id'))->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['no_lot'])->where('status','=',$row['stat'])->where('qty_um','=',$row['kuantity_um'])->where('qty_uom','=',$row['kuantity_uom'])
                            ->update([
                                'id_transaksi'  => Input::get('id_transaksi'),
                                'material_code' => $row['material_code'],
                                'lot_number'    => $lot->nicklot.$row['nolot'],
                                'qty_um'        => $row['qty'],
                                'qty_uom'       => $row['uom'],
                                'status'        => $row['status']
                                ]);
                        DB::table('ss_invdaily')->where('id','=',Input::get('id'))->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['no_lot'])->where('status','=',$row['stat'])->where('qty_um','=',$row['kuantity_um'])->where('qty_uom','=',$row['kuantity_uom'])->where('storage','=',$stor)->where('status2','=','I')
                            ->update([
                                'id'            => Input::get('id_transaksi'),
                                'company'       => $company,
                                'plant'         => $plant,
                                'material_code' => $row['material_code'],
                                'lot_number'    => $lot->nicklot.$row['nolot'],
                                'qty_um'        => $row['qty'],
                                'qty_uom'       => $row['uom'],
                                'storage'       => $storage,
                                'status'        => $row['status'],
                                'status2'       => 'I',
                                'date_ym'       => $date_in,
                                'created_at'    => date("Y-m-d H:i:s"),
                                'updated_at'    => date("Y-m-d H:i:s")
                                ]);
                        /*$monthly = DB::table('ss_invmonthly')->get();
                        foreach ($monthly as $mnth) {
                            while(list($k,$v)= @each($insert)) {
                            if ($v['material_code'] == $mnth->material_code && $v['no_lot']== $mnth->lot_number && $storage = $mnth->storage) {
                                
                            DB::table('ss_invmonthly')->where('material_code','=',$row['material_code'])->where('lot_number','=',$row['no_lot'])->where('status','=',$row['status'])
                                ->update([
                                    'material_code' => $v['material_code'],
                                    'lot_number'    => $lot->nicklot.$v['nolot'],
                                    'begin_qty_um'  => $mnth->begin_qty_um,
                                    'begin_qty_uom' => $mnth->begin_qty_uom,
                                    'in_qty_um'     => $v['qty'],
                                    'in_qty_uom'    => $v['uom'],
                                    'out_qty_um'    => $mnth->out_qty_um,
                                    'out_qty_uom'   => $mnth->out_qty_uom,
                                    'end_qty_um'    => ($mnth->begin_qty_um + $v['qty']) - $mnth->out_qty_um ,
                                    'end_qty_uom'   => ($mnth->begin_qty_uom + $v['uom']) - $mnth->out_qty_uom,
                                    'storage'       => $storage,
                                    ]);
                            }
                            }
                        }*/
                        /*$monthly = DB::table('ss_invmonthly')->get();
                        foreach ($monthly as $mnth) {
                            /*if ($mnth->status != $row['status']) {
                            if ($row['stat'] != $row['status']) {
                                if ($row['status']==$mnth->status) {
                                    
                                    DB::table('ss_invmonthly')->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['no_lot'])->where('status','!=',$row['stat'])->where('storage','=',$stor)
                                        ->update([
                                            'yymm'          => DATE("Ym"),
                                            'company'       => $company,
                                            'plant'         => $plant,
                                            'material_code' => $row['material_code'],
                                            'lot_number'    => $lot->nicklot.$row['nolot'],
                                            'begin_qty_um'  => $mnth->begin_qty_um,
                                            'begin_qty_uom' => $mnth->begin_qty_uom,
                                            'in_qty_um'     => $mnth->in_qty_um + $row['qty'],
                                            'in_qty_uom'    => $mnth->in_qty_uom + $row['uom'],
                                            'out_qty_um'    => $mnth->out_qty_um,
                                            'out_qty_uom'   => $mnth->out_qty_uom,
                                            'end_qty_um'    => ($mnth->begin_qty_um + $mnth->in_qty_um + $row['qty']) - $mnth->out_qty_um ,
                                            'end_qty_uom'   => ($mnth->begin_qty_uom + $mnth->in_qty_uom + $row['uom']) - $mnth->out_qty_uom,
                                            'storage'       => $storage,
                                            ]);        
                                    DB::table('ss_invmonthly')->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['no_lot'])->where('status','=',$row['stat'])->where('storage','=',$stor)
                                        ->update([
                                            'yymm'          => DATE("Ym"),
                                            'company'       => $company,
                                            'plant'         => $plant,
                                            'material_code' => $row['material_code'],
                                            'lot_number'    => $lot->nicklot.$row['nolot'],
                                            'begin_qty_um'  => $mnth->begin_qty_um,
                                            'begin_qty_uom' => $mnth->begin_qty_uom,
                                            'in_qty_um'     => $row['kuantity_um'] - $row['qty'],
                                            'in_qty_uom'    => $row['kuantity_uom'] - $row['uom'],
                                            'out_qty_um'    => $mnth->out_qty_um,
                                            'out_qty_uom'   => $mnth->out_qty_uom,
                                            'end_qty_um'    => ($mnth->begin_qty_um  + $row['kuantity_um'] - $row['qty']) - $mnth->out_qty_um ,
                                            'end_qty_uom'   => ($mnth->begin_qty_uom  + $row['kuantity_uom'] - $row['uom']) - $mnth->out_qty_uom,
                                            'storage'       => $storage,
                                            ]);                        
                                }else{
                                    DB::table('ss_invmonthly')->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['no_lot'])->where('status','!=',$row['stat'])->where('storage','=',$stor)
                                        ->update([
                                            'yymm'          => DATE("Ym"),
                                            'company'       => $company,
                                            'plant'         => $plant,
                                            'material_code' => $row['material_code'],
                                            'lot_number'    => $lot->nicklot.$row['nolot'],
                                            'begin_qty_um'  => $mnth->begin_qty_um,
                                            'begin_qty_uom' => $mnth->begin_qty_uom,
                                            'in_qty_um'     => $row['qty'],
                                            'in_qty_uom'    => $row['uom'],
                                            'out_qty_um'    => $mnth->out_qty_um,
                                            'out_qty_uom'   => $mnth->out_qty_uom,
                                            'end_qty_um'    => ($mnth->begin_qty_um  + $row['kuantity_um'] - $row['qty']) - $mnth->out_qty_um ,
                                            'end_qty_uom'   => ($mnth->begin_qty_uom  + $row['kuantity_uom'] - $row['uom']) - $mnth->out_qty_uom,
                                            'storage'       => $storage,
                                            ]);
                                    DB::table('ss_invmonthly')->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['no_lot'])->where('status','=',$row['stat'])->where('storage','=',$stor)
                                        ->update([
                                            'yymm'          => DATE("Ym"),
                                            'company'       => $company,
                                            'plant'         => $plant,
                                            'material_code' => $row['material_code'],
                                            'lot_number'    => $lot->nicklot.$row['nolot'],
                                            'begin_qty_um'  => $mnth->begin_qty_um,
                                            'begin_qty_uom' => $mnth->begin_qty_uom,
                                            'in_qty_um'     => $mnth->in_qty_um - $row['qty'],
                                            'in_qty_uom'    => $mnth->in_qty_uom - $row['uom'],
                                            'out_qty_um'    => $mnth->out_qty_um,
                                            'out_qty_uom'   => $mnth->out_qty_uom,
                                            'end_qty_um'    => ($mnth->begin_qty_um  + ($mnth->in_qty_um- $row['qty'])) - $mnth->out_qty_um ,
                                            'end_qty_uom'   => ($mnth->begin_qty_uom  + ($mnth->in_qty_uom - $row['uom'])) - $mnth->out_qty_uom,
                                            'storage'       => $storage,
                                            ]);
                                }
                            }else{
                                DB::table('ss_invmonthly')->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['no_lot'])->where('status','!=',$row['stat'])->where('storage','=',$stor)
                                    ->update([
                                        'yymm'          => DATE("Ym"),
                                        'company'       => $company,
                                        'plant'         => $plant,
                                        'material_code' => $row['material_code'],
                                        'lot_number'    => $lot->nicklot.$row['nolot'],
                                        'begin_qty_um'  => $mnth->begin_qty_um,
                                        'begin_qty_uom' => $mnth->begin_qty_uom,
                                        'in_qty_um'     => $mnth->in_qty_um - $row['qty'],
                                        'in_qty_uom'    => $mnth->in_qty_uom - $row['uom'],
                                        'out_qty_um'    => $mnth->out_qty_um,
                                        'out_qty_uom'   => $mnth->out_qty_uom,
                                        'end_qty_um'    => ($mnth->begin_qty_um + $mnth->in_qty_um - $row['qty']) - $mnth->out_qty_um ,
                                        'end_qty_uom'   => ($mnth->begin_qty_uom + $mnth->in_qty_uom - $row['uom']) - $mnth->out_qty_uom,
                                        'storage'       => $storage,
                                        ]);
                            }
                        }*/
                        
                    
                    
                    /*DB::table('ss_invdaily')->where('id','=',Input::get('id'))->where('material_code','=',$row['matcod'])->where('lot_number','=',$row['no_lot'])->where('status','=',$row['stat'])->where('qty_um','=',$row['kuantity_um'])->where('qty_uom','=',$row['kuantity_uom'])->where('storage','=',$storage)
                        ->update([
                            'id'            => Input::get('id_transaksi'),
                            'company'       => $company,
                            'plant'         => $plant,
                            'material_code' => $row['material_code'],
                            'lot_number'    => $lot->nicklot.$row['nolot'],
                            'qty_um'        => $row['qty'],
                            'qty_uom'       => $row['uom'],
                            'storage'       => $storage,
                            'status'        => $row['status'],
                            'status2'       => 'I',
                            'date_ym'       => $date_in,
                            'created_at'    => date("Y-m-d H:i:s"),
                            'updated_at'    => date("Y-m-d H:i:s")
                            ]);*/
                   
                    }

                }
                return Redirect::to('/inbound');
            }                   
    }
    public function deleteItem($idtx,$mtcd,$ltno){
        DB::table('tx_itemindetail')->where('id_transaksi','=',$idtx)->where('material_code','=',$mtcd)->where('lot_number','=',$ltno)->delete();

        return Redirect::to('/inbound/edit/'.Session::get('id_tx'));
    }
    public function getReturn(){
        $inventory = array('' => '');
        foreach(DB::table('ss_invmonthly')->get() as $row)
            foreach (Products::where('material_code','=',$row->material_code)->get() as $prd) {
                $inventory[$row->material_code] = $row->material_code." - ".$prd->material_name;
            }
        $p_bad = DB::table('tx_itemin')->join('tx_itemindetail', 'tx_itemindetail.id_transaksi', '=', 'tx_itemin.id_transaksi')->where( 'tx_itemindetail.status','=','B')->get();
        $return = DB::table('ss_invmonthly')->where('status','=','B')->where('end_qty_um','!=',0)->get();
        return View::make('inventory.return', array(
            'products'  => $inventory,
            'return' => $return    
        ));
    }
    public function getCreateReturn()
    {
        session_start();
        session_destroy();
        $storage = DB::table('cd_code')->join('ss_invmonthly', 'cd_code.code', '=', 'ss_invmonthly.storage')->where( 'ss_invmonthly.status','=','B')->where('ss_invmonthly.end_qty_um','!=',0)->distinct()->select('ss_invmonthly.storage','cd_code.code','cd_code.code_name')->get();
        return View::make('inventory.createreturn')
            ->with('warehouse',CommonCode::where('hcode','LIKE','%'.'GD'.'%')->where('code','!=','*')->get())
            ->with('pabrik',CommonCode::where('hcode','LIKE','%'.'PB'.'%')->where('code','!=','*')->where('code','!=',7003)->where('code','!=',7004)->get());
    }
    public function postShow()
    {
        switch(Input::get('type')):
            case 'storage':
                $m = Input::get('id');
                $list = DB::table('ss_invmonthly')->join('cd_material','cd_material.material_code','=','ss_invmonthly.material_code')->where('storage','=',Input::get('id'))->where('end_qty_um','!=',0)->where('status','=','B')->get();
                if (count($list)==0) {
                    $return = "<script>alert('Not Found a Bad Product In Warehouse!!');window.location.reload();</script>";
                }else{
                    /*$return = "<table class='table table-striped responsive-utilities jambo_table bulk_action'>
                              <thead>
                                <tr class='headings'>
                                  <th class='column-title' colspan='3'>Material </th>
                                  <th class='column-title'>Lot Number</th>
                                  <th class='column-title' >Qty BAD</th>
                                  <th class='column-title' style='text-align:center' colspan='4'>Qty Return</th>
                                </tr>
                              </thead>
                              <tbody>";*/
                foreach(DB::select(DB::raw("select distinct ss_invmonthly.material_code, cd_material.material_name, cd_material.um, cd_material.uom from ss_invmonthly join cd_material on cd_material.material_code=ss_invmonthly.material_code where status = 'B' and end_qty_um != 0 and storage='{$m}'")) as $row){
                        session_start();

                        $_SESSION['m'] = $m;

                        
                    $return .= "<p></p>"; /*"<tr class='even pointer'>
                                    <td class='col-md-5' colspan='3'>
                                        <input value=''  name='material_code[]' type='text' class='col-md-3' >
                                        <a id='btnLaunch' class='col-md-2 btn btn-round btn-xs-primary' data-toggle='modal' data-target='.bs-example-modal-lg'>+ Add </a>
                                        <input value='' name='mater' type='text' class='col-md-6' >
                                    </td>
                                    <td class='col-md-1'><h1></h1></td>
                                    <td class='col-md-2' colspan='2'>
                                        <input name='end_qty[]' class='col-md-6' type='text' value=''>
                                        <input name='return_qty_bag' class='col-md-6' type='text' value=''>
                                    </td>
                                    <td class='col-md-5' colspan='4'>
                                        <input style='width:80px' name='qty[]' class='tInput' id='itemQty' tabindex='1' />
                                        <input type='hidden' name='size[]' value='' class='tInput' />
                                        <input style='width:40px' class='tInput' id='um' readonly='readonly' value='' />
                                        <input style='width:80px' type='text' name='uom[]' readonly='readonly' />
                                        <input style='width:30px' id='uom' class='tInput' readonly='readonly' value=''/>
                                    </td>
                                </tr>
                                ";
*/                       // }
                            }
                  }
                return $return;
                
            break;
            case 'lis':
            $m = Input::get('id');
                $return = "<table class='table table-striped responsive-utilities jambo_table bulk_action'>
                              <thead>
                                <tr class='headings'>
                                  <th class='column-title' colspan='2'>Material </th>
                                  <th class='column-title'>Lot Number</th>
                                  <th class='column-title' >Qty BAD</th>
                                </tr>
                              </thead>
                              <tbody>";
                foreach(DB::select(DB::raw("select ss_invmonthly.*, cd_material.* from ss_invmonthly join cd_material on cd_material.material_code=ss_invmonthly.material_code where status = 'B' and end_qty_um != 0 and storage='{$m}'")) as $row){
                    $return .= "<tr class='even pointer'>
                                    <td class='col-md-6' colspan='2'>
                                        <input value='$row->material_code' name='material_code[]' id='s' type='text' class='sli col-md-2' >
                                        <input value='$row->material_name' name='mater' type='text' class='col-md-6' >
                                    </td>
                                    <td class='col-md-3'>
                                        <input name='end_qty[]' class='col-md-12' type='text' value='$row->lot_number'>
                                    </td>
                                    <td class='col-md-3' colspan='2'>
                                        <input name='end_qty[]' class='col-md-6' type='text' value=''>
                                        <input name='return_qty_bag' class='col-md-6' type='text' value='$row->um'>
                                    </td>
                                </tr>
                                ";
                       // }
                  }
                
                    return $return;
            break;
             case 'destination':
                $destination = Input::get('id');
                $dt = date("Ymd",strtotime(Input::get('dt')));
                if ($destination == '7001') {
                    $dst = 'B';
                }elseif ($destination == '7002') {
                    $dst = 'A';
                }
                foreach(DB::select(DB::raw("select max(substr(no_transaksi,-3,3)) as max from ss_outmaster where(select max(substr(no_transaksi,-3,3)) from ss_outmaster where substr(no_transaksi,3,8)= '{$dt}' ) and substr(no_transaksi,-4,1)='{$dst}'")) as $row)
                    $no_transaksi = 'DO'.date('Ymd',strtotime($dt)).$dst.sprintf('%03d', $row->max+1);
                    $return = "<input  type='text' style='width: 250px;'' class='form-control' readonly='readonly' name='no_transaksi' value='$no_transaksi'>";
                return $return;
            break;
            case 'sk':
                    
            break;
        endswitch;    
    }
    public function postReturn() {
        switch(Input::get('type')):
            case 'lotnumber':
                $return = '<option value=""></option>';
                foreach(Inventory::where('material_code', Input::get('id'))->get() as $row)
                    //$pro = Products::where('material_code',$row->material_code)->first();
                    $return .= "<option value='$row->lot_number'>$row->lot_number</option> ";
                return $return;
            break;
            case 'material':
                //$return = '<option value=""></option>';
                foreach(Inventory::where('lot_number', Input::get('id'))->get() as $row)
                    $pro = Products::where('material_code',$row->material_code)->first();
                    //$return .= "<option disable value='$row->lot_number'>$pro->material_size</option> ";
                    $return = " <table class='table table-striped responsive-utilities jambo_table bulk_action'>
                                    <thead>
                                      <tr class='headings'>
                                        <th class='column-title'>Qty Bad Bag </th>
                                        <th class='column-title'>Qty Bad Kgs </th>
                                        <th class='column-title'>Qty Return Bag</th>
                                        <th class='column-title'>Qty Return Kgs</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                        <tr class='even pointer'>
                                            <td class='col-md-2'><input name='bad_qty_bag' value='$row->bad_qty_bag' type='text' class='col-md-12' id='bad_bag' onkeyup='myFunction()''></input></td>
                                            <td class='col-md-2'><input name='bad_qty_kgs' type='text' id='result_bad' value='$row->bad_qty_kgs' readonly='readonly' class='col-md-12'></input></td>
                                            <td class='col-md-2'><input name='return_qty_bag' class='col-md-12' type='number' max='$row->bad_qty_bag' id='return_bag' onkeyup='myFunction()'></input></td>
                                            <td class='col-md-2'><input type='text' name='return_qty_kgs' id='result_return' readonly='readonly' class='col-md-12'></input> </td>
                                            
                                        </tr>
                                    </tbody>
                                </table>
                                <input type='hidden' id='return_kg' onkeyup='myFunction()' value='$pro->material_size'>
                                <input type='hidden' id='bad_kg' onkeyup='myFunction()' value='$pro->material_size'>
                                <input type='hidden' value='$row->material_name' name='material_name'>
                                <input type='hidden' value='$row->storage' name='storage'>
                                <input type='hidden' value='$row->good_qty_bag' name='good_qty_bag'>
                                <input type='hidden' value='$row->good_qty_kgs' name='good_qty_kgs'>
                                <input type='hidden' value='$row->good_qty_bag' name='good_qty_bag'>
                                ";
                return $return;
        endswitch;    
    }
         
        

    public function postCreateReturn(){
        
        $insert = array();
        foreach (Input::get('material_code') as $key => $material_code) {
            $insert[$key]['material_code'] = $material_code;
        }
        foreach (Input::get('qty_out_um') as $key => $qty_out_um) {
            $insert[$key]['qty_out_um'] = $qty_out_um;
        }
        foreach (Input::get('qty_out_uom') as $key => $qty_out_uom) {
            $insert[$key]['qty_out_uom'] = $qty_out_uom;
        }
        foreach (Input::get('lot_number') as $key => $lot_number) {
            $insert[$key]['lot_number'] = $lot_number;
        }
        
        $company = Auth::user()->company;
        $plant = Auth::user()->plant;
        
        
        $source = Input::get('source');
        $destination = Input::get('destination');
        if ($destination == '7001') {
            $dest = 'B';
        }elseif ($destination == '7002') {
            $dest = 'A';
        }
        $trucking   = Input::get('trucking');
        $no_srtjln  = Input::get('no_srtjln');
        $remarks    = Input::get('remarks');
        $date_out   = Input::get('date_out');
        $user_create = Auth::user()->employee_code;
        $user_update = Auth::user()->employee_code;
        $no_rtn = DB::select(DB::raw("select max(substr(no_transaksi,-3,3)) as max from ss_outmaster where(select max(substr(no_transaksi,-3,3)) from ss_outmaster where substr(no_transaksi,3,8)= DATE_FORMAT(NOW(),'%Y%m%d')) and substr(no_transaksi,-4,1)='{$dest}'"));
        foreach ($no_rtn as $nortn) {
            /*if ($destination == '7001') {
                $no_transaksi = 'DO'.date('Ymd').'B' .sprintf('%03d', $nortn->max+1);
            }
            elseif($destination == '7002'){
                $no_transaksi = 'DO'.date('Ymd').'A'.sprintf('%03d', $nortn->max+1);
            }*/
            $no_transaksi = 'DO'.date('Ymd').$dest.sprintf('%03d', $nortn->max+1);
        }
        $notx = Input::get('no_transaksi');
        $return = ReturnMaster::create([
                'company'       => $company,
                'plant'         => $plant,
                'no_transaksi'  => $notx,
                'date_out'      => $date_out,
                'status'        => 'R',
                'destination'   => $destination,
                'source'        => $source,
                'trucking'      => $trucking,
                'no_srtjln'     => $no_srtjln,
                'remarks'       => $remarks,
                'user_create'   => $user_create,
                'user_update'   => $user_update
            ]);
        foreach ($insert as $row ) {
            //$lot_number = array(''=>'');
            
            if ($row['qty_out_um'] != 0) {
                
            $return->ReturnDetail()->attach($notx,[
                'no_transaksi'     => $notx,
                'material_code' => $row['material_code'],
                'lot_number'    => $row['lot_number'],
                'qty_out_um'    => $row['qty_out_um'],
                'qty_out_uom'    => $row['qty_out_uom'],
                'status'        => 'B'
                ]);
            $return->InvDaily()->attach($notx,[
                'id'            => $notx,
                'company'       => $company,
                'plant'         => $plant,
                'material_code' => $row['material_code'],
                'lot_number'    => $row['lot_number'],
                'qty_um'        => $row['qty_out_um'],
                'qty_uom'       => $row['qty_out_uom'],
                'storage'       => $source,
                'status'        => 'B',
                'status2'       => 'O',
                'date_ym'       => $date_out,
                'created_at'    => date("Y-m-d H:i:s"),
                'updated_at'    => date("Y-m-d H:i:s")
                ]);
            }
        }
            return Redirect::to('return');

        
    }
}